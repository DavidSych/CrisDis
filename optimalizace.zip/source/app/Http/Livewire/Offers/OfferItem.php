<?php

namespace App\Http\Livewire\Offers;

use App\Models\Inquiry;
use App\Models\InquiryStock;
use App\Models\OfferItem as OfferItemModel;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Livewire\Component;

class OfferItem extends Component
{

    public $stockItem;

    protected $listeners = ['updateOfferItems' => 'update'];

    public $showDates = false;

    public $pivotId;

    public $offerId;

    public $locked;

    public function mount(Request $request, $stockItem, $pivotId, $offerId, $locked = false)
    {

        $this->stockItem = $stockItem;

        $this->pivotId = $pivotId;

        $this->offerId = $offerId;

        $this->locked = $locked;

    }

    public function openAddItemModal()
    {
        $this->emit('openAddItemModal', $this->pivotId);
    }

    public function update() {

    }

    public function editItem($itemId)
    {
        $this->emit('openAddItemModal', $this->pivotId, $itemId);

        $this->emit('updatePrice');
    }

    public function removeItem($itemId)
    {
        $item = OfferItemModel::findOrFail($itemId);

        $item->delete();

        $this->emit('updatePrice');
    }

    /*
    public function updateStockAmount($id, $amount = 0)
    {
        $inquiryStock = InquiryStock::findOrFail($id);

        $inquiryStock->updateAmount($amount);
    }

    public function updateStockDeliveryDate($id, $date = '')
    {
        $inquiryStock = InquiryStock::findOrFail($id);

        $inquiryStock->updateDeliveryDate($date ?: null);
    }

    public function removeStockItem($pivotId)
    {
        $inquiryStock = InquiryStock::findOrFail($pivotId);

        $inquiryStock->delete();

        $this->emit('stockItemRemoved');
    }

    */

    public function render()
    {

        $items = OfferItemModel::query()
            ->where('offer_id', $this->offerId)
            ->where('inquiry_stock_id', $this->pivotId)
            ->get();


        $pivot = InquiryStock::findOrFail($this->pivotId);

        return view('offers.lw-offer-item', [
            'items' => $items,
            'pivot' => $pivot
        ]);
    }
}

