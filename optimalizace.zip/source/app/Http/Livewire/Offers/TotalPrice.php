<?php

namespace App\Http\Livewire\Offers;

use App\Models\Inquiry;
use App\Models\InquiryStock;
use App\Models\Offer;
use App\Models\OfferItem as OfferItemModel;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Livewire\Component;

class TotalPrice extends Component
{
    protected $listeners = ['updatePrice' => 'update'];

    public $offerId;

    public function mount(Request $request, $offerId)
    {
        $this->offerId = $offerId;
    }

    public function update() {

    }

    public function editItem($itemId)
    {
        $this->emit('openAddItemModal', $this->pivotId, $itemId);
    }

    public function render()
    {
        $offer = Offer::findOrFail($this->offerId);

        $priceRange = $offer->getPriceRange();

        return view('offers.lw-sum', [
            'priceRange' => $priceRange,
        ]);
    }
}

