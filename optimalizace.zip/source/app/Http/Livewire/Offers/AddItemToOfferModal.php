<?php

namespace App\Http\Livewire\Offers;

use App\Helpers\AppHelper;
use App\Models\InquiryStock;
use App\Models\OfferItem as OfferItemModel;
use App\Models\Product;
use App\Models\Project;
use App\Models\Stock;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class AddItemToOfferModal extends Component
{
    public $dialogVisible = false;

    public $offerItem = null;

    public $stockItemId = false;

    public $offerId = null;

    public $itemId = false;

    public $state = [];

    protected $listeners = [
        'openAddItemModal' => 'openDialog'
    ];

    public function mount($offerId)
    {
        $this->offerId = $offerId;
    }

    public function saveItem()
    {
        $companyId = request()->user()->company->id;

        $this->resetErrorBag();

        $data = $this->state;

        $data['price'] = AppHelper::csCommaToDot($data['price']);

        $data['url'] = AppHelper::addHttpIfMissing(($data['url'] ?? null));

        try {
            $input = $this->customValidate($data);
        } catch(\Exception $e) {
            $this->dispatchBrowserEvent('initialize-flatpickr');

            $this->customValidate($data);
        }


        $input['offer_id'] = $this->offerId;

        $input['inquiry_stock_id'] = $this->stockItemId;

        if ($this->itemId) {
            $offerItem = OfferItemModel::findOrFail($this->itemId);
        } else {
            $offerItem = new OfferItemModel();
        }

        $offerItem->forceFill($input);

        $offerItem->save();


        // saving or updating company product
        $product = Product::query()
            ->where('company_id', $companyId)
            ->where('name', $input['name'])
            ->first();

        if (!$product) {
            $product = new Product();

            $product->company_id = $companyId;
        }

        $product->name = $input['name'];
        $product->url = $input['url'] ?? null;
        $product->note = $input['note'] ?? null;
        $product->price = $input['price'];

        $product->save();

        $this->emit('updatePrice');

        $this->close();
    }

    public function openDialog($stockItemId = null, $itemId = false)
    {
        $this->stockItemId = $stockItemId;

        $this->itemId = $itemId;

        if ($itemId) {
            $stateArray = OfferItemModel::findOrFail($itemId)->toArray();

            $stateArray['price'] = AppHelper::csDotToComma($stateArray['price']);

            $this->state = $stateArray;
        }

        $this->dialogVisible = true;

        $this->dispatchBrowserEvent('initialize-flatpickr');
    }

    public function close()
    {
        $this->dialogVisible = false;

        $this->emit('updateOfferItems');

        $this->state = [];
    }

    public function render()
    {
        $stock = false;

        // loading stock item
        $stockItem = InquiryStock::find($this->stockItemId);

        if ($stockItem) {
            $stock = $stockItem->stock;
        }

        return view('offers.lw-add-item-to-offer-modal', [
            'stockItem' => $stock,
            'pivot' => $stockItem
        ]);
    }

    private function customValidate($data)
    {
        return Validator::make($data, [
            'name' => ['string', 'required', 'max:255'],
            'url' => ['url', 'nullable', 'max:255'],
            'note' => ['nullable'],
            'delivery_date' => ['nullable', 'date'],
            'price' => ['numeric', 'required'],
        ])->validateWithBag('AddItemModal');
    }
}
