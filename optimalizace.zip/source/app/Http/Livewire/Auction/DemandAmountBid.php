<?php

namespace App\Http\Livewire\Auction;

use App\Models\Company;
use App\Models\CrisisDemand;
use App\Models\CrisisSupply;
use App\Models\Stock;
use Livewire\Component;

class DemandAmountBid extends Component
{
    public $amount;

    public $credit;

    public $stock;

    public $company;

    public function mount($stockId)
    {
        $this->stock = Stock::findOrFail($stockId);

        $this->populateValues();
    }

    public function populateValues()
    {
        $bid = CrisisDemand::query()
            ->where('company_id', request()->user()->company->id)
            ->where('stock_id', $this->stock->id)
            ->first();

        if($bid) {
            $this->amount = $bid->amount;
            $this->credit = $bid->credit;
        }
    }

    public function updated()
    {
        $companyId = request()->user()->company->id;

        $bid = CrisisDemand::query()
            ->where('company_id', $companyId)
            ->where('stock_id', $this->stock->id)
            ->first();

        if(!$bid) {
            $bid = new CrisisDemand();

            $bid->company_id = $companyId;
            $bid->stock_id = $this->stock->id;
        }

        $bid->amount = $this->amount;
        $bid->credit = $this->credit;

        $bid->save();
    }

    public function render()
    {
        return view('auction.lw-demand-bid');
    }
}
