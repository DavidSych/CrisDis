<?php

namespace App\Http\Livewire\Auction;

use App\Models\Company;
use Livewire\Component;

class AvailableCredit extends Component
{
    public $availableCredit;

    public $reservedCredit;

    /** @var Company */
    public $company;

    protected $listeners = [
        'bidsUpdated' => 'updateValues',
    ];

    public function mount(Company $company)
    {
        $this->company = $company;
    }

    public function updateValues()
    {
    }


    public function render()
    {
        $this->reservedCredit = $this->company->getReservedCredit();

        $this->availableCredit = $this->company->getAvailableCredit();

        return view('auction.lw-available-credit.blade.php');
    }
}
