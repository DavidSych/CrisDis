<?php

namespace App\Http\Livewire\Auction;

use App\Models\Company;
use App\Models\CrisisSupply;
use App\Models\Stock;
use Livewire\Component;

class SupplyAmountBid extends Component
{
    public $amount;

    public $price;

    public $stock;

    public $company;

    public function mount($stockId)
    {
        $this->stock = Stock::findOrFail($stockId);

        $this->populateValues();
    }

    public function populateValues()
    {
        $bid = CrisisSupply::query()
            ->where('company_id', request()->user()->company->id)
            ->where('stock_id', $this->stock->id)
            ->first();

        if($bid) {
            $this->price = $bid->price;

            $this->amount = $bid->amount;
        }
    }

    public function updated()
    {
        $companyId = request()->user()->company->id;

        $bid = CrisisSupply::query()
            ->where('company_id', $companyId)
            ->where('stock_id', $this->stock->id)
            ->first();

        if(!$bid) {
            $bid = new CrisisSupply();

            $bid->company_id = $companyId;
            $bid->stock_id = $this->stock->id;
        }

        $bid->price = $this->price ?: 0;

        $bid->amount = $this->amount;

        $bid->save();
    }

    public function render()
    {
        return view('auction.lw-supply-bid');
    }
}
