<?php

namespace App\Http\Livewire\Auction;

use App\Classes\Advisor\AdviseParser;
use App\Models\Bid;
use App\Models\Company;
use Livewire\Component;

class Article extends Component
{
    /** @var $stock */
    public $stock;

    /** @var Company */
    public $company;

    public $showDialog = false;

    public $bidsBuying;

    public $bidsSelling;

    public $bidsProduct;

    public $state = [
        'price' => 0,
        'amount' => 0,
    ];

    /*
    protected $listeners = [
        'filterByCategory' => 'filterExpenses',
        'showPlannedExpenses' => 'showExpensesTable',
    ];
    */

    public $type;

    public function mount()
    {
        $this->bidsBuying = $this->company->bidsBuying;

        $this->bidsSelling = $this->company->bidsSelling;

        $this->bidsProduct = $this->company->bidsProduct;
    }

    public function editBid($id)
    {
        $bid = Bid::findOrFail($id);

        $this->state = $bid->toArray();

        $this->openDialog($bid->type);
    }

    public function openDialog($type)
    {
        $this->type = $type;

        $this->showDialog = true;
    }

    public function save()
    {
        $this->resetErrorBag();

        $data = $this->state;

        if($this->type == 'selling') {
            $input = \Validator::make($data, [
                'amount' => ['numeric','max:' . $this->company->getAvailableAllowance($this->stock->id),  'required'],
                'price' => ['numeric', 'required'],
            ])->validateWithBag('createProject');
        } elseif($this->type == 'buying') {
            $input = \Validator::make($data, [
                'amount' => ['numeric', 'required'],
                'price' => ['numeric', 'required'],
            ])->validateWithBag('createProject');
        } else {
        $input = \Validator::make($data, [
            'amount' => ['numeric', 'required'],
            'price' => ['numeric', 'required'],
        ])->validateWithBag('createProject');
    }

        if(!isset($this->state['id'])) {
            $bid = new Bid();

            $bid->company_id = $this->company->id;

            $bid->stock_id = $this->stock->id;

            $bid->type = $this->type;
        } else {
            $bid = Bid::findOrFail($this->state['id']);
        }

        $bid->price = $input['price'];

        $bid->amount = $input['amount'];

        $bid->save();

        $this->emit('bidsUpdated');

        $this->company->refresh();

        $this->bidsBuying = $this->company->bidsBuying;

        $this->bidsSelling = $this->company->bidsSelling;

        $this->bidsProduct = $this->company->bidsProduct;

        $this->cancelDialog();
    }

    public function removeBid($id)
    {
        Bid::findOrFail($id)->delete();

        $this->render();

        $this->company->refresh();

        $this->bidsBuying = $this->company->bidsBuying;

        $this->bidsSelling = $this->company->bidsSelling;

        $this->bidsProduct = $this->company->bidsProduct;
    }

    public function cancelDialog()
    {
        $this->state = [
            'price' => 0,
            'amount' => 0,
        ];

        $this->showDialog = false;

        $this->type = false;
    }

    public function render()
    {
        $availableAllowance = $this->company->getAvailableAllowance($this->stock->id);

        $reservedAllowance = $this->company->getReservedAllowance($this->stock->id);

        $adviseParser = new AdviseParser($this->stock->id);

        $advisedPrice = round($adviseParser->getAdvisedPrice() * 100) / 100;

        $advisedAmount = $adviseParser->getAdvisedAmount($this->company->id);

        return view('auction.lw-article', compact([
            'availableAllowance',
            'reservedAllowance',
            'advisedPrice',
            'advisedAmount',
        ]));
    }
}
