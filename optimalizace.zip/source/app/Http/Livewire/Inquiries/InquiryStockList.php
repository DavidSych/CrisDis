<?php

namespace App\Http\Livewire\Inquiries;

use App\Models\Inquiry;
use App\Models\InquiryStock;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Livewire\Component;

class InquiryStockList extends Component
{
    public $inquiryId;

    protected $listeners = ['stockItemAdded' => 'updateItems'];

    public $showDates = false;

    public function mount(Request $request, $inquiryId)
    {
        $this->inquiryId = $inquiryId;

        $this->updateItems();
    }

    public function updateItems() {

        $inquiry = Inquiry::findOrFail($this->inquiryId);

        $this->showDates = $inquiry->separate_dates;

        $this->dispatchBrowserEvent('initialize-flatpickr');
    }

    public function updateStockAmount($id, $amount = 0)
    {
        $inquiryStock = InquiryStock::findOrFail($id);

        $amount = (int) $amount;

        if($amount < 1) {
            $amount = 1;
        }

        $this->dispatchBrowserEvent('initialize-flatpickr');

        $inquiryStock->updateAmount($amount);
    }

    public function updateStockDeliveryDate($id, $date = '')
    {
        $inquiryStock = InquiryStock::findOrFail($id);

        $inquiryStock->updateDeliveryDate($date ?: null);

        $this->dispatchBrowserEvent('initialize-flatpickr');
    }

    public function removeStockItem($pivotId)
    {
        $inquiryStock = InquiryStock::findOrFail($pivotId);

        $inquiryStock->delete();

        $this->emit('stockItemRemoved');
    }

    public function openNoteModal($pivotId)
    {
        $this->emit('openNoteModal', $pivotId);

        $this->dispatchBrowserEvent('initialize-flatpickr');
    }

    public function render()
    {
        $inquiry = Inquiry::findOrFail($this->inquiryId);

        $stock = $inquiry->query()
            ->with(['stock' => function ($q) {
                $q->orderBy('pivot_id', 'asc');
            }])->findOrFail($this->inquiryId);


        return view('inquiries.inquiry-stock-list', [
            'stock' => $stock->stock
        ]);
    }
}

