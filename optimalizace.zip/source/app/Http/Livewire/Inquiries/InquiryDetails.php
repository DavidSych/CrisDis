<?php

namespace App\Http\Livewire\Inquiries;

use App\Models\Inquiry;
use App\Models\InquiryStock;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Livewire\Component;

class InquiryDetails extends Component
{
    public $inquiryId;

    public $inquiry;

    public $state;

    public function mount(Request $request, $inquiryId)
    {
        $this->inquiryId = $inquiryId;

        $this->inquiry = Inquiry::findOrFail($inquiryId);

        $this->state = $this->inquiry->withoutRelations()->toArray();
    }

    public function updated()
    {
        $this->resetErrorBag();

        $data = $this->state;

        $input = Validator::make($data, [
            'allow_partial_offers' => ['boolean'],
            'separate_dates' => ['boolean'],
            'offers_due' => ['date', 'nullable'],
            'delivery_date' => ['date', 'nullable'],
            'note' => ['nullable'],
        ])->validateWithBag('inquiryForm');

        $this->inquiry->forceFill([

            'allow_partial_offers' => $input['allow_partial_offers'],
            'separate_dates' => $input['separate_dates'],
            'offers_due' => $input['offers_due'] ?: null,
            'delivery_date' => $input['delivery_date'] ?: null,
            'note' => $input['note']

        ])->save();

        $this->emit('saved');

        $this->emit('stockItemAdded');
    }


    public function render()
    {
        return view('inquiries.inquiry-details');
    }
}

