<?php

namespace App\Http\Livewire\Inquiries;

use App\Models\Inquiry;
use App\Models\InquiryStock;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Livewire\Component;

class InquiryDates extends Component
{
    public $inquiryId;

    public $inquiry;

    public $state;

    public function mount(Request $request, $inquiryId)
    {
        $this->inquiryId = $inquiryId;

        $this->inquiry = Inquiry::findOrFail($inquiryId);

        $this->state = $this->inquiry->withoutRelations()->toArray();
    }

    public function updated()
    {
        $this->resetErrorBag();

        $data = $this->state;

        $input = Validator::make($data, [
            'offers_due' => ['date', 'nullable'],
            'delivery_date' => ['date', 'nullable'],
        ])->validateWithBag('inquiryForm');

        $this->inquiry->forceFill([
            'offers_due' => $input['offers_due'] ?: null,
            'delivery_date' => $input['delivery_date'] ?: null,
        ])->save();

        $this->emit('saved');

        $this->emit('stockItemAdded');
    }


    public function render()
    {
        return view('inquiries.inquiry-dates');
    }
}

