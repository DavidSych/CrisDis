<?php

namespace App\Http\Livewire\Inquiries;

use App\Models\InquiryStock;
use App\Models\Project;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class NoteModal extends Component
{
    public $dialogVisible = false;

    public $pivotId = false;

    public $state = [];

    protected $listeners = [
        'openNoteModal' => 'openDialog'
    ];

    public function createProject()
    {
        $this->resetErrorBag();

        $data = $this->state;

        $input = Validator::make($data, [
            'note' => ['nullable'],
        ])->validateWithBag('AddItemModal');

        $item =  InquiryStock::findOrFail($this->pivotId);

        $item->note = $input['note'];

        $item->save();

        $this->close();
    }

    public function openDialog($pivotId)
    {
        $this->pivotId = $pivotId;

        $this->state = InquiryStock::findOrFail($pivotId)->toArray();

        $this->dialogVisible = true;
    }

    public function close()
    {
        $this->dialogVisible = false;

        $this->emit('stockItemAdded');

        $this->state = [];
    }

    public function render()
    {
        return view('inquiries.lw-note-modal');
    }
}
