<?php

namespace App\Http\Livewire\Inquiries;

use App\Models\Inquiry;
use Illuminate\Http\Request;
use Livewire\Component;

class InquiryList extends Component
{
    public $status;

    public function mount(Request $request, $status = false)
    {
        $this->status = $status;
    }

    public function render()
    {
        $inquiriesQuery = request()
            ->user()
            ->company
            ->inquiries()
            ->orderByDesc('created_at');

        if($this->status) {
            $inquiriesQuery->where('status', $this->status);
        }

        $inquiries = $inquiriesQuery->get();

        return view('inquiries.inquiries-list', [
            'inquiries' => $inquiries
        ]);
    }
}
