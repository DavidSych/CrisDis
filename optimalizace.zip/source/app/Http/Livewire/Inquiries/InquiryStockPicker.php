<?php

namespace App\Http\Livewire\Inquiries;

use App\Models\Inquiry;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Livewire\Component;

class InquiryStockPicker extends Component
{
    public $inquiryId;

    public $query = '';

    protected $listeners = ['stockItemRemoved' => 'updateItems'];

    public function mount(Request $request, $inquiryId)
    {
        $this->inquiryId = $inquiryId;
    }

    public function addStockItem($id)
    {
        $stock = Stock::findOrFail($id);

        if($stock->crisis_mode) {
            return;
        }

        $inquiry = Inquiry::findOrFail($this->inquiryId);

        $inquiry->stock()->attach($id, ['amount' => 1]);

        $this->emit('stockItemAdded');
    }

    public function updateItems()
    {

    }

    public function render()
    {
        $results = [];

        if(strlen($this->query) >= 3) {
            $results = Stock::query()
                ->where('name', 'like', '%' . $this->query . '%')
                ->orWhere('code', 'like', '%' . $this->query . '%')
                ->limit(10)
                ->get();
        }

        $selectedStock = Inquiry::findOrFail($this->inquiryId)->stock()->pluck('stocks.id')->toArray();

        $counts = [];

        foreach($selectedStock as $selectedItem) {
            if(!isset($counts[$selectedItem])) {
                $counts[$selectedItem] = 0;
            }

            $counts[$selectedItem]++;
        }

        if($results) {
            $results->each(function($value) use ($counts) {
                $value->selected = $counts[$value->id] ?? false;
            });
        }


        return view('inquiries.inquiry-stock-picker', [
            'results' => $results,
        ]);
    }
}

