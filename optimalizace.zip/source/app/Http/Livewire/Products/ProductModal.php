<?php

namespace App\Http\Livewire\Products;

use App\Helpers\AppHelper;
use App\Models\InquiryStock;
use App\Models\OfferItem as OfferItemModel;
use App\Models\Product;
use App\Models\Project;
use App\Models\Stock;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class ProductModal extends Component
{
    public $dialogVisible = false;

    public $itemId = false;

    public $state = [];

    protected $listeners = [
        'openProductModal' => 'openDialog'
    ];

    public function saveItem()
    {
        $companyId = request()->user()->company->id;

        $this->resetErrorBag();

        $data = $this->state;

        $data['price'] = AppHelper::csCommaToDot($data['price']);

        $data['url'] = AppHelper::addHttpIfMissing($data['url']);

        $input = $this->customValidate($data);

        // saving or updating company product
        $product = Product::query()
            ->where('company_id', $companyId)
            ->where('name', $input['name'])
            ->first();

        if(!$product) {
            $product = new Product();

            $product->company_id = $companyId;
        }

        $product->name = $input['name'];
        $product->url = $input['url'];
        $product->note = $input['note'];
        $product->price = $input['price'];

        $product->save();

        $this->close();
    }

    public function openDialog($itemId = false)
    {
        $this->itemId = $itemId;

        if($itemId) {
            $stateArray = Product::findOrFail($itemId)->toArray();

            $stateArray['price'] = AppHelper::csDotToComma($stateArray['price']);

            $this->state = $stateArray;
        }

        $this->dialogVisible = true;

        $this->dispatchBrowserEvent('initialize-flatpickr');
    }

    public function close()
    {
        $this->dialogVisible = false;

        $this->emit('updateProducts');

        $this->state = [];
    }

    public function render()
    {
        return view('products.lw-product-modal');
    }

    private function customValidate($data)
    {
        return Validator::make($data, [
            'name' => ['string', 'required', 'max:255'],
            'url' => ['url', 'nullable', 'max:255'],
            'note' => ['nullable'],
            'price' => ['numeric', 'nullable'],
        ])->validateWithBag('AddItemModal');
    }
}
