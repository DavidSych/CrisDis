<?php

namespace App\Http\Livewire\Products;

use App\Models\Company;
use App\Models\Offer;
use App\Models\Product;
use App\Models\Stock;
use Livewire\Component;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Mediconesystems\LivewireDatatables\NumberColumn;

class ProductsGrid extends Component
{
    protected $listeners = [
        'updateProducts' => 'updateList'
    ];

    public function togglePortfolioItem($id)
    {
        $company = request()->user()->company;

        $company->portfolio()->toggle($id);
    }

    public function editItem($itemId)
    {
        $this->emit('openProductModal', $itemId);
    }

    public function removeItem($itemId)
    {
        $companyId = request()->user()->company->id;

        $product = Product::findOrFail($itemId);

        if($product->company_id != $companyId) {
            abort(403);
        }

        $product->delete();
    }

    public function updateList()
    {

    }

    public function render()
    {
        $companyId = request()->user()->company->id;

        $products = Product::query()
            ->where('company_id', $companyId)
            ->orderBy('name')
            ->get();

        return view('products.lw-products-grid', [
            'products' => $products
        ]);
    }
}
