<?php

namespace App\Http\Livewire\Stock;

use App\Models\Company;
use App\Models\Offer;
use App\Models\Stock;
use Livewire\Component;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Mediconesystems\LivewireDatatables\NumberColumn;

class StockPortfolio extends Component
{
    public function togglePortfolioItem($id)
    {
        $company = request()->user()->company;

        $company->portfolio()->toggle($id);
    }

    public function render()
    {
        $portfolio = request()->user()->company->portfolio()->pluck('stock_id');

        $stock = Stock::query()
            ->orderBy('name')
            ->get();

        foreach($stock as $stockItem) {
            $stockItem->inPortfolio = in_array($stockItem->id, $portfolio->toArray());
        }

        return view('stock.lw-portfolio', [
            'stock' => $stock
        ]);
    }
}
