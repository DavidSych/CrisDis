<?php

namespace App\Http\Livewire\Stock;

use App\Models\Allowance;
use App\Models\Company;
use App\Models\Offer;
use App\Models\Stock;
use Livewire\Component;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Mediconesystems\LivewireDatatables\NumberColumn;
use Storage;

class StockCrisis extends Component
{
    public function togglePortfolioItem($id)
    {
        $stock = Stock::findOrFail($id);

        $stock->crisis_mode = !$stock->crisis_mode;

        $stock->save();
    }

    public function setStockStage($id, $stage)
    {
        $stock = Stock::findOrFail($id);

        $stock->stage = $stage;

        $stock->save();
    }

    public function evaluateFirstRound($id)
    {
        $stock = Stock::findOrFail($id);

        $json = $stock->generateAuctionData2();

        Storage::put('computation/input.json', json_encode($json));

        exec('python /var/www/zdr-portal.localhost/scripts/contested_garment_distribution.py > ../storage/app/computation/output.json');

        $output =  file_get_contents(base_path('storage/app/computation/output.json'), true);

        $output = json_decode($output, true);

        foreach($output['rights'] as $company => $amount) {
            $allowance = new Allowance();
            $allowance->company_id = $company;
            $allowance->amount = $amount;
            $allowance->stock_id = $id;
            $allowance->save();
        }

        $stock->stage = 2;

        $stock->save();

        session()->flash('message', 'první etapa vyhodnocena');

    }


    public function render()
    {
        $stock = Stock::query()
            ->orderBy('name')
            ->get();

        return view('stock-crisis.lw-crisis', [
            'stock' => $stock
        ]);
    }
}
