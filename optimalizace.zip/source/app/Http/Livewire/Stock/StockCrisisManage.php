<?php

namespace App\Http\Livewire\Stock;

use App\Classes\Archive;
use App\Classes\ArchiveToken;
use App\Classes\Processors\RoundOne;
use App\Classes\Processors\RoundTwo;
use App\Models\Allowance;
use App\Models\Company;
use App\Models\Offer;
use App\Models\Stock;
use Livewire\Component;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Mediconesystems\LivewireDatatables\NumberColumn;
use Storage;

class StockCrisisManage extends Component
{
    public $stockId = null;

    public $showResultsRoundOne;

    public function togglePortfolioItem($id)
    {
        $stock = Stock::findOrFail($id);

        $stock->crisis_mode = !$stock->crisis_mode;

        $stock->save();
    }

    public function setStockStage($id, $stage)
    {
        $stock = Stock::findOrFail($id);

        $stock->stage = $stage;

        $stock->save();
    }

    public function evaluateFirstRound($id)
    {
        $roundOneProcessor = new RoundOne($id);

        $roundOneProcessor->process();

        session()->flash('message', 'první etapa vyhodnocena');
    }

    public function evaluateSecondRound($id)
    {
        $roundOneProcessor = new RoundTwo($id);

        $roundOneProcessor->process();

        session()->flash('message', 'druhá etapa vyhodnocena');
    }


    public function render()
    {
        $stock = Stock::query()
            ->where('id', $this->stockId)
            ->get();

        $roundOneProcessor = new RoundOne($stock);

        $prediction = $roundOneProcessor->getPrediction();


        return view('stock-crisis.lw-manage', [
            'stock' => $stock,
            'prediction' => $prediction,
        ]);
    }
}
