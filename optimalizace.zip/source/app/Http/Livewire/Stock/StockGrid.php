<?php

namespace App\Http\Livewire\Stock;

use App\Models\Company;
use App\Models\Stock;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Mediconesystems\LivewireDatatables\NumberColumn;

class StockGrid extends LivewireDatatable
{
    public function builder()
    {
        return Stock::query();
    }

    public function columns()
    {
        return [

            Column::name('code')
                ->filterable()
                ->searchable()
                ->label(__('Code')),


            Column::name('name')
                ->defaultSort('asc')
                ->filterable()
                ->searchable()
                ->label(__('Item name'))


        ];
    }
}
