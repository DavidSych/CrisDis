<?php

namespace App\Http\Livewire\Companies;

use App\Classes\CompanyTypes;
use App\Helpers\AppHelper;
use App\Models\Company;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Mediconesystems\LivewireDatatables\NumberColumn;

class CompaniesGrid extends LivewireDatatable
{
    public function builder()
    {
        return Company::query();
    }


    public function columns()
    {
        return [

            Column::name('name')
                ->label('Název')
                ->defaultSort('asc')
                ->searchable()
                ->filterable(),

            Column::callback(['type'], function ($type) {
                return __(CompanyTypes::getLabel($type));
            })->label(__('Typ společnosti')),

            Column::name('ic')
                ->label(__('IČ')),

            Column::callback(['credit'], function ($credit) {

                return '<div class="text-right">' . AppHelper::formatCzk($credit)  . " Kč</div>";
            })->label(__('Kredit')),

            Column::callback(['id'], function ($id) {
                return view('companies.table-actions', ['id' => $id]);
            }),

        ];
    }
}
