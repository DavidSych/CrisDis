<?php

namespace App\Http\Livewire\Companies;

use App\Models\Company;
use Livewire\Component;

class CompanyInfoModal extends Component
{
    public $modalVisible = false;

    public $companyId = false;

    protected $listeners = [
        'openCompanyInfoModal' => 'openModal'
    ];

    public function openModal($companyId = false)
    {
        $this->companyId = $companyId;

        $this->modalVisible = true;
    }

    public function close()
    {
        $this->modalVisible = false;

        $this->state = [];
    }

    public function render()
    {
        $company = Company::query()->find($this->companyId);

        return view('companies.lw-company-info-modal', [
            'company' => $company,
        ]);
    }
}
