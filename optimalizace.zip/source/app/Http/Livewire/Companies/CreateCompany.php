<?php

namespace App\Http\Livewire\Companies;

use App\Models\Company;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class CreateCompany extends Component
{
    public $dialogVisible = false;

    public $state = [];

    public function createContact()
    {
        $this->resetErrorBag();

        $data = $this->state;

        $input = Validator::make($data, [
            'name' => ['string', 'required', 'max:255'],
            'ic' => ['string', 'max:30', 'nullable']
        ])->validateWithBag('createContact');

        $company = new Company();

        $company->forceFill($input);

        $company->save();

        return redirect()->to('companies/'. $company->id .'/update');

    }

    public function openDialog()
    {
        $this->dialogVisible = true;
    }

    public function cancel()
    {
        $this->dialogVisible = false;
    }

    public function render()
    {
        return view('companies.create-company');
    }
}
