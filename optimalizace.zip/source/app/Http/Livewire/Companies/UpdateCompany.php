<?php

namespace App\Http\Livewire\Companies;

use App\Classes\CompanyTypes;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Livewire\Component;

class UpdateCompany extends Component
{
    public $company;

    public $state = [];

    public function mount(Request $request, $company)
    {
        $this->company = $company;

        $this->state = $company->withoutRelations()->toArray();
    }

    public function updateProfileInformation()
    {
        $this->resetErrorBag();

        $data = $this->state;

        $input = Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'url' => ['string', 'max:255', 'nullable'],
            'ic' => [ 'string', 'max:30', 'nullable'],
            'dic' => ['string', 'max:30', 'nullable'],

            'type' => ['nullable'],

            'phone' => [ 'string', 'max:100', 'nullable'],
            'fax' => [ 'string', 'max:100', 'nullable'],
            'email' => ['email', 'max:255', 'nullable'],

            'street' => ['string', 'max:255', 'nullable'],
            'town' => ['string', 'max:255', 'nullable'],
            'zip' => ['string', 'max:6', 'nullable'],
            'country' => ['string', 'max:255', 'nullable'],

            'credit' => ['numeric'],
        ])->validateWithBag('updateProfileInformation');

        $this->company->forceFill([

            'name' => $input['name'],
            'url' => $input['url'],
            'ic' => $input['ic'],
            'dic' => $input['dic'],

            'phone' => $input['phone'],
            'fax' => $input['fax'],
            'email' => $input['email'],

            'type' => $input['type'],

            'street' => $input['street'],
            'town' => $input['town'],
            'zip' => $input['zip'],
            'country' => $input['country'],

            'credit' => $input['credit'],
        ])->save();

        $this->emit('saved');

        $this->emit('refresh-navigation-dropdown');
    }

    public function render()
    {
        return view('companies.company-details-form', [
            'types' => CompanyTypes::getTypes()
        ]);
    }
}
