<?php

namespace App\Http\Livewire\Companies;

use App\Classes\CompanyTypes;
use App\Models\Allowance;
use App\Models\Company;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Livewire\Component;

class UpdateAllowances extends Component
{
    /** @var Company */
    public $company;

    public $state = [];

    public function mount(Request $request, $company)
    {
        $this->company = $company;

        $this->state = $this->generateState();
    }

    public function update()
    {
        $this->resetErrorBag();

        $data = $this->state;

        foreach($this->state as $key => $value) {
            $allowance = Allowance::firstOrNew([
                'company_id' => $this->company->id,
                'stock_id' => $key,
            ]);

            $allowance->amount = $value;

            $allowance->save();
        }

        $this->emit('saved');

    }

    public function render()
    {
        $stock = Stock::query()
            ->where('crisis_mode', true)
            ->orderBy('name')
            ->get();

        return view('companies.company-allowances-form', [
            'stock' => $stock
        ]);
    }

    private function generateState()
    {
        $stock = Stock::query()->orderBy('name')->get();

        $state = [];

        $allowances = $this->company->getAllowanceArray();

        foreach($stock as $item) {
            if(!isset($allowances[$item->id])) {
                $allowances[$item->id] = 0;
            }

            $state[$item->id] = $allowances[$item->id];
        }

        return $state;
    }
}
