<?php

namespace App\Http\Livewire\Generator;

use App\Models\Company;
use App\Models\CrisisDemand;
use App\Models\CrisisSupply;
use App\Models\Stock;
use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class Step1 extends Component
{
    public $demand = null;
    public $supply = null;
    public $suppliers = 0;
    public $hospitals = 0;
    public $priceFrom = 200;
    public $priceTo = 500;
    public $stockId = null;

    protected $listeners = [
        'generatorAction' => 'refresh'
    ];

    protected $rules = [
        'stockId' => ['required'],
        'demand' => ['required', 'integer'],
        'supply' => ['required', 'integer'],
        'suppliers' => ['required', 'integer'],
        'hospitals' => ['required', 'integer'],
        'priceFrom' => ['required', 'integer'],
        'priceTo' => ['required', 'integer'],
    ];

    protected $messages = [
        'stockId.required' => 'Vyberte prosím výrobek.'
    ];

    public function generateSupplyAndDemand()
    {
        $this->validate();

        $this->distributeSupply(
            $this->stockId,
            $this->supply,
            $this->suppliers,
            $this->priceFrom,
            $this->priceTo
        );

        $this->distributeDemand(
            $this->stockId,
            $this->demand,
            $this->hospitals
        );

        $this->supply = null;
        $this->demand = null;

        $stock = Stock::findOrFail($this->stockId);
        $stock->crisis_mode = 1;
        $stock->save();

        $this->refresh();
    }

    public function render()
    {
        $this->suppliers = Company::where('type', 1)->count();
        $this->hospitals = Company::where('type', 2)->count();

        return view('generator.step1', [
            'stock' => Stock::query()->pluck('name', 'id'),
            'suppliersCount' => $this->suppliers,
            'hospitalsCount' => $this->hospitals,
        ]);
    }

    public function refresh()
    {

    }

    private function distributeSupply($stockId, $supply, $suppliersCount, $priceFrom, $priceTo)
    {
        $randomRolls = $this->getRandomValues($suppliersCount);

        $sum = array_sum($randomRolls);

        $distributedValues = [];

        foreach($randomRolls as $value) {
            $distributedValues[] = floor(($value / $sum) * $supply);
        }

        $companies = Company::query()
            ->where('type', 1)
            ->inRandomOrder()
            ->limit($suppliersCount)
            ->get();

        $i = 0;
        foreach($companies as $company) {
            if(!$distributedValues[$i]) {
                continue;
            }

            $supplyItem = new CrisisSupply();
            $supplyItem->stock_id = $stockId;
            $supplyItem->company_id = $company->id;
            $supplyItem->amount = $distributedValues[$i++];
            $supplyItem->price = rand($priceFrom, $priceTo);
            $supplyItem->save();
        }

    }

    private function distributeDemand($stockId, $demand, $hospitals)
    {
        $randomRolls = $this->getRandomValues($hospitals);

        $sum = array_sum($randomRolls);

        $distributedValues = [];

        foreach($randomRolls as $value) {
            $distributedValues[] = floor(($value / $sum) * $demand);
        }

        $companies = Company::query()
            ->where('type', 2)
            ->inRandomOrder()
            ->limit($hospitals)
            ->get();

        $i = 0;
        foreach($companies as $company) {
            if(!$distributedValues[$i]) {
                continue;
            }

            $amount = $distributedValues[$i++];

            $demandItem = new CrisisDemand();
            $demandItem->stock_id = $stockId;
            $demandItem->company_id = $company->id;
            $demandItem->amount = $amount;
            $demandItem->credit = rand($this->priceFrom, $this->priceTo) * $amount;
            $demandItem->save();
        }
    }

    private function getRandomValues($amount)
    {
        $randomRolls = [];

        for($i=0; $i<$amount; $i++) {
            $randomRolls[] = rand(1, 100);
        }

        return $randomRolls;
    }
}
