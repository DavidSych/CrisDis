<?php

namespace App\Http\Livewire\Generator;

use App\Classes\ArchiveToken;
use App\Models\Company;
use App\Models\Stock;
use App\Models\User;
use DB;
use Livewire\Component;

class ResetSystem extends Component
{
    public function resetDatabase()
    {
        DB::statement("SET foreign_key_checks=0");
        DB::table('allowances')->truncate();
        DB::table('bids')->truncate();
        DB::table('companies')->truncate();
        DB::table('crisis_demand')->truncate();
        DB::table('crisis_supplies')->truncate();
        DB::table('inquiries')->truncate();
        DB::table('inquiry_stock')->truncate();
        DB::table('offer_items')->truncate();
        DB::table('offers')->truncate();
        DB::table('portfolios')->truncate();
        DB::table('products')->truncate();
        DB::table('transactions')->truncate();
        DB::statement("SET foreign_key_checks=1");

        Stock::query()->update([
            'crisis_mode' => 0,
            'stage' => 1,
        ]);

        User::query()->update([
            'company_id' => null
        ]);

        (new ArchiveToken())->deleteToken();

        $this->emit('generatorAction');
    }

    public function render()
    {
        return view('generator.reset-system');
    }
}
