<?php

namespace App\Http\Livewire\Generator;

use App\Models\Company;
use App\Models\Stock;
use App\Models\User;
use DB;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Companies extends Component
{
    public $suppliers = 10;
    public $hospitals = 10;

    protected $listeners = [
        'generatorAction' => 'refresh'
    ];

    public function generateCompanies()
    {
        Company::factory($this->suppliers)->create([
            'type' => 1
        ]);

        Company::factory($this->hospitals)->create([
            'type' => 2
        ]);

        // assigning current user to the first generated one
        $company = Company::where('type', 2)->first();

        // assign company to all users

        $users = User::get();

        foreach($users as $user) {
            $user->company_id = $company->id;

            $user->save();
        }

        $this->emit('generatorAction');
    }

    public function render()
    {
        return view('generator.companies', [
            'suppliersCount' => Company::where('type', 1)->count(),
            'hospitalsCount' => Company::where('type', 2)->count(),
        ]);
    }

    public function refresh()
    {

    }
}
