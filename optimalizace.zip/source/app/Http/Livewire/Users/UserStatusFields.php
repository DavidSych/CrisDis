<?php

namespace App\Http\Livewire\Users;

use App\Models\Company;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Contracts\UpdatesUserProfileInformation;
use Livewire\Component;
use Spatie\Permission\Models\Role;

class UserStatusFields extends Component
{
    public $user;

    public $state = [];


    public function mount(Request $request, $user)
    {
        $this->$user = $user;

        $role = optional($user->roles()->first())->name;

        $this->state = $user->withoutRelations()->toArray();

        $this->state['role'] = $role;
    }

    public function updateStatusFields()
    {
        $this->resetErrorBag();

        $data = $this->state;

        $input = Validator::make($data, [
            'active' => ['boolean'],
            'new' => ['boolean'],
            'role' => ['string', 'nullable'],
            'company_id' => ['integer', 'nullable'],
        ])->validateWithBag('updateProfileInformation');

        $this->user->forceFill([
            'active' => $input['active'],
            'new' => $input['new'],
            'company_id' => $input['company_id'],
        ])->save();

        $this->user->syncRoles([$input['role']]);

        $this->emit('saved');
    }


    public function render()
    {
        $roles = config('zdrsys.roles');

        $companies = Company::query()
            ->orderBy('name')
            ->pluck('name', 'id');

        return view('users.user-status-fields', [
            'state' => $this->state,
            'roles' => $roles,
            'companies' => $companies,
        ]);
    }
}
