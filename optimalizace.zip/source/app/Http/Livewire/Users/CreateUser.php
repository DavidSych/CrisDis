<?php

namespace App\Http\Livewire\Users;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Livewire\Component;

class CreateUser extends Component
{
    public $dialogVisible = false;

    public $state = [];

    public function createUser()
    {
        $this->resetErrorBag();

        $data = $this->state;

        $input = Validator::make($data, [
            'name' => ['string', 'required', 'max:255'],
            'surname' => ['string', 'required', 'max:255'],
            'email' => ['email', 'required', 'unique:App\Models\User,email'],
        ])->validateWithBag('crateUser');

        $user = new User();

        $user->forceFill($input);

        $user->password = Hash::make('secret');

        $user->save();

        return redirect()->to('users/'. $user->id .'/update');

    }

    public function openDialog()
    {
        $this->dialogVisible = true;
    }

    public function cancel()
    {
        $this->dialogVisible = false;
    }

    public function render()
    {
        return view('users.create-user');
    }
}
