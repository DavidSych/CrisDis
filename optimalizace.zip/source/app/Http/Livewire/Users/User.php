<?php

namespace App\Http\Livewire\Users;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Lab404\Impersonate\Models\Impersonate;
use Laravel\Fortify\Contracts\UpdatesUserProfileInformation;
use Livewire\Component;

class User extends Component
{
    public $user;

    public $state = [];

    use Impersonate;

    public function mount(Request $request, $user)
    {
        $this->$user = $user;

        $this->state = $user->withoutRelations()->toArray();
    }

    public function updateProfileInformation()
    {
        $this->resetErrorBag();

        $data = $this->state;

        $input = Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'surname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users')->ignore($this->user->id)],
            'title_before' => ['string', 'max:100', 'nullable'],
            'title_after' => [ 'string', 'max:100', 'nullable'],
            'phone' => [ 'string', 'max:100', 'nullable'],
            'phone_office' => [ 'string', 'max:100', 'nullable'],
        ])->validateWithBag('updateProfileInformation');

        $this->user->forceFill([
            'name' => $input['name'],
            'surname' => $input['surname'],
            'email' => $input['email'],
            // 'title_before' => $input['title_before'] ?? '',
            // 'title_after' => $input['title_after'] ?? '',
            // 'phone' => $input['phone'] ?? '',
            // 'phone_office' => $input['phone_office'] ?? '',
        ])->save();

        $this->emit('saved');

        $this->emit('refresh-navigation-dropdown');
    }


    public function render()
    {
        return view('users.user-profile-info', [
            'state' => $this->state
        ]);
    }
}
