<?php

namespace App\Http\Livewire\Users;

use App\Models\User;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;
use Mediconesystems\LivewireDatatables\NumberColumn;

class UsersGrid extends LivewireDatatable
{
    public function builder()
    {
        return User::query();
    }

    public function columns()
    {
        return [

            Column::name('surname')
                ->label('Příjmení')
                ->defaultSort('asc')
                ->searchable(),

            Column::name('name')
                ->label('Jméno')
                ->searchable(),

            Column::callback(['email'], function ($email){

                return '<a href="mailto:'. $email .'" class="text-blue-800">'. $email .'</a>';

            })->label('Email'),

            // Column::name('phone'),

            Column::callback(['id'], function ($id) {
                return view('users.table-actions', ['id' => $id]);
            }),

        ];
    }
}
