<?php

namespace App\Http\Controllers;

use App\Models\Inquiry;
use App\Models\Offer;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;

class OpenInquiriesController extends Controller
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index(Request $request)
    {
        $inquiries = Inquiry::query()
            ->with(['stock', 'company'])
            ->where('status', 2)
            ->orderByDesc('offers_due')
            ->get();

        foreach($inquiries as $inquiry) {
            $inquiry->offerCreated = Offer::query()
                ->where('inquiry_id', $inquiry->id)
                ->where('company_id', $request->user()->company->id)
                ->exists();
        }

        return view('open-inquiries.open-inquiries-list', [
            'inquiries' => $inquiries
        ]);
    }

    public function detail($id, Request $request)
    {
        $inquiry = Inquiry::findOrFail($id);

        $companyOffer = Offer::query()
            ->where('inquiry_id', $id)
            ->where('company_id', $request->user()->company->id)
            ->first();

        return view('open-inquiries.open-inquiries-detail', [
            'inquiry' => $inquiry,
            'hasOffer' => (bool) $companyOffer,
            'offerId' => $companyOffer ? $companyOffer->id : false,
        ]);
    }

}
