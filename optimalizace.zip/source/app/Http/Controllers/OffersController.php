<?php

namespace App\Http\Controllers;

use App\Models\Inquiry;
use App\Models\Offer;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;

class OffersController extends Controller
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index(Request $request)
    {
        $offers = $request->user()->company->offers()->where('status','>', 1)->get();

        $openOffers = $request->user()->company->offers()->where('status', 1)->get();

        return view('offers.index', [
            'openOffers' => $openOffers,
            'offers' => $offers,
        ]);
    }

    public function create($inquiryId, Request $request)
    {
        $offer = new Offer();

        $offer->company_id = $request->user()->company->id;

        $offer->inquiry_id = $inquiryId;

        $offer->save();

        return redirect('/offers/' . $offer->id . '/update');
    }

    public function update($id, Request $request)
    {
        $offer = Offer::findOrFail($id);

        $inquiry = $offer->inquiry;

        $approval = old('approval');

        return view('offers.update-offer', [
            'offer' => $offer,
            'inquiry' => $inquiry,
            'approval' => $approval
        ]);
    }

    public function preview($id, Request $request)
    {
        $offer = Offer::findOrFail($id);

        if(
            $offer->company_id != $request->user()->company->id &&
            $offer->inquiry->company_id != $request->user()->company->id
        ) {
            abort(403);
        }

        $inquiry = $offer->inquiry;

        return view('offers.preview-offer', [
            'offer' => $offer,
            'inquiry' => $inquiry
        ]);
    }

    public function submit($id, Request $request)
    {
        $input = $request->validate([
            'approval' => ['required'],
        ], $messages = [
            'required' => 'Pro odeslání nabídky je potřeba prohlášení se pravodivostí údajů.',
        ]);

        $offer = Offer::query()->findOrFail($id);

        // check inquiry ownership

        if(!$offer->isReadyToBePublished()) {
            return redirect()
                ->back()
                ->withInput()
                ->withErrors(['invalidOffer' => 'Vyplněte prosím nabídku k jednotilvým produktům.']);
        }

        $offer->status = 2;

        $offer->save();

        return redirect()->back();
    }
}
