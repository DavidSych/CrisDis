<?php

namespace App\Http\Controllers;

use App\Models\Allowance;
use App\Models\Stock;
use App\Models\Transaction;
use Illuminate\Http\Request;

class AuctionController extends Controller
{
    public function index()
    {
        $stock = Stock::query()->where('crisis_mode', true)->orderBy('name')->get();

        $company = request()->user()->company;

        /*
        $allowances = $company->getAllowanceArray();

        $transactions = Transaction::query()
            ->where('buyer', $company->id)
            ->orWhere('seller', $company->id)
            ->orderByDesc('created_at')
            ->get();
        */

        return view('auction.index', compact([
            'company',
            'stock',
            // 'allowances',
            // 'transactions',
        ]));
    }

    public function article(Stock $stock)
    {
        $company = request()->user()->company;

        return view('auction.article', compact([
            'company',
            'stock',
        ]));
    }
}
