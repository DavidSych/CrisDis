<?php

namespace App\Http\Controllers;

use App\Models\Inquiry;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Session;

class InquiriesController extends Controller
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index(Request $request)
    {
        return view('inquiries.index');
    }

    public function create(Request $request)
    {
        $inquiry = new Inquiry();

        $inquiry->company_id = $request->user()->company->id;

        $inquiry->save();

        return redirect('/inquiries/' . $inquiry->id . '/update');
    }

    public function update($id, Request $request)
    {
        $inquiry = Inquiry::findOrFail($id);

        $errorMessages = Session::pull('errorMessages', []);

        if($inquiry->status == 2) {
            return redirect()->to('inquiries/' . $inquiry->id . '/preview');
        }

        return view('inquiries.update-inquiry', [
            'inquiry' => $inquiry,
            'errorMessages' => $errorMessages
        ]);
    }

    public function save($id, Request $request)
    {
        $inquiry = Inquiry::findOrFail($id);

        if($inquiry->company_id != $request->user()->company->id) {
            abort(403);
        }

        $errorMessages = [];

        // At least one piece of material
        if($inquiry->stock->count() === 0) {
            $errorMessages[] = 'Zadejte prosím alespoň jednu položku materiálu.';
        }

        // at least one piece of every item
        $zeroAmount = false;

        foreach($inquiry->stock as $stockItem) {
            if($stockItem->pivot->amount < 1) {
                $zeroAmount = true;

                break;
            }
        }

        if($zeroAmount) {
            $errorMessages[] = 'Zkontrolujte prosím, že poptáváte alespoň jeden kus od každého materiálu.';
        }

        // check for dates
        if(!$inquiry->delivery_date) {
            $errorMessages[] = 'Zadejte, prosím, datum dodání.';
        }

        if(!$inquiry->offers_due) {
            $errorMessages[] = 'Zadejte, prosím, termín do kdy bude nabídka zveřejněna.';
        }

        if(count($errorMessages)) {
            return back()->with(['errorMessages' => $errorMessages]);
        }

        return redirect()->to('inquiries/' . $inquiry->id . '/preview');
    }

    public function preview($id, Request $request)
    {
        $inquiry = Inquiry::findOrFail($id);

        if($inquiry->company_id != $request->user()->company->id) {
            abort(403);
        }

        return view('open-inquiries.open-inquiries-detail', [
            'title' => 'Zkontrolujte prosím poptávku před zveřejněním',
            'inquiry' => $inquiry,
            'preview' => true,
        ]);

    }

    public function makePublic($id, Request $request)
    {
        $input = $request->validate([
            'approval' => ['required'],
        ], $messages = [
            'required' => 'Pro zveřejnění poptávky je potřeba prohlášení se pravodivostí údajů.',
        ]);


        $inquiry = Inquiry::findOrFail($id);

        // check inquiry ownership

        $inquiry->status = 2;

        $inquiry->save();

        return redirect()->back();
    }
}
