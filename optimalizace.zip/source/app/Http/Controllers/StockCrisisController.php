<?php

namespace App\Http\Controllers;

use App\Models\Stock;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;

class StockCrisisController extends Controller
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index()
    {
        return view('stock-crisis.stock-list');
    }

    public function manage($id)
    {
        $stock = Stock::findOrFail($id);

        return view('stock-crisis.manage', [
            'stock' => $stock
        ]);
    }
}
