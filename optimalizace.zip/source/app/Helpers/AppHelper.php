<?php
namespace App\Helpers;

use Carbon\Carbon;
use DateTime;

class AppHelper {
    public static function csCommaToDot($number)
    {
        return str_replace(',', '.', $number);
    }

    public static function csDotToComma($number)
    {
        return str_replace('.', ',', $number);
    }

    public static function formatDate($date)
    {
        if(is_string($date)) {
            $date = new DateTime($date);

            return $date->format("j.n.Y");
        }

        return $date;
    }

    public static function formatCzk($number)
    {
        return number_format($number, '2', ',', ' ');
    }

    public static function addHttpIfMissing($url)
    {
        $url = trim($url);

        if($url === '' || $url === null) {
            return null;
        }

        $arrParsedUrl = parse_url($url);

        if (!empty($arrParsedUrl['scheme'])) {
            return $url;
        } else {
            return 'http://' . $url;
        }
    }
}
