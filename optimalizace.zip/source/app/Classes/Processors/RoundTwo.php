<?php

namespace App\Classes\Processors;

use App\Classes\Archive;
use App\Models\Allowance;
use App\Models\Stock;
use Illuminate\Support\Facades\Storage;

class RoundTwo {

    protected $archive;

    protected $stockId;

    private $pythonCommand;

    public function __construct($stockId)
    {
        $this->archive = new Archive($stockId);

        $this->stockId = $stockId;

        $this->pythonCommand = config('zdrsys.python_command');
    }

    public function process()
    {
        $stock = Stock::findOrFail($this->stockId);

        $json = $stock->generateAuctionData();

        Storage::put('computation/input-2.json', json_encode($json));

        $basePath = base_path();

        exec("{$this->pythonCommand} {$basePath}/scripts/step-2.py > ../storage/app/computation/output-2.json");

        $output =  file_get_contents(base_path('storage/app/computation/output-2.json'), true);

        $output = json_decode($output, true);

        /*
        foreach($output['rights'] as $company => $amount) {
            $allowance = new Allowance();
            $allowance->company_id = $company;
            $allowance->amount = $amount;
            $allowance->stock_id = $this->stockId;
            $allowance->save();
        }

        $stock->stage = 2;

        $stock->save();

        $this->showResultsRoundOne = true;

        // $this->generateResultJson();
        */

        // logging archive
        $this->archive->storeFile(json_encode($json), 'round-2-input.json');
        $this->archive->storeFile(json_encode($output), 'round-2-output.json');
    }

    public function getResultJson()
    {
        return $this->archive->getFile('round-2-output.json');
    }

    protected function generateResultJson()
    {
        $input =  file_get_contents(base_path('storage/app/computation/input.json'), true);
        $input = json_decode($input, true);

        $output =  file_get_contents(base_path('storage/app/computation/output.json'), true);
        $output = json_decode($output, true);


        $result = [];

        $result['stock'] = $input['stock'];
        $result['transactions'] = [];

        foreach($input['productDemand'] as $demand) {
            $result['transactions'][] = [
                'company_id' => $demand['company_id'],
                'demanded' => $demand['amount'],
                'received' => $output['rights'][$demand['company_id']],
            ];
        }

        $this->archive->storeFile(json_encode($result), 'round-1-result.json');
    }

}

