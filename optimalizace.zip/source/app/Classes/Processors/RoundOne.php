<?php

namespace App\Classes\Processors;

use App\Classes\Advisor\AdviseParser;
use App\Classes\Archive;
use App\Models\Allowance;
use App\Models\Stock;
use Illuminate\Support\Facades\Storage;

class RoundOne {

    protected $archive;

    protected $stockId;

    private $pythonCommand;

    public function __construct($stockId)
    {
        $this->archive = new Archive($stockId);

        $this->stockId = $stockId;

        $this->pythonCommand = config('zdrsys.python_command');
    }

    public function process()
    {
        $stock = Stock::findOrFail($this->stockId);

        $json = $stock->generateAuctionData2();

        Storage::put('computation/input.json', json_encode($json));

        $basePath = base_path();

        exec("{$this->pythonCommand} {$basePath}/scripts/step-1.py > ../storage/app/computation/output.json");

        $output =  file_get_contents(base_path('storage/app/computation/output.json'), true);

        $output = json_decode($output, true);

        foreach($output['rights'] as $company => $amount) {
            $allowance = new Allowance();
            $allowance->company_id = $company;
            $allowance->amount = $amount;
            $allowance->stock_id = $this->stockId;
            $allowance->save();
        }

        $stock->stage = 2;

        $stock->save();

        $this->showResultsRoundOne = true;

        // logging archive
        $this->archive->storeFile(json_encode($json), 'round-1-input.json');
        $this->archive->storeFile(json_encode($output), 'round-1-output.json');

        $this->generateResultJson();

        // Interim price data packing and processing

        $json1b = $stock->generateInterimPriceData();

        Storage::put('computation/input-1b.json', json_encode($json1b));

        $this->archive->storeFile(json_encode($json1b), 'round-1b-input.json');

        exec("{$this->pythonCommand} {$basePath}/scripts/step-1b/src/main.py --path {$basePath}/storage/app/computation/input-1b.json --mode advice > {$basePath}/storage/app/computation/output-1b.json");

        $output1b =  file_get_contents(base_path('storage/app/computation/output-1b.json'), true);

        $this->archive->storeFile($output1b, 'round-1b-output.json');
    }

    public function getResultJson()
    {
        return $this->archive->getFile('round-1-result.json');
    }

    protected function generateResultJson()
    {
        $input =  file_get_contents(base_path('storage/app/computation/input.json'), true);
        $input = json_decode($input, true);

        $output =  file_get_contents(base_path('storage/app/computation/output.json'), true);
        $output = json_decode($output, true);


        $result = [];

        $result['stock'] = $input['stock'];
        $result['transactions'] = [];

        foreach($input['productDemand'] as $demand) {
            $result['transactions'][] = [
                'company_id' => $demand['company_id'],
                'demanded' => $demand['amount'],
                'received' => $output['rights'][$demand['company_id']],
            ];
        }

        $this->archive->storeFile(json_encode($result), 'round-1-result.json');
    }

    public function getPrediction()
    {
        $output =  file_get_contents(base_path('storage/app/computation/output-1b.json'), true);

        return explode("\n",$output)[0];
    }

}

