<?php

namespace App\Classes;

class CompanyTypes
{
    public const SUPPLIER = 1;
    public const MEDICAL = 2;

    public static function getTypes()
    {
        return self::getTypesArray();
    }

    public static function getLabel($type)
    {
        return isset(self::getTypesArray()[$type]) ? self::getTypesArray()[$type] : false;
    }

    protected static function getTypesArray()
    {
        return [
            self::SUPPLIER => __('Supplier'),
            self:: MEDICAL => __('Medical institution'),
        ];
    }
}
