<?php
namespace App\Classes;

use Carbon\Carbon;
use Illuminate\Session\Store;
use Illuminate\Support\Facades\Storage;

class Archive
{
    protected $token = false;

    protected $stockId = false;

    protected $path = '/archive';

    public function __construct($stockId)
    {
        $this->token = (new ArchiveToken())->getToken();

        $this->stockId = $stockId;
    }

    public function storeFile($contents, $name)
    {
        $directoryPath = $this->path . '/' . $this->token;

        if(!Storage::exists($directoryPath)) {
            Storage::makeDirectory($directoryPath);
        }

        $filename = $this->stockId . '_' . Carbon::now()->format('Y-m-d') . '_' . $this->token . '_' . $name;

        Storage::put($directoryPath . '/' . $filename, $contents);

    }

    public function getFile($filename, $token = false)
    {
        $directoryPath = $this->path . '/' . $this->token;

        $filePath = $directoryPath . '/' . $this->stockId . '_' . Carbon::now()->format('Y-m-d') . '_' . $this->token . '_' . $filename;

        if(!Storage::exists($filePath)) {
            return false;
        }

        return Storage::get($filePath);
    }
}
