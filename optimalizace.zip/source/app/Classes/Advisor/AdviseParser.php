<?php

namespace App\Classes\Advisor;

use App\Classes\Archive;

class AdviseParser {

    protected $advisedPrice = false;

    protected $advisedAmounts = [];

    protected $archive;

    public function __construct($stockId)
    {
        $this->archive = new Archive($stockId);

        $contents = explode("\n", $this->archive->getFile('round-1b-output.json'));

        // parsing price
        $priceLine = explode(':', $contents[0]);

        if(count($priceLine) > 1) {
            $price = $priceLine[1];

            $this->advisedPrice = (float) $price;
        } else {
            $this->advisedPrice = 0;
        }

        // parsing advised values

        for($line = 1; $line <= count($contents) - 1; $line++) {
            $advise = $contents[$line];

            $advise = explode('should buy', $advise);

            if(isset($advise[1])) {
                $subjectId = $this->getSubjectId($line - 1);

                $this->advisedAmounts[$subjectId] = (int) $advise[1];
            }
        }
    }

    public function getAdvisedPrice()
    {
        return $this->advisedPrice;
    }

    public function getAdviseSummary($id = false)
    {
        return $this->advisedAmounts;
    }

    public function getAdvisedAmount($id = false)
    {
        return isset($this->advisedAmounts[$id]) ? $this->advisedAmounts[$id] : false;

    }

    private function getSubjectId($order)
    {
        $contents = $this->archive->getFile('round-1-input.json');

        $contents = json_decode($contents, true);

        return $contents['productDemand'][$order]['company_id'];
    }
}
