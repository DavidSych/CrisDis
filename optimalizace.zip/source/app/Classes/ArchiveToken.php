<?php

namespace App\Classes;

use Illuminate\Support\Facades\Storage;
use Str;

class ArchiveToken {

    protected $token = false;

    protected $tokenPath = '/archive/.token';

    public function __construct()
    {
        if(!Storage::exists($this->tokenPath)) {
            $this->token = $this->generateToken();
        } else {
            $this->token = Storage::get($this->tokenPath);
        }
    }

    public function getToken()
    {
        if(!$this->token) {
            $this->token = $this->generateToken();
        }

        return $this->token;
    }

    protected function generateToken()
    {
        $str  = Str::random(20);

        Storage::put($this->tokenPath, $str);

        return $str;
    }

    public function deleteToken() {
        Storage::delete($this->tokenPath);
    }
}
