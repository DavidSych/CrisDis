<?php

namespace App\Classes;

use App\Models\Allowance;
use App\Models\Bid;
use App\Models\Company;
use App\Models\CrisisDemand;
use App\Models\CrisisSupply;

class AuctionDataPacker2 {

    protected $stock;

    protected $companiesInvolved;

    public function __construct($stock)
    {
        $this->stock = $stock;

        $this->companiesInvolved = collect([]);
    }

    public function pack()
    {
        return [
            'stock' => [
                'id' => $this->stock->id,
                'code' => $this->stock->code,
                'name' => $this->stock->name,
            ],
            'productDemand' => $this->getProductDemand(),
            'productSupply' => $this->getProductSupply(),
        ];
    }

    private function getProductDemand()
    {
        $demand = CrisisDemand::query()
            ->select('id', 'company_id', 'amount')
            ->where('stock_id', $this->stock->id)
            ->get();

        return $demand;
    }

    private function getProductSupply()
    {
        $supply = CrisisSupply::query()
            ->select('id', 'company_id', 'amount', 'price')
            ->where('stock_id', $this->stock->id)
            ->get();

        return $supply;
    }
}
