<?php

namespace App\Classes;

use App\Models\Allowance;
use App\Models\Bid;
use App\Models\Company;
use App\Models\CrisisSupply;

class AuctionDataPacker {

    protected $stock;

    protected $companiesInvolved;

    public function __construct($stock)
    {
        $this->stock = $stock;

        $this->companiesInvolved = collect([]);
    }

    public function pack()
    {
        return [
            'stock' => [
                'id' => $this->stock->id,
                'code' => $this->stock->code,
                'name' => $this->stock->name,
            ],
            'allowancesDemand' => $this->getDemand(),
            'allowancesSupply' => $this->getSupply(),
            'productDemand' => $this->getProductDemand(),
            'productSupply' => $this->getProductSupply(),
            'allowances' => $this->getAllowances(),
            'credit' => $this->getCredit(),
        ];
    }

    private function getProductDemand()
    {
        $bids = Bid::query()
            ->select('id', 'amount', 'price', 'company_id')
            ->where('type', 'product')
            ->where('stock_id', $this->stock->id)
            ->get();

        $this->companiesInvolved = $this->companiesInvolved->merge($bids->pluck('company_id')->unique());

        return $bids;
    }

    private function getProductSupply()
    {
        $supply = CrisisSupply::query()
            ->select('id', 'company_id', 'amount', 'price')
            ->where('stock_id', $this->stock->id)
            ->get();

        return $supply;
    }

    private function getDemand()
    {
        $bids = Bid::query()
            ->select('id', 'amount', 'price', 'company_id')
            ->where('type', 'buying')
            ->where('stock_id', $this->stock->id)
            ->get();

        $this->companiesInvolved = $this->companiesInvolved->merge($bids->pluck('company_id')->unique());

        return $bids;
    }

    private function getSupply()
    {
        $bids = Bid::query()
            ->select('id', 'amount', 'price', 'company_id')
            ->where('type', 'selling')
            ->where('stock_id', $this->stock->id)
            ->get();

        $this->companiesInvolved = $this->companiesInvolved->merge($bids->pluck('company_id')->unique());

        return $bids;
    }

    private function getAllowances()
    {
        return Allowance::query()
            ->where('stock_id', $this->stock->id)
            ->whereIn('company_id', $this->companiesInvolved)
            ->pluck('amount', 'company_id');
    }

    private function getCredit()
    {
        return Company::query()
            ->whereIn('id', $this->companiesInvolved)
            ->pluck('credit', 'id');
    }
}
