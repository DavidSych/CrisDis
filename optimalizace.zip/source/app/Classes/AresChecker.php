<?php

namespace App\Classes;

class AresChecker
{
    public function retrieveFromRegister($ic)
    {

        $ares_ico_fin = "";
        $ares_dic_fin = "";
        $ares_firma_fin = "";
        $ares_ulice_fin = "";
        $ares_cp1_fin   = "";
        $ares_cp2_fin   = "";
        $ares_mesto_fin = "";
        $ares_psc_fin   = "";
        $ares_stav_fin = "";

        $output = false;

        $file = @file_get_contents("http://wwwinfo.mfcr.cz/cgi-bin/ares/darv_bas.cgi?ico=". $ic);

        if($file)
        {
            $xml = @simplexml_load_string($file);
        }

        if($xml)
        {
            $ns = $xml->getDocNamespaces();
            $data = $xml->children($ns['are']);
            $el = $data->children($ns['D'])->VBAS;

            if (strval($el->ICO) == $ic)
            {
                $ares_ico_fin = strval($el->ICO);
                $ares_dic_fin = strval($el->DIC);
                $ares_firma_fin = strval($el->OF);
                $ares_ulice_fin = strval($el->AA->NU);
                $ares_cp1_fin   = strval($el->AA->CD);
                $ares_cp2_fin   = strval($el->AA->CO);
                if($ares_cp2_fin != ""){ $ares_cp_fin = $ares_cp1_fin."/".$ares_cp2_fin; }else{ $ares_cp_fin = $ares_cp1_fin; }
                $ares_mesto_fin = strval($el->AA->N);
                $ares_psc_fin   = strval($el->AA->PSC);
                $ares_stav_fin = 1;

                $output = [
                    'ares_dic_fin' => $ares_dic_fin,
                    'ares_firma_fin' => $ares_firma_fin,
                    'ares_cp1_fin' => $ares_cp1_fin,
                    'ares_ulice_fin' => $ares_ulice_fin,
                    'ares_mesto_fin' => $ares_mesto_fin,
                    'ares_psc_fin' => $ares_psc_fin,
                ];
            }
            else
            {
                $ares_stav_fin  = 'IČO firmy nebylo nalezeno';
            }
        }
        else
        {
            $ares_stav_fin  = 'Databáze ARES není dostupná';
        }

        return $output;
    }
}
