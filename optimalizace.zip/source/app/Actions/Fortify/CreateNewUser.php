<?php

namespace App\Actions\Fortify;

use App\Classes\AresChecker;
use App\Models\Company;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Laravel\Fortify\Contracts\CreatesNewUsers;
use Laravel\Jetstream\Jetstream;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array  $input
     * @return \App\Models\User
     */
    public function create(array $input)
    {
        Validator::make($input, [
            'name' => ['required', 'string', 'max:255'],
            'surname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'ic' => ['required', 'string', 'max:30'],
            'password' => $this->passwordRules(),
            'terms' => Jetstream::hasTermsAndPrivacyPolicyFeature() ? ['required', 'accepted'] : '',
        ])->validate();

        $user = User::create([
            'name' => $input['name'],
            'surname' => $input['surname'],
            'email' => $input['email'],
            'password' => Hash::make($input['password']),
            'active' => false,
            'new' => true,
        ]);

        $company = Company::where('ic', $input['ic'])->first();

        if($company) {
            $user->company_id = $company->id;

            $user->save();
        } else {
            $aresData = (new AresChecker)->retrieveFromRegister($input['ic']);

            if($aresData != false) {
                $company = new Company();

                $company->ic = $input['ic'];
                $company->name = $aresData['ares_firma_fin'];
                $company->dic = $aresData['ares_dic_fin'];
                $company->street = $aresData['ares_ulice_fin'];

                if($aresData['ares_cp1_fin']) {
                    $company->street = $company->street . ' ' . $aresData['ares_cp1_fin'];
                }

                $company->town = $aresData['ares_mesto_fin'];
                $company->zip = $aresData['ares_psc_fin'];

                $company->save();

                $user->company_id = $company->id;

                $user->save();
            }
        }

        return $user;
    }
}
