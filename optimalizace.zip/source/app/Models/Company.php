<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use HasFactory;

    protected $casts = [
        'credit' => 'float'
    ];

    public function inquiries()
    {
        return $this->hasMany(Inquiry::class);
    }

    public function offers()
    {
        return $this->hasMany(Offer::class);
    }

    public function users()
    {
        return $this->hasMany(User::class);
    }

    public function allowances()
    {
        return $this->hasMany(Allowance::class, 'company_id');
    }

    public function bidsSelling()
    {
        return $this->hasMany(Bid::class, 'company_id')->where('type', 'selling');
    }

    public function bidsBuying()
    {
        return $this->hasMany(Bid::class, 'company_id')->where('type', 'buying');
    }

    public function bidsProduct()
    {
        return $this->hasMany(Bid::class, 'company_id')->where('type', 'product');
    }

    public function portfolio()
    {
        return $this->belongsToMany(
            Stock::class,
            'portfolios',
            'company_id',
            'stock_id'
        );
    }

    public function getReservedCredit()
    {
        $bids = $this->bidsBuying;

        $sum = 0;

        foreach($bids as $bid) {
            $sum += $bid->amount * $bid->price;
        }

        return $sum;
    }

    public function getAvailableCredit()
    {
        return $this->credit - $this->getReservedCredit();
    }

    public function getAllowanceArray()
    {
        $inCrisisMode = Stock::where('crisis_mode', true)->pluck('id');

        return $this->allowances()
            ->whereIn('stock_id', $inCrisisMode)
            ->pluck('amount', 'stock_id');
    }

    public function getReservedAllowance($id)
    {
        return $this->bidsSelling()->where('stock_id', $id)->sum('amount');
    }

    public function getAvailableAllowance($id)
    {
        $allowance =  Allowance:: query()
            ->where('stock_id', $id)
            ->where('company_id', $this->id)
            ->first();

        if(!$allowance) {
            return 0;
        }

        return $allowance->amount - $this->getReservedAllowance($id);
    }

    public function isSupplier()
    {
        return $this->type === 1;
    }

    public function isHealthProvider()
    {
        return $this->type === 2;
    }
}
