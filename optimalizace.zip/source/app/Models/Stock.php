<?php

namespace App\Models;

use App\Classes\AuctionDataPacker;
use App\Classes\AuctionDataPacker2;
use App\Classes\InterimPriceDataPacker;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{
    use HasFactory;

    protected $fillable = ['id', 'name', 'code'];

    public function inquiries()
    {
        return $this->belongsToMany(Inquiry::class);
    }

    public static function importFromCsv($filename = false)
    {
        if(!$filename) {
            $filename = storage_path('app/material.csv');
        }

        $data = self::csvToArray($filename);

        for ($i = 0; $i < count($data); $i ++)
        {
            (new Stock())->firstOrCreate($data[$i]);
        }
    }

    public static function csvToArray($filename = '', $delimiter = ',')
    {
        if (!file_exists($filename) || !is_readable($filename))
            return false;

        $header = null;
        $data = array();
        if (($handle = fopen($filename, 'r')) !== false)
        {
            while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
            {
                if (!$header)
                    $header = $row;
                else
                    $data[] = array_combine($header, $row);
            }
            fclose($handle);
        }

        return $data;
    }

    public function generateAuctionData()
    {
        $dataPacker = new AuctionDataPacker($this);

        return $dataPacker->pack();
    }

    public function generateInterimPriceData()
    {
        $dataPacker = new InterimPriceDataPacker($this);

        return $dataPacker->pack();
    }

    public function generateAuctionData2()
    {
        $dataPacker = new AuctionDataPacker2($this);

        return $dataPacker->pack();
    }

    public function inMappingStage()
    {
        return $this->crisis_mode && $this->stage === 1;
    }

    public function inBiddingStage()
    {
        return $this->crisis_mode && $this->stage === 2;
    }

    public function inResultsStage()
    {
        return $this->crisis_mode && $this->stage === 3;
    }
}
