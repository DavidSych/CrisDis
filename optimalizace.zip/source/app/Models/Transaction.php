<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasFactory;

    public function seller()
    {
        return $this->belongsTo(Company::class, 'seller');
    }

    public function buyer()
    {
        return $this->belongsTo(Company::class, 'buyer');
    }

    public function stock()
    {
        return $this->belongsTo(Stock::class, 'stock_id');
    }
}
