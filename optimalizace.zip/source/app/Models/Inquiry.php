<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Inquiry extends Model
{
    use HasFactory;

    private $offersCount = false;

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function stock()
    {
        return $this->belongsToMany(Stock::class)->withPivot('id', 'amount', 'delivery_date', 'note');
    }

    public function offers()
    {
        return $this->hasMany(Offer::class);
    }

    public function activeOffers()
    {
        return $this->hasMany(Offer::class)->where('status', '>', 1);
    }

    public function getOffersCount()
    {
        if($this->offersCount) {
            return $this->offersCount;
        }

        $this->offersCount = Offer::query()
            ->where('status', '>', 1)
            ->where('inquiry_id', $this->id)
            ->count();

        return $this->offersCount;
    }
}
