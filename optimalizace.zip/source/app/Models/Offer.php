<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use function Composer\Autoload\includeFile;

class Offer extends Model
{
    use HasFactory;

    public function inquiry()
    {
        return $this->belongsTo(Inquiry::class);
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function isReadyToBePublished(): bool
    {
        $isReady = false;

        foreach($this->inquiry->stock as $stockItem) {
            $itemCount = OfferItem::query()
                ->where('offer_id', $this->id)
                ->where('inquiry_stock_id', $stockItem->pivot->id)
                ->count();

            // if partial offers are not allowed
            if(!$this->inquiry->allow_partial_offers) {
                if(!$itemCount)  {
                    return false;
                }
            }

            if($itemCount)  {
                $isReady = true;
            }
        }

        return $isReady;
    }

    public function getPriceRange()
    {
        $output = [
            'from' => 0,
            'to' => 0,
        ];

        foreach($this->inquiry->stock as $stockItem) {

            // get offer items
            $items = OfferItem::query()
                ->where('offer_id', $this->id)
                ->where('inquiry_stock_id', $stockItem->pivot->id)
                ->get();

            $amount = $stockItem->pivot->amount;
            $min = false;
            $max = 0;


            foreach($items as $item) {
                $price = $item->price * $amount;

                if($min == false) {
                    $min = $price;
                }

                if($min > $price) {
                    $min = $price;
                }

                if($max < $price) {
                    $max = $price;
                }
            }

            if($min !== false) {
                $output['from'] += $min;
            }

            if($max !== false) {
                $output['to'] += $max;
            }

        }

        return $output;
    }
}
