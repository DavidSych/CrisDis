<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CrisisSupply extends Model
{
    use HasFactory;

    protected $casts = [
        'price' => 'float'
    ];

    public function company()
    {
        return $this->belongsTo(Company::class, 'company_id');
    }

    public function stock()
    {
        return $this->belongsTo(Stock::class, 'stock_id');
    }
}
