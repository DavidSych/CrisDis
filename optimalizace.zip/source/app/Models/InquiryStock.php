<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InquiryStock extends Model
{
    use HasFactory;

    protected $table = 'inquiry_stock';

    public function stock()
    {
        return $this->belongsTo(Stock::class);
    }

    public function inquiry()
    {
        return $this->belongsTo(Inquiry::class);
    }

    public function updateAmount($amount)
    {
        $this->amount = $amount;

        $this->save();
    }

    public function updateDeliveryDate($deliveryDate)
    {
        $this->delivery_date = $deliveryDate ?: null;

        $this->save();
    }
}
