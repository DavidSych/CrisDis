<?php

namespace App\Console\Commands;

use App\Models\Allowance;
use App\Models\Bid;
use App\Models\Transaction;
use Illuminate\Console\Command;

class ResolveMarket extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cridis:resolver';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $bids = Bid::query()
            ->with('company')
            ->where('type', 'buying')
            ->orderBy('created_at')
            ->get();

        foreach($bids as $bid) {

            $resolvedBy = Bid::query()
                ->with('company')
                ->where('type', 'selling')
                ->where('stock_id', $bid->stock_id)
                ->where('company_id', '!=', $bid->company_id)
                ->where('amount', '>=', $bid->amount)
                ->where('price', '<=', $bid->price)
                ->orderBy('created_at')
                ->first();


            if($resolvedBy) {

                $allowance = Allowance::firstOrNew([
                    'stock_id' => $bid->stock_id,
                    'company_id' => $bid->company->id,
                ]);

                $allowance->amount += $bid->amount;

                $allowance->save();

                $allowance = Allowance::firstOrNew([
                    'stock_id' => $bid->stock_id,
                    'company_id' => $resolvedBy->company->id,
                ]);

                $allowance->amount -=    $bid->amount;

                $allowance->save();

                $bid->company->credit -= $resolvedBy->price * $bid->amount;

                $bid->company->save();

                $resolvedBy->company->credit += $resolvedBy->price * $bid->amount;

                $resolvedBy->company->save();

                $bid->delete();

                if($resolvedBy->amount == $bid->amount) {
                    $resolvedBy->delete();
                } else {
                    $resolvedBy->amount -= $bid->amount;

                    $resolvedBy->save();
                }

                $trade = new Transaction();

                $trade->stock_id = $bid->stock_id;
                $trade->seller = $resolvedBy->company->id;
                $trade->buyer = $bid->company->id;
                $trade->amount = $bid->amount;
                $trade->price = $resolvedBy->price;

                $trade->save();
            }
        }
    }
}
