## CrisDis test portal

CrisDis test portal is built using PHP and is based on the Laravel framework. It is possible to run it on various web servers and databases. Please check setup requirements at the [Laravel documentation](https://laravel.com/docs/8.x)

This version was tested using Apache web server and MySQL database, but should work also on other environments.

To install the application locally, please run:

- `composer install` to install all dependencies
- `php artisan migrate --seed` to create the required database structure (modify admin user in the seed file as needed)
- copy file `.env.example` to `.env` and fill in your environment data

As the test portal includes external python scripts for the evaluation of crisis management phases, the application server should have the rights to run console scripts and Python with required libraries should be present on the server.
