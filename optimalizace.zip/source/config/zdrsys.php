<?php
return [
    'dateFormat' => 'd.n.Y',

    'roles' => [
        'provider' => 'Provider',
        'admin' => 'Administrator',
        'demo' => 'Demo',
        'super-admin' => 'Sudo administrator',
    ],

    'python_command' =>  env('PYTHON_COMMAND', 'python'),
];
