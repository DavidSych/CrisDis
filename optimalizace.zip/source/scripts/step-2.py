import json
import numpy as np
# from parser_project import *

## Parsing

# Each bid and each offers are defined by a: company_id, an amount and a price.
# Supply
def get_offered_supply(data):
    return [[offer["company_id"], offer['amount'], offer['price']] for offer in data['productSupply']]

def get_desired_supply(data):
    return [[offer["company_id"], offer['amount'], offer['price']] for offer in data['productDemand']]

# Rights
def get_offered_rights(data):
    return [[offer["company_id"], offer['amount'], offer['price']] for offer in data['allowancesSupply']]

def get_desired_rights(data):
    return [[offer["company_id"], offer['amount'], offer['price']] for offer in data['allowancesDemand']]

def get_wallet(data):
    return [[int(id), data["allowances"][id], data["credit"][id]] for id in data["credit"]]

def results_json(data, sold_supply, bought_supply, sold_rights, bought_rights, buyer_wallet):
    for offer_supply in range(len(data["productSupply"])):
        data["productSupply"][offer_supply]["volume_sold"] = int(sold_supply[offer_supply, 0])
        data["productSupply"][offer_supply]["credit_earned"] = int(sold_supply[offer_supply, 1])

    for offer_right in range(len(data["allowancesSupply"])):
        data["allowancesSupply"][offer_right]["volume_sold"] = int(sold_rights[offer_right, 0])
        data["allowancesSupply"][offer_right]["credit_earned"] = int(sold_rights[offer_right, 1])
        id = int(data["allowancesSupply"][offer_right]["company_id"])
        buyer_wallet[np.argwhere(buyer_wallet[:,0] == id)[0][0]][2] += int(sold_rights[offer_right, 1])

    for bid_supply in range(len(data["productDemand"])):
        data["productDemand"][bid_supply]["volume_bought"] = int(bought_supply[bid_supply, 0])
        data["productDemand"][bid_supply]["credit_used"] = int(bought_supply[bid_supply, 1])

    for bid_right in range(len(data["allowancesDemand"])):
        data["allowancesDemand"][bid_right]["volume_bought"] = int(bought_rights[bid_right, 0])
        data["allowancesDemand"][bid_right]["credit_used"] = int(bought_rights[bid_right, 1])

    for company in buyer_wallet:
        id = company[0]
        rights = company[1]
        credit = company[2]

        data["allowances"][str(id)] = int(rights)
        data["credit"][str(id)] = int(credit)

    return json.dumps(data)

## Algorithm

"""
The algorithm works as follows:

Take buyers in random order:
    Look at the sellers in ascending order of price:
        If a transaction is possible: trade.
        If the buyer needs rights:
            Look at the right offers in ascending order of price:
                If a transaction is possible: trade with both the seller and the right owner.
"""
def greedy_algorithm(data_json):
    data = json.loads(data_json)

#     0 = company ID, 1 = amount, 2 = unit price
    offered_supply = np.array(get_offered_supply(data))
    desired_supply = np.array(get_desired_supply(data))

    offered_rights = np.array(get_offered_rights(data))
    desired_rights = np.array(get_desired_rights(data))

#   0 = volume, 1 = price
    sold_supply = np.zeros(shape=(len(offered_supply), 2))
    bought_supply = np.zeros(shape=(len(desired_supply), 2))

    #sold_rights = np.zeros(shape=(len(desired_rights), 2))
    sold_rights = np.zeros(shape=(len(offered_rights), 2))
    bought_rights = np.zeros(shape=(len(desired_rights), 2))

#   0 = company id, 1 = rights, 2 = money
    buyer_wallet = np.array(get_wallet(data))

    for supply_bid_id in np.random.permutation(len(desired_supply)):

        buyer_company_id = desired_supply[supply_bid_id][0]
        buyer_company_id_wallet = np.argwhere(buyer_wallet[:,0] == buyer_company_id)[0][0]

        right_order = np.argsort(offered_rights[:,2])

        for right_seller_id in right_order:

            # The buyer will pick the best offer first.
            supply_order = np.argsort(offered_supply[:,2])
            for seller_id in supply_order:

                # If the price of the supply offer is above the price of the supply bid, we pass to next offer.
                if desired_supply[supply_bid_id, 2] < offered_supply[seller_id, 2]:
                    continue

                # First buy what you have Rights for.
                right_volume = buyer_wallet[buyer_company_id_wallet,1]

                # We calculate the volume of supply the supply bid can buy from the supply offer without buying any right.
                leftover_volume_supply = offered_supply[seller_id, 1] - sold_supply[seller_id, 0]
                still_desired_volume_supply = desired_supply[supply_bid_id, 1] - bought_supply[supply_bid_id, 0]

                if offered_supply[seller_id, 2] > 0:
                    affordable_vol = buyer_wallet[buyer_company_id_wallet, 2] // offered_supply[seller_id, 2]
                    vol_to_buy = min(affordable_vol, right_volume, leftover_volume_supply, still_desired_volume_supply)
                else:
                    vol_to_buy = min(right_volume, leftover_volume_supply, still_desired_volume_supply)

                if vol_to_buy > 0:
                    # We execute the transaction.
                    sold_supply[seller_id, 0] += vol_to_buy
                    bought_supply[supply_bid_id, 0] += vol_to_buy

                    money_to_pay = vol_to_buy * offered_supply[seller_id,2]
                    sold_supply[seller_id, 1] += money_to_pay
                    bought_supply[supply_bid_id, 1] += money_to_pay

                    buyer_wallet[buyer_company_id_wallet, 2] -= money_to_pay
                    buyer_wallet[buyer_company_id_wallet, 1] -= vol_to_buy


                # Second, if you still want more, buy the same volume of Rights and Goods
                # You cannot buy right from yourself.
                if desired_supply[supply_bid_id, 0] == offered_rights[right_seller_id, 0]:
                    continue

                # Buyer will first try to buy for the lower price of his bids.
                right_bids = np.argwhere(desired_rights[:, 0] == buyer_company_id).flatten()
                right_bids_odered = right_bids[np.argsort(desired_rights[right_bids, 2])]

                for right_bid in right_bids_odered:
                    if desired_rights[right_bid, 2] < offered_rights[right_seller_id, 2]:
                        continue

                    leftover_volume_rights = offered_rights[right_seller_id,1] - sold_rights[right_seller_id, 0]
                    still_desired_volume_rights = desired_rights[right_bid, 1] - bought_rights[right_bid, 0]

                    leftover_volume_supply = offered_supply[seller_id,1] - sold_supply[seller_id, 0]
                    still_desired_volume_supply = desired_supply[right_bid,1] - bought_supply[right_bid, 0]

                    # We calculate the volume of supply the supply bid will buy from the supply offer with rights.
                    if offered_supply[seller_id, 2] + offered_rights[right_seller_id, 2] > 0:
                        affordable_vol = buyer_wallet[buyer_company_id_wallet, 2] // (offered_supply[seller_id, 2] + offered_rights[right_seller_id, 2])
                        vol_to_buy = min(affordable_vol, leftover_volume_supply, still_desired_volume_supply, leftover_volume_rights, still_desired_volume_rights)
                    else:
                        vol_to_buy = min(right_volume, leftover_volume_supply, still_desired_volume_supply, leftover_volume_rights, still_desired_volume_rights)

                    if vol_to_buy > 0:
                        # We execute the transaction.
                        sold_supply[seller_id, 0] += vol_to_buy
                        bought_supply[supply_bid_id, 0] += vol_to_buy
                        sold_rights[right_seller_id, 0] += vol_to_buy
                        bought_rights[right_bid, 0] += vol_to_buy

                        money_to_pay_supply = vol_to_buy * offered_supply[seller_id, 2]
                        sold_supply[seller_id, 1] += money_to_pay_supply
                        bought_supply[supply_bid_id, 1] += money_to_pay_supply
                        buyer_wallet[buyer_company_id_wallet, 2] -= int(money_to_pay_supply)

                        money_to_pay_rights = vol_to_buy * offered_rights[right_seller_id, 2]
                        sold_rights[right_seller_id, 1] += money_to_pay_rights
                        bought_rights[right_bid, 1] += money_to_pay_rights
                        buyer_wallet[buyer_company_id_wallet, 2] -= int(money_to_pay_rights)

                        # they get the money only after the trades
                        # buyer_money[right_seller_id, 2] += money_to_pay_rights
                        # buyer_wallet[right_seller_id, 1] -= vol_to_buy
    return results_json(data, sold_supply, bought_supply, sold_rights, bought_rights, buyer_wallet)


with open('../storage/app/computation/input-2.json', 'r') as file:
    data_json = file.read().replace('\n', '')

print(greedy_algorithm(data_json))
