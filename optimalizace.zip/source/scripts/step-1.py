import numpy as np
import json


## Distribution functions

# Each participant lose an equal amount of their demand, but cannot receive less than 0.
def ConstrainedEqualLosses(total_estate, demand_array):
    sorted_idx = np.argsort(demand_array)
    distribution = np.array(demand_array, copy=True, dtype=np.float64)

    while np.sum(distribution) > total_estate and len(sorted_idx) > 0:
        distribution[sorted_idx] -= min(distribution[sorted_idx[0]], (np.sum(distribution) - total_estate) / len(sorted_idx))
        sorted_idx = sorted_idx[1:]
    return distribution

# Each participant receive either his demand or no one receive more than him.
def ConstrainedEqualAwards(total_estate, demand_array):
    total_demand = np.sum(demand_array)
    sorted_idx = np.argsort(demand_array)
    distribution = np.zeros(len(demand_array))

    while np.sum(distribution) < total_demand and len(sorted_idx) > 0:
        distribution[sorted_idx] += min(demand_array[sorted_idx[0]], (total_estate - np.sum(distribution)) / len(sorted_idx))
        sorted_idx = sorted_idx[1:]
    return distribution

def ContestedGarmentDistribution(total_estate, demand_array):
    half_demand = np.array(demand_array) / 2
    # If the total estate is lower than half the demand, then we use the constrained equal awards on half the demand.
    if np.sum(demand_array) > 2*total_estate:
        return ConstrainedEqualAwards(total_estate, half_demand)
    # Else, give the participants half their claims and use the constrained equal losses on the remaining estate.
    return half_demand + ConstrainedEqualLosses(total_estate - np.sum(half_demand), half_demand)

## Parsing Json

# Return the sum of the supply.
def get_total_supply(data):
    return sum([supplier["amount"] for supplier in data["productSupply"]])

# Return two arrays, one with the different company_id and the other one with their corresponding demands.
def get_demands_and_id(data):
    company_id_array = np.unique([buyer["company_id"] for buyer in data["productDemand"]])
    demands_array = [sum([id["amount"] for id in data["productDemand"] if id["company_id"] == buyer]) for buyer in company_id_array]
    return company_id_array, demands_array

def create_json(distribution, id_array):
    d = dict()
    for i in range(len(distribution)):
        d[str(id_array[i])] = distribution[i]
    rights=dict()
    rights["rights"] = d
    return json.dumps(rights)

def get_rights_distribution_from_json(data_json):
    data = json.loads(data_json)
    total_supply = get_total_supply(data)
    id_array, demands = get_demands_and_id(data)
    distribution = ContestedGarmentDistribution(total_supply, demands)
    return create_json(distribution, id_array)

## Example
#data_json = '{"stock":{"id":9,"code":"M9","name":"jehla injek\u010dn\u00ed modr\u00e1 0,6x25 mm"},"productDemand":[{"id":1,"company_id":1,"amount":3000},{"id":1,"company_id":1,"amount":100},{"id":1,"company_id":2,"amount":100}],"productSupply":[{"id":1,"company_id":1,"amount":600,"price":200}, {"id":1,"company_id":1,"amount":600,"price":300}, {"id":1,"company_id":2,"amount":100,"price":200}]}'
#print(get_rights_distribution_from_json(data_json))

with open('../storage/app/computation/input.json', 'r') as file:
    data_json = file.read().replace('\n', '')

print(get_rights_distribution_from_json(data_json))

