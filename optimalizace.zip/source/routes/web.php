<?php

use App\Classes\Archive;
use App\Classes\Processors\RoundOne;
use App\Http\Controllers\AdminConsoleController;
use App\Http\Controllers\AuctionController;
use App\Http\Controllers\CompaniesController;
use App\Http\Controllers\GeneratorController;
use App\Http\Controllers\InquiriesController;
use App\Http\Controllers\OffersController;
use App\Http\Controllers\OpenInquiriesController;
use App\Http\Controllers\ProductsController;
use App\Http\Controllers\StockController;
use App\Http\Controllers\StockCrisisController;
use App\Http\Controllers\UsersController;
use App\Models\Stock;
use App\Models\User;
use Illuminate\Support\Facades\Route;

function format_czk ($number) {
    return number_format($number, '2', ',', ' ');
}

function format_czech ($number) {
    return number_format($number, '0', ',', ' ');
}


function format_date ($date) {
    if(!$date) {
        return '';
    }

    return date('j.n.Y', strtotime($date));
}

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::middleware(['auth:sanctum', 'verified'])->group(function() {

    /**
     * Users
     */
    Route::get('/users', [UsersController::class, 'index'])->name('users');
    Route::get('/users/{id}/update', [UsersController::class, 'update'])->name('users.update');


    /**
     * Contacts
     */
    Route::get('/companies', [CompaniesController::class, 'index'])->name('companies');
    Route::get('/companies/{id}/update', [CompaniesController::class, 'update'])->name('companies.update');

    /**
     * Inquiries
     */
    Route::get('/inquiries', [InquiriesController::class, 'index'])->name('inquiries');
    Route::get('/inquiries/create', [InquiriesController::class, 'create'])->name('inquiries.create');
    Route::get('/inquiries/{id}/update', [InquiriesController::class, 'update'])->name('inquiries.update');
    Route::get('/inquiries/{id}/save', [InquiriesController::class, 'save'])->name('inquiries.save');
    Route::get('/inquiries/{id}/preview', [InquiriesController::class, 'preview'])->name('inquiries.preview');
    Route::post('/inquiries/{id}/make-public', [InquiriesController::class, 'makePublic'])->name('inquiries.make-public');

    /**
     * Open Inquiries
     */
    Route::get('/open-inquiries', [OpenInquiriesController::class, 'index'])->name('open-inquiries');
    Route::get('/open-inquiries/{id}/detail', [OpenInquiriesController::class, 'detail'])->name('open-inquiries.detail');

    /**
     * Offers
     */
    Route::get('/offers', [OffersController::class, 'index'])->name('offers');
    Route::get('/offers/create/{inquiryId}', [OffersController::class, 'create'])->name('offers.create');
    Route::get('/offers/{id}/update', [OffersController::class, 'update'])->name('offers.update');
    Route::post('/offers/{id}/submit', [OffersController::class, 'submit'])->name('offers.submit');
    Route::get('/offers/{id}/preview', [OffersController::class, 'preview'])->name('offers.preview');


    /**
     * Stock
     */
    Route::get('/stock-overview', [StockController::class, 'index'])->name('stock-overview');
    Route::get('/stock', [StockController::class, 'portfolio'])->name('stock');
    Route::get('/stock-crisis', [StockCrisisController::class, 'index'])->name('stock-crisis');
    Route::get('/stock-crisis/manage/{id}', [StockCrisisController::class, 'manage'])->name('stock-crisis-manage');

    /**
     * Products
     */
    Route::get('/products', [ProductsController::class, 'index'])->name('products');

    /**
     * Products
     */
    Route::get('/auction', [AuctionController::class, 'index'])->name('auction');
    Route::get('/auction/article/{stock}', [AuctionController::class, 'article'])->name('auction.stock');

    /**
     * Generator
     */
    Route::get('/generator', [GeneratorController::class, 'index'])->name('generator');

    Route::impersonate();

    /**
     * Admin console
     */
    Route::get('/admin-console', [AdminConsoleController::class, 'index'])->name('admin-console');

    Route::impersonate();

    /**
     * JSON helper
     */
    Route::get('/generate-json/{stock}', function(Stock $stock) {

        $output = $stock->generateAuctionData();

        return response()->json($output);
    });

    Route::get('/generate-json-1b/{stock}', function(Stock $stock) {

        $output = $stock->generateInterimPriceData();

        return response()->json($output);
    });

    Route::get('/generate-json-2/{stock}', function(Stock $stock) {

        $output = $stock->generateAuctionData2();

        return response()->json($output);
    });

    Route::get('/generate-result/{stock}', function($stock) {
        $roundOneProcessor = new RoundOne($stock);

        $result = $roundOneProcessor->getResultJson();

        return response()->json(json_decode($result));
    });

    Route::get('/generate-result-2/{stock}', function($stock) {
        $roundOneProcessor = new \App\Classes\Processors\RoundTwo($stock);

        $result = $roundOneProcessor->getResultJson();

        return response()->json(json_decode($result));
    });
});

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {

    $newUsers = User::where('new', 1)->get();

    return view('dashboard', [
        'newUsers' => $newUsers,
    ]);
})->name('dashboard');


/* NAVIGATOR SHOWCASE */
Route::get('/navigator', function () {
    return view('navigator');
});

Route::get('/navigator/data', function () {
    $this->pythonCommand = config('zdrsys.python_command');

    $basePath = base_path();

    exec("{$this->pythonCommand} {$basePath}/scripts/step-1b/src/main.py --path {$basePath}/scripts/step-1b/data/test.json --mode advice > {$basePath}/storage/app/computation/test.json");

    $result =  file_get_contents(base_path('storage/app/computation/test.json'), true);

    return $result;
});
