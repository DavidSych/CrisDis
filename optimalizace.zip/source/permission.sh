#!/bin/sh
php artisan db:seed --class=PermissionsSeeder
