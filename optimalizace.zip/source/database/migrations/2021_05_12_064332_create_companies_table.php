<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCompaniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->id();

            $table->string('name')->nullable();
            $table->string('url')->nullable();
            $table->string('ic', 30)->nullable();
            $table->string('dic', 30)->nullable();

            $table->string('phone', 100)->nullable();
            $table->string('fax', 100)->nullable();
            $table->string('email', 255)->nullable();

            $table->boolean('type')->default(0);

            $table->string('street')->nullable();
            $table->string('town')->nullable();
            $table->string('zip')->nullable();
            $table->string('country')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('companies');
    }
}
