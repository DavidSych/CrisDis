<?php
namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Psy\Util\Str;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class PermissionsSeeder extends Seeder
{
    /**
     * Create the initial roles and permissions.
     *
     * @return void
     */
    public function run()
    {
        // Reset cached roles and permissions
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        DB::table('role_has_permissions')->delete();
        DB::table('roles')->delete();
        DB::table('permissions')->delete();

        // create permissions
        Permission::create(['name' => 'view users']);
        Permission::create(['name' => 'edit user']);

        Permission::create(['name' => 'view companies']);
        Permission::create(['name' => 'edit company']);

        Permission::create(['name' => 'manage stock']);


        // create roles and assign existing permissions
        $role2 = Role::create(['name' => 'provider']);

        // create roles and assign existing permissions
        $roleDemo = Role::create(['name' => 'demo']);
        $roleDemo->givePermissionTo('view companies');
        $roleDemo->givePermissionTo('edit company');
        $roleDemo->givePermissionTo('manage stock');

        // create roles and assign existing permissions
        $role1 = Role::create(['name' => 'admin']);
        $role1->givePermissionTo('view users');
        $role1->givePermissionTo('edit user');
        $role1->givePermissionTo('view companies');
        $role1->givePermissionTo('edit company');
        $role1->givePermissionTo('manage stock');


        $role3 = Role::create(['name' => 'super-admin']);
        // gets all permissions via Gate::before rule; see AuthServiceProvider

        $user = User::find(1);

        $user->assignRole($role1);
    }
}
