<?php

namespace Database\Seeders;

use App\Models\Stock;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {

        $user = new User();
        $user->name = 'Demo';
        $user->surname = 'Admin';
        $user->active = 1;
        $user->email = 'admin@example.com';
        $user->remember_token = Str::random(10);
        $user->password = Hash::make('secret');
        $user->company_id = 1;
        $user->save();

        (new PermissionsSeeder())->run();

        $user->syncRoles('admin');

        \App\Models\Company::factory(1)->create([
            'name' => 'Test Company'
        ]);

        \App\Models\Company::factory(30)->create();

        Stock::importFromCsv();

    }
}
