# Zásady ochrany osobních údajů
## INFORMACE O ZPRACOVÁNÍ OSOBNÍCH ÚDAJŮ PŘI používání předběžného informačního portálu pro distribuci drobného zdravotnického materiálu („PIP“)
### Úvod

PIP je platforma pro provádění předběžných tržních konzultací podle ust. § 33 zákona č. 134/2016 Sb., o zadávání veřejných zakázek, ve znění pozdějších předpisů. Uživatelé používají PIP skrze zřízené uživatelské účty na základě uživatelské smlouvy. Nedílnou součástí uživatelské smlouvy jsou Všeobecné obchodní podmínky používání předběžného informačního portálu pro distribuci drobného zdravotnického materiálu („PIP“)1 obsahující popis vzájemných práv a povinností mezi provozovatelem PIP a uživateli.

Prostřednictvím PIP jsou shromažďovány a dále analyticky zpracovávány primárně údaje o poptávkách a nabídkách zdravotnických prostředků, o nákupech zdravotnických prostředků, o uživatelích, jež jsou převážně právnickými osobami (zejména údaje o nemocnicích, ordinacích a dodavatelích zdravotnických prostředků), trendech a zásobách, čili údaje, jež nejsou osobními údaji ve smyslu ust. čl. 4 bodu 1) nařízení Evropského parlamentu a Rady (EU) 2016/679 ze dne 27. dubna 2016 o ochraně fyzických osob v souvislosti se zpracováním osobních údajů a o volném pohybu těchto údajů a o zrušení směrnice 95/46/ES (obecné nařízení o ochraně osobních údajů; dále též „**GDPR**“). To však neznamená, že se mezi zpracovávanými prostřednictvím PIP údaji nemohou objevit osobní údaje, tj. určité informace o identifikované nebo identifikovatelné fyzické osobě jakožto subjektu údajů2 (např. fyzické osoby zastupující uživatele PIP). Mezi zpracovávané osobní údaje patří identifikační a kontaktní údaje (např. jméno, příjmení, funkce jednající nebo kontaktní osoby, e-mailová adresa, telefonní číslo, atd.), nikoli však zvláštní kategorie osobních údajů ve smyslu ust. čl. 9 GDPR.

[…] si Vás tímto dovoluje informovat o způsobu a rozsahu zpracování osobních údajů, včetně rozsahu Vašich práv, jakožto subjektu údajů, souvisejících se zpracováním Vašich osobních údajů dle GDPR.

### 1. Kdo je správcem vašich osobních údajů?

Správcem osobních údajů je […] se sídlem […], Česká republika, IČO: […], zapsaná/ý v […] rejstříku vedeném […] soudem v […] pod spisovou značkou […], telefonní číslo: […], e-mail: […] (dále též "**Provozovatel PIP**").

### 2. Jaké osobní údaje zpracováváme, v jakém rozsahu a pro jaké účely?

Zpracováváme pouze ty osobní údaje a v takovém rozsahu, abychom mohli splnit uživatelskou smlouvu uzavřenou s uživatelem, jejímž předmětem je používání PIP, zejména zřídit uživateli uživatelský účet, zpřístupnit PIP a umožnit uživateli používat veškeré funkcionality, kterými je PIP vybaven (zejména funkcionality umožňující provádění předběžných tržních konzultací).  

Osobní údaje zpracováváme pro účely našich oprávněných zájmů či oprávněných zájmů uživatele, který Vaše osobní údaje poskytl.  

Toto zpracování je založeno na oprávněném zájmu dle čl. 6 odst. 1 písm. f) GDPR.

Poskytnutí osobních údajů o zástupci/kontaktní osobě uživatele (zejména jména a příjmení) je smluvním požadavkem. Bez těchto osobních údajů nelze registraci a zřízení uživatelského účtu úspěšně provést.

### 3. Probíhá automatické zpracování Vašich osobních údajů?

Osobní údaje, k jejichž zpracování jsme oprávněni, nebudou použity k rozhodování čistě na bázi automatizovaného zpracování, ani profilování.

### 4. Kdo zpracovává vaše osobní údaje?

Osobní údaje zpracovává přímo příslušný uživatel, Provozovatel PIP nebo vybraní zpracovatelé, jež rovněž poskytují dostatečné a věrohodné záruky o  zabezpečení ochrany Vašich osobních údajů (např. poskytovatel cloudových služeb, poskytovatelé IT služeb a služeb v oblasti bezpečnosti, poskytovatelé analytických služeb a jiní dodavatelé).  

Dále mohou být Vaše osobní údaje za určitých podmínek zpřístupněny státním orgánům v rámci výkonu jejich zákonných pravomocí nebo je můžeme přímo poskytnout jiným subjektům v rozsahu stanoveném zvláštním zákonem. Osobní údaje v zákonem stanoveném rozsahu mohou být také předány pojišťovnám.

Osobní údaje nejsou předávány do zemí mimo Evropskou unii, resp. Evropský hospodářský prostor.

### 5. jakým způsobem zajištujeme ochranu vašich osobních údajů?

Uplatňujeme opatření nezbytná k bezpečnému uchování informací v elektronické nebo fyzické podobě, a k zabránění neoprávněnému přístupu, změnám či zveřejnění informací. Zabezpečení informací jsou podporovány řadou bezpečnostních standardů, procesů a postupů. Informace ukládáme v prostorách s omezeným přístupem nebo v elektronických databázích vyžadujících přihlašovací údaje a hesla. Požadujeme, aby poskytovatelé datových úložišť a jiní zpracovatelé splňovali příslušné standardy průmyslového zabezpečení. Všichni partneři, zaměstnanci a poskytovatelé služeb, kteří mají přístup k důvěrným informacím, podléhají povinnosti mlčenlivosti.

### 6. Po jakou dobu Vaše osobní údaje uchováváme?

Osobní údaje uchováváme jen po dobu nezbytnou pro naplnění stanoveného účelu. Vaše osobní údaje zpracováváme po dobu trvání uživatelské smlouvy uzavřené mezi provozovatelem PIP a uživatelem, který Vaše osobní údaje poskytl (tj. po dobu trvání registrace a uživatelského účtu uživatele, který Vaše osobní údaje poskytl) a po dobu čtyř (4) let od ukončení uživatelské smlouvy (od zrušení uživatelského účtu), případně po delší dobu, bude-li to nezbytné pro určení, výkon nebo obhajobu našich právních nároků.

### 7. Jaká práva máte v souvislosti se zpracováním Vašich osobních údajů?
   
 
**Právo na informace o zpracování a přístup k Vašim osobním údajům**

Máte právo od nás získat potvrzení, zda osobní údaje, které se Vás týkají, jsou či nejsou zpracovávány, a pokud je tomu tak, máte právo získat přístup k těmto osobním údajům a k dalším informacím o zpracování. Máte rovněž právo na poskytnutí kopií zpracovávaných osobních údajů.

**Právo na opravu**

Máte právo na to, abychom bez zbytečného odkladu opravili nepřesné osobní údaje, které se Vás týkají, případně doplnili neúplné osobní údaje. Informujte nás, prosím, o všech změnách týkajících se Vašich osobních údajů na níže uvedené adrese.

**Právo na omezení zpracování**

Jakožto subjekt údajů máte právo na to, abychom omezili zpracování Vašich osobních údajů pokud:

- popíráte přesnost osobních údajů, které o Vás zpracováváme, a to na dobu potřebnou k tomu, abychom mohli přesnost Vašich osobních údajů ověřit;
- zpracování Vašich osobních údajů je protiprávní, ale Vy odmítáte jejich výmaz a žádáte místo toho o omezení jejich použití;
- zpracování Vašich osobních údajů již není z naší strany potřebné, ale Vy je požadujete pro určení, výkon nebo obhajobu svých právních nároků; nebo
- jste vznesl/a námitku proti zpracování osobních údajů na základě zejména oprávněných zájmů, včetně profilování, dokud nebude ověřeno, zda naše oprávněné důvody převažují nad Vašimi oprávněnými důvody.
   
Pokud bylo zpracování omezeno na základě některého z výše uvedených důvodů, mohou být dotčené osobní údaje, s výjimkou jejich uložení, zpracovávány pouze s Vaším souhlasem, nebo z důvodu určení, výkonu nebo obhajoby právních nároků, z důvodu ochrany jiné fyzické nebo právnické osoby nebo z důvodu důležitého veřejného zájmu Evropské unie nebo některého členského státu Evropské unie. O zrušení omezení zpracování Vašich osobních údajů jsme povinni Vás předem informovat.

**Právo vznést námitku**
 
Domníváte-li se, že zpracování osobních údajů probíhá v rozporu s ochranou Vašeho soukromí nebo v rozporu s právními předpisy, máte právo vznést námitku proti zpracování osobních údajů, které se Vás týkají, na základě zejména oprávněných zájmů [čl. 6 odst. 1 písm. e) nebo f) GDPR], včetně profilování. Stejně tak můžete vznést námitku proti automatizovanému rozhodování.

**Právo na přenositelnost**

Máte právo získat Vaše osobní údaje ve strukturovaném, běžně používaném a strojově čitelném formátu a právo předat tyto údaje jinému správci tak, aby osobní údaje byly předány přímo druhému správci, je-li to technicky proveditelné.
   
**Právo na výmaz**

Máte právo na to, abychom bez zbytečného odkladu vymazali osobní údaje, které se Vás týkají, pokud je splněna alespoň jedna z následujících podmínek:

- osobní údaje již nejsou potřebné pro účely, pro které byly shromážděny nebo jinak zpracovány,
- odvoláte souhlas se zpracováním Vašich osobních údajů a na naší straně neexistuje žádný další právní důvod pro jejich zpracování,
- vznesete námitky proti zpracování Vašich osobních údajů a na naší straně neexistují žádné převažující oprávněné důvody pro zpracování,
- osobní údaje byly zpracovávány protiprávně,
- osobní údaje musí být vymazány ke splnění naší právní povinnosti,
- osobní údaje byly shromážděny v souvislosti s nabídkou služeb informační společnosti.

Výše uvedené podmínky se neuplatní, pokud je zpracování osobních údajů nezbytné:

- pro výkon práva na svobodu projevu a informace;
- pro splnění právní povinnosti, jež vyžaduje zpracování podle práva Evropské unie nebo členského státu Evropské unie, které se na nás vztahuje, nebo pro splnění úkolu provedeného ve veřejném zájmu nebo při výkonu veřejné moci, kterým jsme pověřeni;
- z důvodu veřejného zájmu v oblasti veřejného zdraví;
- pro účely archivace ve veřejném zájmu, pro účely vědeckého či historického výzkumu či pro statistické účely, pokud je pravděpodobné, že by právo na výmaz znemožnilo nebo vážně ohrozilo splnění cílů uvedeného zpracování; nebo
- pro určení, výkon nebo obhajobu právních nároků.

**Právo odvolat souhlas**

Pokud zpracováváme osobní údaje na základě Vašeho souhlasu, můžete takový souhlas kdykoli odvolat. Odvoláním tohoto souhlasu však není dotčena zákonnost zpracování osobních údajů založená na tomto souhlasu před jeho odvoláním. Odvolat souhlas lze kdykoli písemně zasláním e-mailu nebo dopisu na kontaktní adresu uvedenou níže.

**Právo podat podnět nebo stížnost**

V případě pochybností o dodržování povinností souvisejících se zpracováním osobních údajů se můžete obrátit na nás nebo se stížností na Úřad pro ochranu osobních údajů, se sídlem Pplk. Sochora 27, 170 00 Praha 7, e-mail: posta@uoou.cz, WWW: ˂https://www.uoou.cz˃.

Veškerá sdělení a vyjádření Vám poskytneme bezplatně a co nejdříve (nejpozději však do jednoho měsíce).

### 8. Kde nás můžete kontaktovat?

Svá práva můžete uplatnit a své dotazy nebo připomínky nám můžete sdělit telefonicky na lince +420 […], e-mailem na adrese […] nebo písemně na korespondenční adrese: […].
