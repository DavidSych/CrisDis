<x-jet-form-section submit="updateProfileInformation">
    <x-slot name="title">
        {{ __('Profile Information') }}
    </x-slot>

    <x-slot name="description">
        {{ __('Update user\'s information and email address.') }}
    </x-slot>

    <x-slot name="form">
        <!-- Profile Photo -->

        <!-- Name -->
        <div class="col-span-6 lg:col-span-1">
            <x-jet-label for="title_before" value="{{ __('Ttile before') }}" />
            <x-jet-input id="title_before" type="text" class="mt-1 block w-full" wire:model.defer="state.title_before" autocomplete="title_before" />
            <x-jet-input-error for="title_before" class="mt-2" />
        </div>

        <!-- Name -->
        <div class="col-span-6 lg:col-span-2">
            <x-jet-label for="name" value="{{ __('Name') }}" />
            <x-jet-input id="name" type="text" class="mt-1 block w-full" wire:model.defer="state.name" autocomplete="name" />
            <x-jet-input-error for="name" class="mt-2" />
        </div>

        <!-- Surname -->
        <div class="col-span-6 lg:col-span-2">
            <x-jet-label for="surname" value="{{ __('Surname') }}" />
            <x-jet-input id="surname" type="text" class="mt-1 block w-full" wire:model.defer="state.surname" autocomplete="surname" />
            <x-jet-input-error for="surname" class="mt-2" />
        </div>

        <!-- Title after -->
        <div class="col-span-6 lg:col-span-1">
            <x-jet-label for="title_after" value="{{ __('Ttile after') }}" />
            <x-jet-input id="title_after" type="text" class="mt-1 block w-full" wire:model.defer="state.title_after" autocomplete="title_after" />
            <x-jet-input-error for="title_after" class="mt-2" />
        </div>

        <!-- Email -->
        <div class="col-span-6 sm:col-span-6">
            <x-jet-label for="email" value="{{ __('Email') }}" />
            <x-jet-input id="email" type="email" class="mt-1 block w-full" wire:model.defer="state.email" />
            <x-jet-input-error for="email" class="mt-2" />
        </div>

        <!-- Country -->
        <div class="col-span-6 lg:col-span-3">
            <x-jet-label for="phone" value="{{ __('Mobile phone') }}" />
            <x-jet-input id="phone" type="text" class="mt-1 block w-full" wire:model.defer="state.phone" />
            <x-jet-input-error for="phone" class="mt-2" />
        </div>

        <!-- Country -->
        <div class="col-span-6 lg:col-span-3">
            <x-jet-label for="phone_office" value="{{ __('Landline') }}" />
            <x-jet-input id="phone_office" type="text" class="mt-1 block w-full" wire:model.defer="state.phone_office" />
            <x-jet-input-error for="phone_office" class="mt-2" />
        </div>

    </x-slot>


    <x-slot name="actions">
        <x-jet-action-message class="mr-3" on="saved">
            {{ __('Saved.') }}
        </x-jet-action-message>

        <x-jet-button>
            {{ __('Save') }}
        </x-jet-button>
    </x-slot>
</x-jet-form-section>
