<x-jet-form-section submit="updateStatusFields">
    <x-slot name="title">
        {{ __('Manage user') }}
    </x-slot>

    <x-slot name="description">
        {{ __('Update user\'s status.') }}
    </x-slot>

    <x-slot name="form">
        <!-- Profile Photo -->

        <!-- Active -->
        <div class="col-span-6 lg:col-span-3">
            <label class="block font-medium text-sm text-gray-700 inline-flex items-center mt-1" for="active">
                <input id="active" type="checkbox" class="form-checkbox " wire:model.defer="state.active" />

                <span class="ml-3">{{ __('Active - can sign into the system') }}</span>
            </label>
            <x-jet-input-error for="active" class="mt-2" />
        </div>

        <div class="col-span-6 lg:col-span-3">
            <label class="block font-medium text-sm text-gray-700 inline-flex items-center mt-1" for="new">
                <input id="new" type="checkbox" class="form-checkbox " wire:model.defer="state.new" />

                <span class="ml-3">{{ __('Nově registrovaný') }}</span>
            </label>
            <x-jet-input-error for="new" class="mt-2" />
        </div>

        <!-- Category -->
        <div class="col-span-6 md:col-span-6 lg:col-span-6 ">
            <x-jet-label for="role" value="{{ __('Role') }}" />
            <div class="relative">
                <select
                    id="role"
                    wire:model.defer="state.role"
                    class="block appearance-none w-full bg-gray-200 border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-state"
                >
                    <option value="">{{ __('- choose user role -') }}</option>
                    @foreach($roles as $value => $option)
                        <option value="{{ $value }}">{{ $option }}</option>
                    @endforeach
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                </div>
                <x-jet-input-error for="role" class="mt-2" />
            </div>
        </div>

        <!-- Company -->
        <div class="col-span-6 md:col-span-6 lg:col-span-6 ">
            <x-jet-label for="role" value="{{ __('Company') }}" />
            <div class="relative">
                <select
                    id="company_id"
                    wire:model.defer="state.company_id"
                    class="block appearance-none w-full bg-gray-200 border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-state"
                >
                    <option value="">{{ __('- choose company -') }}</option>
                    @foreach($companies as $value => $option)
                        <option value="{{ $value }}">{{ $option }}</option>
                    @endforeach
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                </div>
                <x-jet-input-error for="role" class="mt-2" />
            </div>
        </div>

    </x-slot>


    <x-slot name="actions">
        <x-jet-action-message class="mr-3" on="saved">
            {{ __('Saved.') }}
        </x-jet-action-message>

        <x-jet-button>
            {{ __('Save') }}
        </x-jet-button>
    </x-slot>
</x-jet-form-section>
