<x-app-layout>
    <x-slot name="header">
        <div class="flex">
            <h2 class="flex-1 font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Update user profile') }}
            </h2>
            @if(auth()->user()->canImpersonate() && $user->canBeImpersonated())
            <div>
                <x-button-link href="{{ route('impersonate', $user->id) }}" class="bg-red-800 text-white hover:bg-red-900">přihlásit se jako tento uživatel</x-button-link>
            </div>
            @endif
        </div>

    </x-slot>

    <div>
        <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">

            <div class="mt-10 sm:mt-0">
                @livewire('users.user', ['user' => $user])
            </div>

            <x-jet-section-border />

            <div class="mt-10 sm:mt-0">
                @livewire('users.user-status-fields', ['user' => $user])
            </div>

            <x-jet-section-border />

        </div>
    </div>
</x-app-layout>
