<div>

    <div class="text-right">
        <x-jet-button wire:click="openDialog()">{{ __('Create user') }}</x-jet-button>
    </div>


    <div class="text-left">
    <x-jet-dialog-modal wire:model="dialogVisible">
        <x-slot name="title">{{ __('Create new user') }}</x-slot>

        <x-slot name="content">

            <div class="mt-4 flex">
                <div class="flex-1 pr-4">
                    <x-jet-label>{{ __('Name') }}</x-jet-label>
                    <x-jet-input class="w-full" wire:model.defer="state.name" id="name"></x-jet-input>
                    <x-jet-input-error for="name" class="mt-2" />
                </div>
                <div class="flex-1">
                    <x-jet-label>{{ __('Surname') }}</x-jet-label>
                    <x-jet-input class="w-full" wire:model.defer="state.surname" id="surname"></x-jet-input>
                    <x-jet-input-error for="surname" class="mt-2" />
                </div>
            </div>

            <div class="mt-4 flex">
                <div class="flex-1">
                    <x-jet-label>{{ __('Email') }}</x-jet-label>
                    <x-jet-input type="email" class="w-full" wire:model.defer="state.email" id="email" autocomplete="off"></x-jet-input>
                    <x-jet-input-error for="email" class="mt-2" />
                </div>
            </div>

        </x-slot>

        <x-slot name="footer">
            <div class="flex">

                <div class="rounded-md flex-1 text-left">
                    <x-button-light wire:click="cancel()">{{ __('cancel') }}</x-button-light>
                </div>

                <div class="rounded-md">
                  <x-jet-button wire:click="createUser()">{{ __('Create user') }}</x-jet-button>
                </div>
            </div>

        </x-slot>
    </x-jet-dialog-modal>
</div>
</div>
