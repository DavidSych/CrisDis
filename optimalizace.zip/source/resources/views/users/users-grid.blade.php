<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('Users') }}
            </h2>

            <div class="text-right">
                <livewire:users.create-user />
            </div>
        </div>
    </x-slot>

    @if(request()->user()->hasRole('admin') && count($newUsers))
        <x-sections.basic-list-section>
            <div class="p-6 sm:px-20 bg-yellow-50 border-b border-gray-200">
                <div class="text-yellow-700 text-2xl">
                    Neaktivovaní uživatelé
                </div>

                <div class="bg-yellow-50 shadow overflow-hidden sm:rounded-md mt-4">
                    <ul class="divide-y divide-gray-200">
                        @foreach($newUsers as $newUser)
                            <li>
                                <a href="{{ route('users.update', ['id' => $newUser->id]) }}"
                                   class="block hover:bg-yellow-100"
                                >
                                    <div class="py-4 px-4">
                                        <div class="flex items-center flex-wrap">
                                            <p class="text-sm font-medium uppercase font-bold text-black">
                                                {{ $newUser->surname }}, {{ $newUser->name }}
                                            </p>
                                            <p class="text-sm font-medium text-black ml-10">
                                                {{ $newUser->email }}
                                            </p>
                                            <p class="text-sm font-medium text-black flex-1 ml-10">
                                                Firma: {{ $newUser->company->name ?? '' }}
                                            </p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        @endforeach

                    </ul>
                </div>
            </div>
        </x-sections.basic-list-section>
    @endif

    <x-sections.plain-section>
        @livewire('users.users-grid', [
            'perPage' => '25',
            'searchable' => 'id,surname,name,email',
            'hideable' => 'select',
        ])
    </x-sections.plain-section>
</x-app-layout>
