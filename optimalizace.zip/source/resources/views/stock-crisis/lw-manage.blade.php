<x-sections.basic-section class="max-w-4xl mx-auto mt-10">

    @if(count($stock))
        @foreach($stock as $stockItem)
            <div class="">
                <div class="flex items-center flex-wrap">
                    @if($stockItem->crisis_mode)
                        <div class="flex flex-1 gap-4 mr-14 items-center">
                            <span>Etapa:</span>
                            <x-button-link-light wire:click.stop="setStockStage({{$stockItem->id}}, 1)"
                                                 class="flex gap-3 {{ $stockItem->inMappingStage() ? 'bg-blue-800 text-white' : 'bg-blue-300 hover:bg-blue-400' }}">
                                <div class="text-xs">1</div>
                            </x-button-link-light>
                            <x-button-link-light wire:click.stop="setStockStage({{$stockItem->id}}, 2)"
                                                 class="flex gap-3 {{ $stockItem->inBiddingStage() ? 'bg-blue-800  text-white' : 'bg-blue-300 hover:bg-blue-400' }}">
                                <div class="text-xs">2</div>
                            </x-button-link-light>
                            <x-button-link-light wire:click.stop="setStockStage({{$stockItem->id}}, 3)"
                                                 class="flex gap-3 {{ $stockItem->inResultsStage() ? 'bg-blue-800  text-white' : 'bg-blue-300 hover:bg-blue-400' }}">
                                <div class="text-xs">3</div>
                            </x-button-link-light>
                        </div>
                        <div class="flex gap-4 items-center">
                            <div>
                                <x-button-link-light wire:click.stop=""
                                                     href="/generate-json-2/{{ $stockItem->id }}"
                                                     class="flex gap-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4"
                                         viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd"
                                              d="M2 9.5A3.5 3.5 0 005.5 13H9v2.586l-1.293-1.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 15.586V13h2.5a4.5 4.5 0 10-.616-8.958 4.002 4.002 0 10-7.753 1.977A3.5 3.5 0 002 9.5zm9 3.5H9V8a1 1 0 012 0v5z"
                                              clip-rule="evenodd"/>
                                    </svg>
                                    <div class="text-xs">json 1</div>
                                </x-button-link-light>
                            </div>

                            <div>
                                <x-button-link-light wire:click.stop=""
                                                     href="/generate-json-1b/{{ $stockItem->id }}"
                                                     class="flex gap-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4"
                                         viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd"
                                              d="M2 9.5A3.5 3.5 0 005.5 13H9v2.586l-1.293-1.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 15.586V13h2.5a4.5 4.5 0 10-.616-8.958 4.002 4.002 0 10-7.753 1.977A3.5 3.5 0 002 9.5zm9 3.5H9V8a1 1 0 012 0v5z"
                                              clip-rule="evenodd"/>
                                    </svg>
                                    <div class="text-xs">json 1b</div>
                                </x-button-link-light>
                            </div>

                            <div>
                                <x-button-link-light wire:click.stop=""
                                                     href="/generate-json/{{ $stockItem->id }}"
                                                     class="flex gap-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4"
                                         viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd"
                                              d="M2 9.5A3.5 3.5 0 005.5 13H9v2.586l-1.293-1.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 15.586V13h2.5a4.5 4.5 0 10-.616-8.958 4.002 4.002 0 10-7.753 1.977A3.5 3.5 0 002 9.5zm9 3.5H9V8a1 1 0 012 0v5z"
                                              clip-rule="evenodd"/>
                                    </svg>
                                    <div class="text-xs">json 2</div>
                                </x-button-link-light>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
            @if($stockItem->crisis_mode)
                <div class="pt-10 ">
                    <div class="flex items-center justify-end gap-4 flex-wrap">

                        <div>
                            <x-button-link-light
                                wire:click="evaluateFirstRound({{$stockItem->id}})"
                                class="flex gap-3 cursor-pointer"
                            >
                                <div class="text-xs">Vyhodnotit 1. etapu</div>
                            </x-button-link-light>
                        </div>
                        <div>
                            <x-button-link-light
                                wire:click="evaluateSecondRound({{$stockItem->id}})"
                                disabled="true"
                                class="flex gap-3 cursor-pointer"
                            >
                                <div class="text-xs">Vyhodnotit 2. etapu</div>
                            </x-button-link-light>
                        </div>
                    </div>
                </div>


                <div wire:loading
                     class="text-gray-500 mt-10 text-center w-full"
                >
                    ... pracuji ...
                </div>
                @if (session()->has('message'))
                    <div class="text-gray-700 gap-10 flex justify-center mt-10 items-center">
                        <div class="flex gap-2 justify-center items-center text-green-600">
                            <div class="font-bold">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                     stroke-width="3" stroke="currentColor" class="w-5 h-5">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                          d="M4.5 12.75l6 6 9-13.5"/>
                                </svg>
                            </div>
                            <div>
                                {{ session('message') }}
                            </div>
                        </div>

                        @if (session('message') == 'první etapa vyhodnocena')
                        <div>
                            <x-button-link-light href="/generate-result/{{$stockItem->id}}"
                                                 class="flex gap-3 cursor-pointer">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4"
                                     viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd"
                                          d="M2 9.5A3.5 3.5 0 005.5 13H9v2.586l-1.293-1.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 15.586V13h2.5a4.5 4.5 0 10-.616-8.958 4.002 4.002 0 10-7.753 1.977A3.5 3.5 0 002 9.5zm9 3.5H9V8a1 1 0 012 0v5z"
                                          clip-rule="evenodd"/>
                                </svg>
                                <div class="text-xs">stáhnout transakce</div>
                            </x-button-link-light>
                        </div>
                        @endif

                        @if (session('message') == 'druhá etapa vyhodnocena')
                            <div>
                                <x-button-link-light href="/generate-result-2/{{$stockItem->id}}"
                                                     class="flex gap-3 cursor-pointer">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4"
                                         viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd"
                                              d="M2 9.5A3.5 3.5 0 005.5 13H9v2.586l-1.293-1.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 15.586V13h2.5a4.5 4.5 0 10-.616-8.958 4.002 4.002 0 10-7.753 1.977A3.5 3.5 0 002 9.5zm9 3.5H9V8a1 1 0 012 0v5z"
                                              clip-rule="evenodd"/>
                                    </svg>
                                    <div class="text-xs">stáhnout výsledky</div>
                                </x-button-link-light>
                            </div>
                        @endif
                    </div>

                    @if (session('message') == 'první etapa vyhodnocena')
                    <div class="text-center mt-6">
                        {{ $prediction }}
                    </div>
                    @endif
                @endif
            @endif
        @endforeach
    @endif

</x-sections.basic-section>
