<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('Crisis management') }}
            </h2>

            <div class="text-right">
                <!-- place for import button -->
            </div>
        </div>
    </x-slot>

    <x-sections.basic-section>

        Zde můžete označit materiál, který podléhá <span class="font-bold text-red-700">krizovému režimu</span>.

    </x-sections.basic-section>

    <livewire:stock.stock-crisis />

    <div class="h-20"></div>
</x-app-layout>

