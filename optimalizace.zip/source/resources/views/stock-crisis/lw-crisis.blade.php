

<x-sections.basic-list-section>

    @if(count($stock))
        <div class="bg-white shadow overflow-hidden sm:rounded-md">
            <ul class="divide-y divide-gray-200">
                @foreach($stock as $stockItem)
                    <li>
                        <a
                            @if($stockItem->crisis_mode)href="{{ route('stock-crisis-manage', ['id' => $stockItem->id] ) }}"@endif
                            class="block px-4 py-4 sm:px-6 {{ $stockItem->crisis_mode ? ' cursor-pointer bg-red-200' : '' }}"
                        >
                            <div class="flex items-center flex-wrap">
                                <div class="mr-6">
                                    <input type="checkbox"
                                           {{ $stockItem->crisis_mode ? 'checked="checked"': '' }} wire:click.stop="togglePortfolioItem({{$stockItem->id}})">
                                </div>
                                <div class="flex-1 mr-6 text-sm font-medium text-black">
                                    {{ $stockItem->name  }}
                                    <span class="font-semibold ml-4">({{ $stockItem->code }})</span>
                                </div>
                            </div>
                        </a>
                    </li>
                @endforeach

            </ul>
        </div>
    @endif

</x-sections.basic-list-section>

