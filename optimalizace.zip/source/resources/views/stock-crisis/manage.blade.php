<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 uppercase ">
                {{ $stock->name }} - správa krizového režimu
            </h2>
        </div>
    </x-slot>

    <livewire:stock.stock-crisis-manage :stock-id="$stock->id" />

    <div class="h-20"></div>
</x-app-layout>

