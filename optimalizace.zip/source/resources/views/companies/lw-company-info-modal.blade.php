<x-jet-dialog-modal wire:model="modalVisible">
    <x-slot name="title">
        <span class="font-bold">
            {{ $company->name ?? '' }}
        </span>
        &ndash; informace o společnosti
    </x-slot>

    <x-slot name="content">

        <table class="table-auto info-table table-aligned-top">
            <tr>
                <td class="font-semibold">IČ</td>
                <td>{{ $company->ic ?? ''}}</td>
            </tr>
            <tr>
                <td class="font-semibold">DIČ</td>
                <td>{{ $company->dic ?? ''}}</td>
            </tr>
            <tr>
                <td class="font-semibold">Adresa</td>
                <td>
                    {{ $company->street ?? ''}}<br>
                    {{ $company->zip ?? '' }} {{ $company->town ?? '' }}<br>
                    {{ $company->country ?? '' }}
                </td>
            </tr>
            @if(!empty($company->phone))
            <tr>
                <td class="font-semibold">Telefon</td>
                <td>{{ $company->phone ?? ''}}</td>
            </tr>
            @endif
            @if(!empty($company->email))
            <tr>
                <td class="font-semibold">Email</td>
                <td>{{ $company->email ?? ''}}</td>
            </tr>
            @endif
        </table>

    </x-slot>

    <x-slot name="footer">
        <div class="flex justify-end">
            <div class="rounded-md">
                <x-jet-button wire:click="close()">zavřít okno</x-jet-button>
            </div>
        </div>

    </x-slot>


</x-jet-dialog-modal>
