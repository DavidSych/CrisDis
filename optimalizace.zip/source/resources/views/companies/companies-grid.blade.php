<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('Companies') }}
            </h2>

            <div class="text-right">
                <livewire:companies.create-company />
            </div>
        </div>
    </x-slot>

    <x-sections.plain-section>

        @livewire('companies.companies-grid', [
            'perPage' => '25',
            'searchable' => 'id,name',
            'hideable' => 'select',
        ])

    </x-sections.plain-section>

    <div class="pb-20"></div>
</x-app-layout>
