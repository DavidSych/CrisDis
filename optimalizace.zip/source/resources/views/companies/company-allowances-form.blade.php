<x-jet-form-section submit="update">
    <x-slot name="title">
        Povolení k nákupu
    </x-slot>

    <x-slot name="description">
        Zde můžete upravit množství "povolenek" k nákupu produktů.
    </x-slot>

    <x-slot name="form">

        @foreach($stock as $item)
            <div class="col-span-6 md:col-span-3">
                <x-jet-label for="stock{{ $item->id }}" value="{{ $item->name }}"/>
                <div
                    class="relative form-input rounded-md shadow-sm p-3 border border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm"
                >
                    <input wire:model.defer="state.{{ $item->id }}"
                           placeholder="0"
                           aria-describedby="price-currency"
                           class="outline-none"
                    >
                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                    <span class="text-gray-500 sm:text-sm sm:leading-5" id="price-currency">
                        Ks
                    </span>
                    </div>
                </div>
                <x-jet-input-error for="stock{{ $item->id }}" class="mt-2"/>
            </div>
        @endforeach

    </x-slot>


    <x-slot name="actions">
        <x-jet-action-message class="mr-3" on="saved">
            {{ __('Saved.') }}
        </x-jet-action-message>

        <x-jet-button>
            {{ __('Save') }}
        </x-jet-button>
    </x-slot>
</x-jet-form-section>
