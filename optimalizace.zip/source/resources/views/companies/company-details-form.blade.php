<x-jet-form-section submit="updateProfileInformation">
    <x-slot name="title">
        {{ __('Contact Information') }}
    </x-slot>

    <x-slot name="description">
        {{ __('Update contact\'s core information.') }}
    </x-slot>

    <x-slot name="form">

        <!-- Name -->
        <div class="col-span-6 lg:col-span-6">
            <x-jet-label for="name" value="{{ __('Name') }}" />
            <x-jet-input id="name" type="text" class="mt-1 block w-full" wire:model.defer="state.name" autocomplete="name" />
            <x-jet-input-error for="name" class="mt-2" />
        </div>

        <!-- Category -->
        <div class="col-span-6 md:col-span-6 lg:col-span-6 ">
            <x-jet-label for="role" value="{{ __('Company type') }}" />
            <div class="relative">
                <select
                    id="role"
                    wire:model.defer="state.type"
                    class="block appearance-none w-full bg-gray-200 border border-gray-200 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-state"
                >
                    <option value="">{{ __('- choose company type -') }}</option>
                    @foreach($types as $value => $option)
                        <option value="{{ $value }}">{{ $option }}</option>
                    @endforeach
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                </div>
                <x-jet-input-error for="role" class="mt-2" />
            </div>
        </div>

        <!-- IČ -->
        <div class="col-span-6 md:col-span-3 lg:col-span-3 lg:col-start-1">
            <x-jet-label for="ic" value="{{ __('IČ') }}" />
            <x-jet-input id="ic" type="text" class="mt-1 block w-full" wire:model.defer="state.ic" autocomplete="ic" />
            <x-jet-input-error for="ic" class="mt-2" />
        </div>

        <!-- DIČ -->
        <div class="col-span-6 md:col-span-3 lg:col-span-3">
            <x-jet-label for="dic" value="{{ __('DIČ') }}" />
            <x-jet-input id="dic" type="text" class="mt-1 block w-full" wire:model.defer="state.dic" autocomplete="dic" />
            <x-jet-input-error for="dic" class="mt-2" />
        </div>

        <!-- Email -->
        <div class="col-span-6 lg:col-span-6">
            <x-jet-label for="email" value="{{ __('Email') }}" />
            <x-jet-input id="email" type="email" class="mt-1 block w-full" wire:model.defer="state.email" />
            <x-jet-input-error for="email" class="mt-2" />
        </div>

        <!-- Phone -->
        <div class="col-span-6 md:col-span-3 lg:col-span-3 lg:col-start-1">
            <x-jet-label for="phone" value="{{ __('Phone') }}" />
            <x-jet-input id="phone" type="text" class="mt-1 block w-full" wire:model.defer="state.phone" />
            <x-jet-input-error for="phone" class="mt-2" />
        </div>

        <!-- Fax -->
        <div class="col-span-6 md:col-span-3 lg:col-span-3">
            <x-jet-label for="fax" value="{{ __('Phone') }}" />
            <x-jet-input id="fax" type="text" class="mt-1 block w-full" wire:model.defer="state.fax" />
            <x-jet-input-error for="fax" class="mt-2" />
        </div>

        <!-- Street -->
        <div class="col-span-6 sm:col-span-6">
            <x-jet-label for="street" value="{{ __('Street') }}" />
            <x-jet-input id="street" type="text" class="mt-1 block w-full" wire:model.defer="state.street" autocomplete="street" />
            <x-jet-input-error for="street" class="mt-2" />
        </div>

        <!-- ZIP -->
        <div class="col-span-6 sm:col-span-2 sm:col-start-1">
            <x-jet-label for="zip" value="{{ __('Zip code') }}" />
            <x-jet-input id="zip" type="text" class="mt-1 block w-full" wire:model.defer="state.zip" />
            <x-jet-input-error for="zip" class="mt-2" />
        </div>

        <!-- Town -->
        <div class="col-span-6 sm:col-span-4">
            <x-jet-label for="town" value="{{ __('City') }}" />
            <x-jet-input id="town" type="text" class="mt-1 block w-full" wire:model.defer="state.town" autocomplete="town" />
            <x-jet-input-error for="town" class="mt-2" />
        </div>

        <!-- Country -->
        <div class="col-span-6 sm:col-span-6">
            <x-jet-label for="country" value="{{ __('Country') }}" />
            <x-jet-input id="country" type="text" class="mt-1 block w-full" wire:model.defer="state.country" />
            <x-jet-input-error for="country" class="mt-2" />
        </div>

        <!-- Credit -->
        <div class="col-span-6 md:col-span-3">
            <x-jet-label for="credit" value="{{ __('Kredit') }}" />
            <x-input.currency-czk wire:model.defer="state.credit" />
            <x-jet-input-error for="credit" class="mt-2" />
        </div>

    </x-slot>


    <x-slot name="actions">
        <x-jet-action-message class="mr-3" on="saved">
            {{ __('Saved.') }}
        </x-jet-action-message>

        <x-jet-button>
            {{ __('Save') }}
        </x-jet-button>
    </x-slot>
</x-jet-form-section>
