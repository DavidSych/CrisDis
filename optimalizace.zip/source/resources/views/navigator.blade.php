<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CrisDis Navigator</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.2.2/axios.min.js" integrity="sha512-QTnb9BQkG4fBYIt9JGvYmxPpd6TBeKp6lsUrtiVQsrJ9sb33Bn9s0wMQO9qVBFbPX3xHRAsBHvXlcsrnJjExjg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        let originalData = {
            "stock": {
                "id": 9,
                "code": "M9",
                "name": "jehla injek\u010dn\u00ed modr\u00e1 0,6x25 mm"
            },
            "productDemand": [
                {
                    "id": 1,
                    "company_id": 1,
                    "amount": 3,
                    "credit": 10
                },
                {
                    "id": 23,
                    "company_id": 42,
                    "amount": 3,
                    "credit": 20
                }
            ],
            "productSupply": [
                {
                    "id": 1,
                    "company_id": 1,
                    "amount": 2,
                    "price": 5
                },
                {
                    "id": 1,
                    "company_id": 2,
                    "amount": 1,
                    "price": 9
                }
            ]
        }
    </script>

</head>
<body class="bg-stone-300" x-data="{sourceData: '', resultData: null, isLoading: false }" x-init="sourceData = JSON.stringify(originalData, undefined, 2)">
    <section class="max-w-4xl mx-auto border border-stone-400 rounded bg-white my-4 p-12 text-gray-600">
        <h1 class="text-4xl mt-4 mb-10 font-mono text-black">Navigator</h1>


        <p class="mb-4">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus rhoncus. Nunc tincidunt ante vitae massa. Sed ac dolor sit amet purus malesuada congue. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Etiam quis quam. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Duis bibendum, lectus ut viverra rhoncus, dolor nunc faucibus libero, eget facilisis enim ipsum id lacus. Fusce nibh. Aliquam id dolor. Pellentesque pretium lectus id turpis. Mauris tincidunt sem sed arcu. Vivamus porttitor turpis ac leo. Nulla pulvinar eleifend sem.</p>

        <p class="mb-4">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. In laoreet, magna id viverra tincidunt, sem odio bibendum justo, vel imperdiet sapien wisi sed libero. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Maecenas aliquet accumsan leo. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Nulla accumsan, elit sit amet varius semper, nulla mauris mollis quam, tempor suscipit diam nulla vel leo. In dapibus augue non sapien. Duis pulvinar. In enim a arcu imperdiet malesuada. Mauris tincidunt sem sed arcu. Morbi scelerisque luctus velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Integer imperdiet lectus quis justo. Donec quis nibh at felis congue commodo. Etiam commodo dui eget wisi. Nullam feugiat, turpis at pulvinar vulputate, erat libero tristique tellus, nec bibendum odio risus sit amet ante. Nulla turpis magna, cursus sit amet, suscipit a, interdum id, felis. Fusce dui leo, imperdiet in, aliquam sit amet, feugiat eu, orci. Duis condimentum augue id magna semper rutrum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>


        <h2 class="text-xl mt-10 mb-2 font-mono text-black">Testovací zdrojová data</h2>

        <pre class="whitespace-pre bg-sky-50 border border-sky-200 rounded p-5 " x-text="sourceData" ></pre>

        <div class="mt-8">
            <div class="">
                <button
                    class="bg-stone-500 hover:bg-stone-700  text-white py-2 px-4 border border-stone-900 rounded"
                    x-show="!isLoading"
                    x-on:click="
                        isLoading = true;
                        resultData = null;
                        axios.get('/navigator/data')
                            .then((response) =>{
                                resultData = response.data
                                isLoading = false;
                            })
                    "
                >zobrazit výsledky</button>
            </div>

            <div x-show="isLoading" class="font-mono bg-white hover:bg-white text-gray-500 py-2 px-4"> ... loading ...</div>
        </div>



        <div x-show="resultData !== null">
            <h2 class="text-xl mt-10 mb-2 font-mono text-black">Výsledná data</h2>

            <pre class="whitespace-pre bg-sky-50 border border-sky-200 rounded p-5 " x-text="resultData" ></pre>
        </div>
    </section>

</body>
</html>
