<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    @if(request()->user()->hasRole('admin') && count($newUsers))
        <div class="pt-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-yellow-50 overflow-hidden shadow-xl sm:rounded-lg">
                    <div class="p-6 sm:px-20 bg-yellow-50 border-b border-gray-200">
                        <div class="text-yellow-700 text-2xl">
                            Neaktivovaní uživatelé
                        </div>

                        <div class="bg-yellow-50 shadow overflow-hidden sm:rounded-md mt-4">
                            <ul class="divide-y divide-gray-200">
                                @foreach($newUsers as $newUser)
                                    <li>
                                        <a href="{{ route('users.update', ['id' => $newUser->id]) }}"
                                           class="block hover:bg-yellow-100"
                                        >
                                            <div class="py-4 px-4">
                                                <div class="flex items-center flex-wrap">
                                                    <p class="text-sm font-medium uppercase font-bold text-black">
                                                        {{ $newUser->surname }}, {{ $newUser->name }}
                                                    </p>
                                                    <p class="text-sm font-medium text-black ml-10">
                                                        {{ $newUser->email }}
                                                    </p>
                                                    <p class="text-sm font-medium text-black flex-1 ml-10">
                                                        Firma: {{ $newUser->company->name ?? '' }}
                                                    </p>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                @endforeach

                        </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                @if(request()->user()->isSupplier())
                    Supplier
                @elseif(request()->user()->isMedicalCenter())
                    <x-medical-welcome />
                @else
                    <x-medical-welcome />
                @endif
            </div>
        </div>
    </div>
</x-app-layout>
