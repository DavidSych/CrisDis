<x-sections.basic-list-section class="pt-4">

    <div class="grid gap-x-4 grid-cols-12 border-b border-gray-600 pb-2 pt-4 px-6 bg-yellow-50">
        <div class="{{ $locked ? 'col-span-8' : 'col-span-7' }} font-bold">
            {{ $pivot->amount }}x {{$stockItem->name}}
        </div>
        <div class="col-span-2 row-span-2 text-right align-bottom">
            jedn. cena
        </div>
        <div class="col-span-2 row-span-2 text-right">
            celkem
        </div>
        @if(!$locked)
            <div class="col-span-1 row-span-2 text-right">

            </div>
        @endif

        <div class="col-span-8 text-sm">
            Datum dodání:
            @if(isset($pivot->delivery_date))
                {{ format_date($pivot->delivery_date) }}
            @else
                {{ format_date($pivot->inquiry->delivery_date) }}
            @endif
        </div>
        @if($pivot->note)
            <div class="col-span-8 text-sm text-gray-600 italic">
                Poznámka: {{ $pivot->note }}
            </div>
        @endif

    </div>

    @if($items->count())
        <div class="">
            @foreach($items as $item)
                <div class="grid gap-4 grid-cols-12 border-b border-gray-300 py-3 px-6">
                    <div class="col-span-3">
                        @if($item->url)
                            <a href="{{ $item->url }}" target="_blank" class="text-blue-800 flex">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z" />
                                    <path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z" />
                                </svg>

                                {{ $item->name }}
                            </a>
                        @else
                            {{ $item->name }}
                        @endif
                    </div>

                    <div class="{{ $locked ? 'col-span-4' : 'col-span-3' }}">
                        {{ $item->note }}
                    </div>

                    <div class="col-span-1">
                        {{ AppHelper::formatDate($item->delivery_date) }}
                    </div>

                    <div class="col-span-2 text-right">
                        {{ AppHelper::formatCzk($item->price) }} Kč
                    </div>
                    <div class="col-span-2 text-right">
                        {{ AppHelper::formatCzk($item->price * $pivot->amount) }} Kč
                    </div>
                    @if(!$locked)
                        <div class="col-span-1 flex justify-end">
                            <div>
                                <svg xmlns="http://www.w3.org/2000/svg"
                                     wire:click="editItem({{ $item->id }})"
                                     class="h-5 w-5 text-gray-400 hover:text-red-300 cursor-pointer"
                                     fill="none"
                                     viewBox="0 0 24 24"
                                     stroke="currentColor"
                                >
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                </svg>
                            </div>

                            <div class="ml-5">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                     wire:click="removeItem({{ $item->id }})"
                                     class="h-5 w-5 text-gray-400 hover:text-red-300 cursor-pointer"
                                     fill="none"
                                     viewBox="0 0 24 24"
                                     stroke="currentColor"
                                >
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                            </div>

                        </div>
                    @endif
                </div>
            @endforeach
        </div>
    @endif

    @if(!$locked)
    <div class="rounded-md text-right px-6 py-3 bg-gray-50">
        <x-button-light wire:click="openAddItemModal()">přidat položku nabídky</x-button-light>
    </div>
    @endif

</x-sections.basic-list-section>
