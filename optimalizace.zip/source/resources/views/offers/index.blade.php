<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                Moje nabídky
            </h2>
        </div>
    </x-slot>

    <x-sections.basic-list-section>
        <x-slot name="title">Moje rozpracované nabídky</x-slot>

        @if(count($openOffers))
            <ul class="divide-y divide-gray-200">
                @foreach($openOffers as $offer)
                    <li>
                        <a href="{{ route('offers.update', ['id' => $offer->id]) }}"
                           class="block hover:bg-gray-50"
                        >
                            <div class="px-4 py-4 sm:px-6">
                                <div class="flex items-center flex-wrap">
                                     <p class="text-sm font-medium text-black">
                                         Poptávka: #{{ str_pad($offer->inquiry->id, 7, '0', STR_PAD_LEFT) }} od <span class="font-bold">{{ $offer->inquiry->company->name }}</span>
                                    </p>
                                    <p class="text-sm font-medium text-black flex-1 ml-10">
                                        <?php $priceRange = $offer->getPriceRange(); ?>

                                        @if($priceRange['from'] != $priceRange['to'])
                                            <span class="font-bold">{{ format_czk($priceRange['from']) }} Kč</span> až <span class="font-bold">{{ format_czk($priceRange['to']) }} Kč</span>
                                        @else
                                            <span class="font-bold">{{ format_czk($priceRange['from']) }} Kč
                                        @endif
                                    </p>

                                    @if($offer->inquiry->delivery_date)
                                        <div class="ml-8 text-sm flex-shrink-0 flex">
                                            Datum dodání: <span class="ml-2 font-semibold">{{ AppHelper::formatDate($offer->inquiry->delivery_date) }}</span>
                                        </div>
                                    @endif

                                    @if($offer->inquiry->offers_due)
                                        <div class="ml-8 text-sm flex-shrink-0 flex">
                                            Zveřejněno do: <span class="ml-2 font-semibold">{{ AppHelper::formatDate($offer->inquiry->offers_due) }}</span>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </a>
                    </li>
                @endforeach

            </ul>
        @else
            <div class="py-4 px-6">Nemáte žádné rozpracavné nabídky.</div>
        @endif

    </x-sections.basic-list-section>

    <x-sections.basic-list-section>

        <x-slot name="title">Moje odeslané nabídky</x-slot>

        @if(count($offers))
            <ul class="divide-y divide-gray-200">
                @foreach($offers as $offer)
                    <li>
                        <a href="{{ route('offers.update', ['id' => $offer->id]) }}"
                           class="block hover:bg-gray-50"
                        >
                            <div class="px-4 py-4 sm:px-6">
                                <div class="flex items-center flex-wrap">
                                    <p class="text-sm font-medium text-black">
                                        Poptávka: #{{ str_pad($offer->inquiry->id, 7, '0', STR_PAD_LEFT) }} od <span class="font-bold">{{ $offer->inquiry->company->name }}</span>
                                    </p>
                                    <p class="text-sm font-medium text-black flex-1 ml-10">
                                        <?php $priceRange = $offer->getPriceRange(); ?>

                                            @if($priceRange['from'] != $priceRange['to'])
                                                <span class="font-bold">{{ format_czk($priceRange['from']) }} Kč</span> až <span class="font-bold">{{ format_czk($priceRange['to']) }} Kč</span>
                                            @else
                                                <span class="font-bold">{{ format_czk($priceRange['from']) }} Kč
                                            @endif
                                    </p>

                                    @if($offer->inquiry->delivery_date)
                                        <div class="ml-8 text-sm flex-shrink-0 flex">
                                            Datum dodání: <span class="ml-2 font-semibold">{{ AppHelper::formatDate($offer->inquiry->delivery_date) }}</span>
                                        </div>
                                    @endif

                                    @if($offer->inquiry->offers_due)
                                        <div class="ml-8 text-sm flex-shrink-0 flex">
                                            Zveřejněno do: <span class="ml-2 font-semibold">{{ AppHelper::formatDate($offer->inquiry->offers_due) }}</span>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </a>
                    </li>
                @endforeach

            </ul>
        @else
            <div class="py-4 px-6">Nemáte žádné odeslané nabídky.</div>
        @endif

    </x-sections.basic-list-section>
</x-app-layout>
