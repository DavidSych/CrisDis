<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                Úprava nabídky
            </h2>
        </div>
    </x-slot>

    <x-sections.basic-list-section>

        <div class="bg-blue-900 text-white p-6">

        <div class="grid gap-4 grid-cols-8">

            <div class="col-span-8 lg:col-span-8">
                <p class="text-lg mb-3 font-semibold">Poptávka -
                <a onClick="Livewire.emit('openCompanyInfoModal', {{ $inquiry->company->id }}); return false;" href="#" >
                    {{ $inquiry->company->name }}

                    <svg xmlns="http://www.w3.org/2000/svg" class="inline-block h-5 w-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </a>
            </div>

            <div class="col-span-8 md:col-span-4 lg:col-span-2">
                Číslo poptávky: <span class="ml-2 font-semibold">#{{ str_pad($inquiry->id, 7, '0', STR_PAD_LEFT) }}</span>
            </div>

            <div class="col-span-8 md:col-span-4 lg:col-span-2">
                Zveřejněnno do: <span class="ml-2 font-semibold">{{ format_date($inquiry->offers_due) }}</span>
            </div>

            <div class="col-span-8 md:col-span-4 lg:col-span-2">
                Datum dodání: <span class="ml-2 font-semibold">{{ format_date($inquiry->delivery_date) }}</span>
            </div>

            <div class="col-span-8 md:col-span-4 lg:col-span-2">
                Možnost částečné nabídky: <span class="ml-2 font-semibold"> {{ $inquiry->allow_partial_offers ? 'Ano': 'Ne' }}</span>
            </div>
        </div>

        @if($inquiry->note)
        <div class="flex flex-wrap mt-4">

            <div class="">
                Poznámka:
            </div>

            <div class="italic ml-4">
                {{ $inquiry->note }}
            </div>

        </div>
        @endif

        </div>
    </x-sections.basic-list-section>

    @foreach($inquiry->stock as $stockItem)
        @livewire('offers.offer-item', [
            'stockItem' => $stockItem,
            'pivotId' => $stockItem->pivot->id,
            'offerId' => $offer->id,
            'locked' => ($offer->status > 1)
        ], key($stockItem->pivot->id))
    @endforeach

    @livewire('offers.add-item-to-offer-modal', [
        'offerId' => $offer->id
    ])

    <x-sections.basic-section>

        <div class="text-lg">
            @livewire('offers.total-price', [
                'offerId' => $offer->id
            ])
        </div>

        <x-jet-input-error for="invalidOffer" class="mt-10" />

        <div class="mt-10">
            @if($offer->status == 1)
                <form method="post" action="{{ route('offers.submit', ['id' => $offer->id]) }}">
                    @csrf

                    <div class="mb-10">
                        <div class="flex">
                            <div class="mr-6">
                                <input type="checkbox" name="approval" id="approval" @if($approval) checked="checked" @endif>
                            </div>
                            <div>
                                <label for="approval">Prohlášení o pravdivostí údajů (bude doplněno)</label>
                            </div>
                        </div>

                        <div>
                            <x-jet-input-error for="approval" class="mt-2" />
                        </div>
                    </div>

                    <x-jet-button type="submit" class="text-lg">
                        Odeslat nabídku zadavateli
                    </x-jet-button>

                </form>
            @elseif($inquiry->status == 2)
                <span class="text-lg">Nabídka je odeslána</span>
            @endif
        </div>


    </x-sections.basic-section>

    <div class="h-40"></div>

    <livewire:companies.company-info-modal></livewire:companies.company-info-modal>

</x-app-layout>
