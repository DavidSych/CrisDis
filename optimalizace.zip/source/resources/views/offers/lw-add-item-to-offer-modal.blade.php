<x-jet-dialog-modal wire:model="dialogVisible">
    <x-slot name="title">
        <div class="font-bold">{{ $stockItem->name ?? '' }}</div>
        <div class="text-sm">
            @if(isset($pivot->delivery_date))
                Datum dodání: {{ format_date($pivot->delivery_date) }}
            @else
                Datum dodání: {{ isset($pivot->inquiry->delivery_date) ? format_date($pivot->inquiry->delivery_date): ''}}
            @endif
        </div>
    </x-slot>

    <x-slot name="content">

        <div class="mt-4 flex">
            <div class="flex-1 pr-4">
                <x-jet-label>Název výrobku *</x-jet-label>
                <x-jet-input class="w-full" wire:model.defer="state.name" id="name"></x-jet-input>
                <x-jet-input-error for="name" class="mt-2" />
            </div>
        </div>

        <div class="mt-4 flex">
            <div class="flex-1 pr-4">
                <x-jet-label>Webový odkaz</x-jet-label>
                <x-jet-input class="w-full" wire:model.defer="state.url" id="url"></x-jet-input>
                <x-jet-input-error for="url" class="mt-2" />
            </div>
        </div>

        <div class="mt-4 flex">
            <div class="flex-1">
                <x-jet-label>Jednotková cena *</x-jet-label>
                <x-jet-input type="text" wire:model.defer="state.price" id="price" autocomplete="off"></x-jet-input>
                <x-jet-input-error for="price" class="mt-2" />
            </div>

            <div class="flex-1">
                <x-jet-label>Datum dodání</x-jet-label>
                <x-jet-input class="flatpickr-future"
                             type="text"
                             wire:model.defer="state.delivery_date"
                             id="delivery_date"
                             autocomplete="off"
                ></x-jet-input>
                <x-jet-input-error for="delivery_date" class="mt-2" />
            </div>
        </div>

        <div class="mt-4 flex">
            <div class="flex-1">
                <x-jet-label>Poznámka</x-jet-label>
                <textarea  wire:model.defer="state.note" id="note" autocomplete="off" class="w-full p-3 border border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm"></textarea>
                <x-jet-input-error for="note" class="mt-2" />
            </div>
        </div>

    </x-slot>

    <x-slot name="footer">
        <div class="flex">

            <div class="rounded-md flex-1 text-left">
                <x-button-light wire:click="close()">{{ __('cancel') }}</x-button-light>
            </div>

            <div class="rounded-md">
                <x-jet-button wire:click="saveItem()">uložit položku</x-jet-button>
            </div>
        </div>

    </x-slot>


</x-jet-dialog-modal>
