<div>
    @if($priceRange['from'] != $priceRange['to'])
        Celková cena: <span class="ml-8 font-bold">{{ format_czk($priceRange['from']) }} Kč</span> až <span class="font-bold">{{ format_czk($priceRange['to']) }} Kč</span>
    @else
        Celková cena: <span class="ml-8 font-bold">{{ format_czk($priceRange['from']) }} Kč</span>
    @endif
</div>
