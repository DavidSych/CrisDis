<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                Přehled nabídky nabídku
            </h2>
        </div>
    </x-slot>

    <x-sections.basic-section>

        <div class="flex">

            <div class="flex-1">
                <p class="text-lg font-semibold">
                    Nabídka od
                    <a onClick="Livewire.emit('openCompanyInfoModal', {{ $offer->company->id }}); return false;" href="#" class="text-blue-800">
                        {{ $offer->company->name }}

                        <svg xmlns="http://www.w3.org/2000/svg" class="inline-block h-5 w-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </a>
                </p>
            </div>

            <div class="col-span-8 lg:col-span-8">
                <x-button-link-light href="{{ route('inquiries.preview', $offer->inquiry->id) }}">zpět na poptávku</x-button-link-light>
            </div>

        </div>
    </x-sections.basic-section>

    @foreach($inquiry->stock as $stockItem)
        @livewire('offers.offer-item', [
            'stockItem' => $stockItem,
            'pivotId' => $stockItem->pivot->id,
            'offerId' => $offer->id,
            'locked' => true
         ], key($stockItem->pivot->id))
    @endforeach

    @livewire('offers.add-item-to-offer-modal', [
        'offerId' => $offer->id
    ])

    <x-sections.basic-section>

        <div class="text-lg">
            @livewire('offers.total-price', [
                'offerId' => $offer->id
            ])
        </div>
    </x-sections.basic-section>

    <div class="h-40"></div>

    <livewire:companies.company-info-modal></livewire:companies.company-info-modal>

</x-app-layout>
