<x-sections.basic-section
    class="max-w-5xl mx-auto mt-5 "
>
    <div wire:loading.class="opacity-50">
        <div class="mb-10 text-center">
            V systému je <strong>{{ $suppliersCount }}</strong> dodavatelů a <strong>{{ $hospitalsCount }}</strong> zdravotnických zařízení.
        </div>

        <div class="flex justify-center items-center gap-5">
            <div class="font-semibold">
                Generovat
            </div>

            <div  class="flex justify-center items-center gap-5">
                <x-jet-input type="text" wire:model.defer="suppliers" class="w-20 text-center" />
                {{ __('dodavatelů a') }}
            </div>

            <div class="flex justify-center items-center gap-5">
                <x-jet-input type="text" wire:model.defer="hospitals" class="w-20 text-center" />
                {{ __('zdravotnických zařízení') }}
            </div>

            <x-jet-button
                wire:click="generateCompanies()"
                wire:loading.attr="disabled"
            >
                {{ __('generovat') }}
            </x-jet-button>
        </div>
    </div>

</x-sections.basic-section>
