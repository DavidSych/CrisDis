<x-sections.basic-section
    class="max-w-5xl mx-auto mt-5 "
>
    <div wire:loading.class="opacity-50">
        <div class="text-xl text-center font-semibold mb-6">
            <span class="font-bold">Krok 2:</span> Generovat nákup a prodej výrobků a práv
        </div>

        <div class="flex justify-center items-center gap-5 mb-6">
            <div class="font-semibold">
                Výrobek
            </div>

            <div>
                <div class="relative">
                    <select wire:model.defer="stockId" class="block appearance-none w-full bg-gray-200 border border-gray-200 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500">
                        <option value="">- vyberte výrobek -</option>
                        @foreach($stock as $key => $item)
                            <option value="{{ $key }}">{{ $item }}</option>
                        @endforeach
                    </select>
                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                    </div>
                </div>
                <x-jet-input-error for="stockId" class="mt-2"/>
            </div>
        </div>

        <div class="flex justify-center items-center gap-5  mt-14">
            Každé zdravotnické zařízení poptá výrobky:
        </div>
        <div class="flex justify-center items-center gap-5  mt-3">
            <div>
                Mezi
            </div>
            <div  class="flex justify-center items-center gap-2">
                <x-jet-input type="text" wire:model.defer="amountFrom" class="w-20 py-2 text-center" />
                %
            </div>

            <div>a</div>

            <div  class="flex justify-center items-center gap-2">
                <x-jet-input type="text" wire:model.defer="amountTo" class="w-20 py-2 text-center" />
                %
            </div>
            <div>
                přiřazeného množství povolenek.
            </div>

        </div>

        <div class="text-center mt-10">
            <x-jet-input-error for="amountFrom" class="mt-2"/>
            <x-jet-input-error for="amountTo" class="mt-2"/>
        </div>

        <div class="flex justify-center items-center gap-4 mt-14">
            <div class="">
                Za cenu mezi
            </div>

            <div  class="flex justify-center items-center gap-2">
                <x-jet-input type="text" wire:model.defer="priceFrom" class="w-20 py-2 text-center" />
                %
            </div>

            <div>a</div>

            <div  class="flex justify-center items-center gap-2">
                <x-jet-input type="text" wire:model.defer="priceTo" class="w-20 py-2 text-center" />
                %
            </div>
            <div>
                průměru cen nabízené dodavateli.
            </div>

        </div>

        <div class="text-center mt-10">
            <x-jet-input-error for="priceFrom" class="mt-2"/>
            <x-jet-input-error for="priceTo" class="mt-2"/>
        </div>


        <div class="text-center mt-10">
            <x-jet-button
                wire:click="generateSupplyAndDemand()"
                wire:loading.attr="disabled"
                class=" mx-auto"
            >
                {{ __('generovat') }}
            </x-jet-button>
        </div>

    </div>

</x-sections.basic-section>
