<x-sections.basic-section
    class="max-w-5xl mx-auto mt-5 "
>
    <div wire:loading.class="opacity-50">
        <div class="text-xl text-center font-semibold mb-6">
            <span class="font-bold">Krok 1:</span> Generovat nabídku a poptávku
        </div>

        <div class="flex justify-center items-center gap-5 mb-6">
            <div class="font-semibold">
                Výrobek
            </div>

            <div>
                <div class="relative">
                    <select wire:model.defer="stockId" class="block appearance-none w-full bg-gray-200 border border-gray-200 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500">
                        <option value="">- vyberte výrobek -</option>
                        @foreach($stock as $key => $item)
                        <option value="{{ $key }}">{{ $item }}</option>
                        @endforeach
                    </select>
                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                    </div>
                </div>
                <x-jet-input-error for="stockId" class="mt-2"/>
            </div>
        </div>

        <div class="flex justify-center items-center gap-5  mt-14">
            <div class="">
                Rozdělit
            </div>

            <div  class="flex justify-center items-center gap-5">
                <x-jet-input type="text" wire:model.defer="supply" class="w-28 py-2 text-center" />
                {{ __('nabízených kusů mezi') }}
            </div>

            <div class="flex justify-center items-center gap-5">
                <x-jet-input type="text" wire:model.defer="suppliers" class="w-20 py-2 text-center" />
                <span class="font-bold">
                    / {{ $suppliersCount }}
                </span>
                {{ __('dodavatelů') }}.
            </div>

        </div>

        <div class="flex justify-center items-center gap-4 mt-4">
            <div class="">
                za cenu mezi
            </div>

            <div  class="flex justify-center items-center gap-5">
                <x-jet-input type="text" wire:model.defer="priceFrom" class="w-28 py-2 text-center" />
                {{ __('a') }}
            </div>

            <div class="flex justify-center items-center gap-5">
                <x-jet-input type="text" wire:model.defer="priceTo" class="w-28 py-2 text-center" />
                {{ __('Kč / kus') }}.
            </div>

        </div>

        <div class="text-center">
            <x-jet-input-error for="supply" class="mt-2"/>
            <x-jet-input-error for="suppliers" class="mt-2"/>
            <x-jet-input-error for="priceFrom" class="mt-2"/>
            <x-jet-input-error for="priceTo" class="mt-2"/>
        </div>


        <div class="flex justify-center items-center gap-5 mt-12">
            <div class="">
                Rozdělit
            </div>

            <div  class="flex justify-center items-center gap-5">
                <x-jet-input type="text" wire:model.defer="demand" class="w-28 py-2 text-center" />
                {{ __('poptávaných kusů mezi') }}
            </div>

            <div class="flex justify-center items-center gap-5">
                <x-jet-input type="text" wire:model.defer="hospitals" class="w-20 py-2 text-center" />
                <span class="font-bold">
                    / {{ $hospitalsCount }}
                </span>
                {{ __('zdravotnických zařízení') }}.
            </div>


        </div>

        <div class="text-center">
            <x-jet-input-error for="demand" class="mt-2"/>
            <x-jet-input-error for="hospitals" class="mt-2"/>
        </div>

        <div class="text-center mt-10">
            <x-jet-button
                wire:click="generateSupplyAndDemand()"
                wire:loading.attr="disabled"
                class=" mx-auto"
            >
                {{ __('generovat') }}
            </x-jet-button>
        </div>

    </div>

</x-sections.basic-section>
