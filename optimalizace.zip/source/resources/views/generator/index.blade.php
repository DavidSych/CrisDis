<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('Resetování systému / generování zkušebních dat') }}
            </h2>

            <div class="text-right">
                <!-- place for import button -->
            </div>
        </div>
    </x-slot>

    <div class="mx-auto mt-5 max-w-xl">
        <div class="font-bold">Pstup při generování zkušebních dat</div>

        <ol class="list-decimal ml-4 mt-3">
            <li class="mb-1">
                Resetujet systém pomocí červéného talčítka dole na této stránce<br>
                (Pozor smaže veškerá existující data)
            </li>
            <li class="mb-1">Vygenerujte požadovaný počet zdr. zařízení a dodavatelů</li>
            <li class="mb-1">Vygenerujte základní poptávku po výrobku a dodané množství (<strong>Krok 1</strong>)</li>
            <li class="mb-1">Vyhodnoťte první kolo (<a href="/stock-crisis" class="text-blue-600">zde</a>)</li>
            <li class="mb-1">Vygenerujte požadavky na nákup výrobku a nákup a prodej práv (<strong>Krok 2</strong>)</li>
            <li class="mb-1">Vyhodnoťte druhé kolo (<a href="/stock-crisis" class="text-blue-600">zde</a>)</li>
        </ol>
    </div>

    <livewire:generator.companies />

    <livewire:generator.step1 />

    <livewire:generator.step2 />

    <livewire:generator.reset-system />


    <div class="h-20"></div>
</x-app-layout>

