<x-sections.basic-section class="max-w-5xl mx-auto mt-5">

    <div wire:loading.class="opacity-50">
        <div class="flex justify-center items-center gap-10">
            <div class="font-semibold">
                {{ __('Vymazat všechna data společností:') }}
            </div>
            <x-jet-button
                wire:click="resetDatabase()"
                wire:loading.attr="disabled"
                class="bg-red-700 hover:bg-red-800"
            >
                {{ __('resetovat systém') }}
            </x-jet-button>
        </div>
    </div>

</x-sections.basic-section>
