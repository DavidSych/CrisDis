<x-sections.basic-list-section>

    @if(count($products))
        <div class="bg-white shadow overflow-hidden sm:rounded-md">
            <ul class="divide-y divide-gray-200">
                @foreach($products as $product)
                    <li>
                        <div class="px-4 py-4 sm:px-6 {{ $product->inPortfolio ? 'bg-blue-50 hover:bg-blue-100' : 'hover:bg-gray-50' }}">
                            <div class="flex items-center flex-wrap">
                                <div class="mr-6 text-sm font-semibold text-black  flex-1">
                                    @if($product->url)
                                        <a href="{{ $product->url }}" target="_blank" class="text-blue-800 flex">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                                <path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z" />
                                                <path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z" />
                                            </svg>

                                            {{ $product->name }}
                                        </a>
                                    @else
                                        {{ $product->name }}
                                    @endif
                                </div>
                                <div class="ml-6 text-sm text-black">
                                    @if($product->price === null)
                                        <span class="text-gray-400">&mdash;</span>
                                    @else
                                        {{ format_czk($product->price)  }} Kč
                                    @endif
                                </div>
                                <div class="ml-6 text-sm font-semibold text-black">
                                    <div class="col-span-1 flex justify-end">
                                        <div>
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                 wire:click="editItem({{ $product->id }})"
                                                 class="h-5 w-5 text-gray-400 hover:text-red-300 cursor-pointer"
                                                 fill="none"
                                                 viewBox="0 0 24 24"
                                                 stroke="currentColor"
                                            >
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                            </svg>
                                        </div>

                                        <div class="ml-5">
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                 wire:click="removeItem({{ $product->id }})"
                                                 class="h-5 w-5 text-gray-400 hover:text-red-300 cursor-pointer"
                                                 fill="none"
                                                 viewBox="0 0 24 24"
                                                 stroke="currentColor"
                                            >
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                            </svg>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                @endforeach

            </ul>
        </div>
    @endif

    @livewire('products.product-modal')

</x-sections.basic-list-section>
