<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                Katalog výrobků
            </h2>

            <div class="text-right">
                <!-- place for import button -->
            </div>
        </div>
    </x-slot>

    <x-sections.basic-section>

        Zde naleznete seznam výrobků, které jste vložili do nabídek.

    </x-sections.basic-section>

    @livewire('products.products-grid')

    <div class="h-20"></div>
</x-app-layout>
