<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                Burza - krizový režim
            </h2>
            <div>
            </div>
        </div>
    </x-slot>

    <x-sections.plain-section>

        <div class="grid grid-cols-12 gap-6">


            {{--
            <div class="col-span-7 bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="bg-blue-900 text-white font-semibold tracking-wide px-6 py-4">
                    Poslední transakce
                </div>
                <div class="py-6 bg-white">
                    <ul class="divide-y divide-gray-200">
                        @foreach($transactions as $transaction)
                            <li class="py-4 px-6">
                                @if($transaction->buyer === $company->id)
                                    <div class="font-semibold">
                                        {{ $transaction->stock->name }}
                                    </div>
                                    <div class="text-gray-600">
                                        {{ $transaction->created_at->format('j.n.Y') }}
                                        &nbsp;&ndash;&nbsp;
                                        Koupeno <span
                                            class="font-bold">{{ format_czech($transaction->amount) }} ks</span>
                                        povolenek za <span
                                            class="font-bold">{{ format_czk($transaction->price) }} Kč</span> za kus
                                    </div>
                                @endif

                                @if($transaction->seller === $company->id)
                                    <div class="font-semibold">
                                        {{ $transaction->stock->name }}
                                    </div>
                                    <div class="text-gray-600">
                                        {{ $transaction->created_at->format('j.n.Y') }}
                                        &nbsp;&ndash;&nbsp;
                                        Prodáno <span
                                            class="font-bold">{{ format_czech($transaction->amount) }} ks</span>
                                        povolenek za <span
                                            class="font-bold">{{ format_czk($transaction->price) }} Kč</span> za kus
                                    </div>
                                @endif

                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
            --}}

            <div class="col-span-6 col-start-4 bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="bg-blue-900 text-white font-semibold tracking-wide px-6 py-4">
                    Produkty v krizovém režimu
                </div>
                <div class="py-6 bg-white">
                    <ul class="divide-y divide-gray-200">
                        @foreach($stock as $stockItem)
                            <li>
                                <a href="/auction/article/{{ $stockItem->id }}" class="flex gap-2 py-2 px-6 hover:bg-gray-50">

                                    <span class="text-gray-400">
                                         <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                                        </svg>
                                    </span>

                                    <span class="flex-1">
                                        {{ $stockItem->name }}
                                    </span>

                                    <span>
                                        Etapa: {{ $stockItem->stage }}
                                    </span>

                                    <span class="text-right">
                                        {{--
                                        {!! isset($allowances[$key]) ? format_czech($allowances[$key]) : '&mdash;'  !!} <span class="text-gray-500">ks</span>
                                        --}}
                                    </span>
                                </a>
                            </li>
                        @endforeach
                    </ul>

                    <div class="mt-10 text-center bg-purple-50 border border-purple-300 text-purple-900 p-5 mx-16">
                        Vyberte prosím produkt.
                    </div>
                </div>
            </div>

        </div>
    </x-sections.plain-section>


</x-app-layout>
