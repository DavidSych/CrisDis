<x-sections.plain-section class="max-w-3xl mt-10">

<div class="col-span-6 md:col-span-3 bg-white overflow-hidden shadow-xl sm:rounded-lg">
    <div class="bg-blue-900 text-white font-semibold tracking-wide px-6 py-4">
        Můžeme dodat produkt: {{ $stock->name }}
    </div>
    <div class="py-6 px-10 bg-white">
        <div class="mt-4 flex">
            <div class="flex-1  pr-4">
                <x-jet-label for="amount" class="mt-4">Počet kusů</x-jet-label>
                <x-jet-input class="w-full outline-none" id="amount" wire:model="amount"></x-jet-input>
                <x-jet-input-error for="amount" class="mt-2"/>
            </div>
            <div class="flex-1">
                <x-jet-label for="price" class="mt-4">
                    Cena
                </x-jet-label>
                <x-input.currency-czk class="w-full" id="price" wire:model="price"></x-input.currency-czk>
                <x-jet-input-error for="price" class="mt-2"/>
            </div>
        </div>
    </div>
</div>
</x-sections.plain-section>
