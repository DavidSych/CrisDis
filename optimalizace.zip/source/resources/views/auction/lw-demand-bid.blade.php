<x-sections.plain-section class="max-w-3xl mt-10">

    <div class="col-span-6 md:col-span-3 bg-white overflow-hidden shadow-xl sm:rounded-lg">
        <div class="bg-blue-900 text-white font-semibold tracking-wide px-6 py-4">
            Poptáváme produkt: {{ $stock->name }}
        </div>
        <div class="py-6 px-10 bg-white">
            <div class="mt-4 flex">
                <div class="flex-1  pr-4">
                    <x-jet-label for="amount" class="mt-4">Počet kusů</x-jet-label>
                    <x-jet-input class="w-full outline-none" id="amount" wire:model="amount"></x-jet-input>
                    <x-jet-input-error for="amount" class="mt-2"/>
                </div>
            </div>

            <div class="mt-4 flex">
                <div class="flex-1  pr-4">
                    <x-jet-label for="credit" class="mt-4">Prostředky dosupné na nákup tohoto výrobku (Kč celkem)</x-jet-label>
                    <x-jet-input class="w-full outline-none" id="credit" wire:model="credit"></x-jet-input>
                    <x-jet-input-error for="credit" class="mt-2"/>
                </div>
            </div>

            <div class="mt-12 text-center bg-blue-50 border border-blue-300 text-blue-900 p-5 mx-16 rounded">
                Zde vyplněné hodnoty můžete měnit až to ukončení prvníko kola. Pak budou vyplněné údaje automaticky zpracovány.
            </div>
        </div>
    </div>
</x-sections.plain-section>
