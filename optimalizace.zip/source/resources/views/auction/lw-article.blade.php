<div class="max-w-3xl gap-6 pt-12 mx-auto grid grid-cols-6">

    <x-jet-dialog-modal wire:model="showDialog">
        <x-slot name="title">
            <h2 class="text-md">
            @if($type == 'buying')
                Koupit práva pro:
            @elseif($type == 'selling')
                Prodat práva pro:
            @else
                Koupit produkt:
            @endif
            </h2>

            <div class="text-xl mt-2 font-semibold">{{ $stock->name }}</div>
        </x-slot>

        <x-slot name="content">
            <input type="hidden" value="cena" name="type">

            <div class="mt-4 flex">
                <div class="flex-1  pr-4">
                    <x-jet-label for="amount" class="mt-4">{{ $type == 'product' ? 'Počet výrobků' : 'Počet práv' }}</x-jet-label>
                    <x-jet-input class="w-full outline-none" id="amount" wire:model.defer="state.amount"></x-jet-input>
                    <x-jet-input-error for="amount" class="mt-2"/>
                </div>
                <div class="flex-1">
                    <x-jet-label for="price" class="mt-4">
                        @if ($type == 'buying')
                            Maximální cena za jedno právo
                        @elseif ($type == 'selling')
                            Minimální cena za jedno právo
                        @else
                            Maximální cena za jeden kus
                        @endif
                    </x-jet-label>
                    <x-input.currency-czk class="w-full" id="price" wire:model.defer="state.price"></x-input.currency-czk>
                    <x-jet-input-error for="price" class="mt-2"/>
                </div>
            </div>
        </x-slot>

        <x-slot name="footer">
            <div class="flex">

                <div class="rounded-md flex-1 text-left">
                    <x-button-light wire:click="cancelDialog()">{{ __('cancel') }}</x-button-light>
                </div>

                <span class="rounded-md text-right">
                  <x-jet-button wire:click="save()">{{ __('Save') }}</x-jet-button>
                </span>
            </div>


        </x-slot>
    </x-jet-dialog-modal>

    <div class="col-span-6 bg-white overflow-hidden shadow-xl sm:rounded-lg">
        <div class="p-6 flex-1">
            <div class="font-semibold text-lg">{{ $stock->name }}</div>

            <div class="pt-6 bg-white flex">
                <div class="pr-8">
                    Množství práv k nákupu výrobku:  <span class="font-semibold ml-2">{{ format_czech($availableAllowance) }}</span>
                </div>
                <duv>
                    Rezervované množství práv: <span  class="font-semibold ml-2">{{ format_czech($reservedAllowance) }}</span>
                </duv>
            </div>
        </div>

    </div>

    <div class="col-span-6 md:col-span-6 bg-white overflow-hidden shadow-xl sm:rounded-lg">
        <div class="bg-blue-900 text-white font-semibold tracking-wide px-6 py-4">
            Poptávám výrobky
        </div>
        <div class="py-6 bg-white">
            <ul class="w-full divide-gray-200 divide-y">
                @foreach($bidsProduct as $bid)
                    <li class="py-2 px-6 flex cursor-pointer hover:bg-gray-50" wire:click="editBid({{ $bid->id}})">
                        <div class="flex-1" >
                            Poptávám <span class="font-bold">{{ format_czech($bid->amount) }}</span> výrobků za cenu <span class="font-bold">{{ format_czk($bid->price) }} Kč</span> za kus
                        </div>
                        <div>
                            <button class="text-gray-700 hover:text-red-600" wire:click.stop="removeBid({{$bid->id}})">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                            </button>
                        </div>
                    </li>
                @endforeach
            </ul>

            @if(!count($bidsProduct))
            <div class="mt-1 text-center">

                <x-jet-button wire:click="openDialog('product')">
                    Poptat výrobky
                </x-jet-button>
            </div>
            @endif
        </div>
    </div>

    <div class="col-span-6 md:col-span-6 bg-white overflow-hidden shadow-xl sm:rounded-lg">
        <div class="bg-blue-900 text-white font-semibold tracking-wide px-6 py-4">
            Poptávám práva
        </div>
        <div class="py-6 bg-white">
            <ul class="w-full divide-gray-200 divide-y">
                @foreach($bidsBuying as $bid)
                    <li class="py-2 px-6 flex cursor-pointer hover:bg-gray-50" wire:click="editBid({{ $bid->id}})">
                        <div class="flex-1">
                            Poptávám <span class="font-bold">{{ format_czech($bid->amount) }}</span>  práv za cenu <span class="font-bold">{{ format_czk($bid->price) }} Kč</span> za kus
                        </div>
                        <div>
                            <button class="text-gray-700 hover:text-red-600" wire:click.stop="removeBid({{$bid->id}})">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                            </button>
                        </div>
                    </li>
                @endforeach
            </ul>

            @if(!count($bidsBuying))
            <div class="mt-1 text-center">
                <x-jet-button wire:click="openDialog('buying')">
                    Poptat práva
                </x-jet-button>
            </div>
            @endif
        </div>

    </div>

    <div class="col-span-6 md:col-span-6 bg-white overflow-hidden shadow-xl sm:rounded-lg">
        <div class="bg-blue-900 text-white font-semibold tracking-wide px-6 py-4">
            Nabízím práva
        </div>
        <div class="py-6 bg-white">
            <ul class="w-full divide-gray-200 divide-y">
                @foreach($bidsSelling as $bid)
                    <li class="py-2 px-6 flex cursor-pointer hover:bg-gray-50" wire:click="editBid({{ $bid->id}})">
                        <div class="flex-1" >
                            Prodávám <span class="font-bold">{{ format_czech($bid->amount) }}</span> práv za cenu <span class="font-bold">{{ format_czk($bid->price) }} Kč</span> za kus
                        </div>
                        <div>
                            <button class="text-gray-700 hover:text-red-600" wire:click.stop="removeBid({{$bid->id}})">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                            </button>
                        </div>
                    </li>
                @endforeach
            </ul>

            @if(!count($bidsSelling))
            <div class="mt-1 text-center">
                <x-jet-button wire:click="openDialog('selling')">
                    Prodat práva
                </x-jet-button>
            </div>
            @endif

        </div>
    </div>

    <div class="col-span-6 md:col-span-6">
        <div class="mt-12 text-center bg-blue-50 border border-blue-300 text-blue-900 p-5 mx-16 rounded">
            Na základě vaší poptávky z prvního kola dopuručujeme:

            <div class="text-black mt-4">
                Koupit <strong>{{ $advisedAmount }} kusů</strong> za cenu <strong>{{ $advisedPrice }} Kč</strong>.
            </div>

            @if($availableAllowance - $advisedAmount > 0)
            <div class="text-black mt-4">
                Prodat <strong>{{ $availableAllowance - $advisedAmount }} práv</strong> za cenu <strong>{{ $advisedPrice }} Kč</strong>.
            </div>
            @endif
            @if($availableAllowance - $advisedAmount < 0)
                <div class="text-black mt-4">
                    Koupit <strong>{{ ($availableAllowance - $advisedAmount) * - 1 }} práv</strong> za cenu <strong>{{ $advisedPrice }} Kč</strong>.
                </div>
            @endif

        </div>
    </div>



</div>
