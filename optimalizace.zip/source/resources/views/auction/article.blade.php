<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                Burza
            </h2>
            <div>
                @if($stock->inBiddingStage())
                    @livewire('auction.available-credit', [
                        'company' => request()->user()->company
                    ])
                @endif
            </div>
        </div>
    </x-slot>


    @if($stock->inMappingStage() && request()->user()->company->isSupplier() )
        <livewire:auction.supply-amount-bid :stock-id="$stock->id"/>
    @endif

    @if($stock->inMappingStage() && request()->user()->company->isHealthProvider() )
        <livewire:auction.demand-amount-bid :stock-id="$stock->id"/>
    @endif


    @if($stock->inBiddingStage() && request()->user()->company->isHealthProvider())
        @livewire('auction.article', [
            'company' => request()->user()->company,
            'stock' => $stock,
        ])
    @endif

    @if($stock->inResultsStage())
        <div class="max-w-3xl gap-6 pt-12 mx-auto grid grid-cols-6">

            <div class="col-span-6 bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="p-12 bg-white text-center font-bold">
                    Toto kolo aukce bylo ukončeno. Počkejte prosím na otevření dalšího.
                </div>
            </div>

        </div>
    @endif



</x-app-layout>
