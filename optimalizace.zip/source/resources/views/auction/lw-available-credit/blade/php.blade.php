<div class="flex gap-6">

    <div class="text-gray-600">{{ $company->name }}</div>

    <div class="text-gray-600">
        Dostupný kredit: <span class="font-semibold text-black ml-2">{{ App\Helpers\AppHelper::formatCzk($availableCredit) }} Kč</span>
    </div>

    <div class="text-gray-600">
        Rezervovaný kredit: <span class="font-semibold text-black ml-2">{{ App\Helpers\AppHelper::formatCzk($reservedCredit) }} Kč</span>
    </div>
</div>
