<x-sections.basic-list-section>

    @if(count($stock))
        <div class="bg-white shadow overflow-hidden sm:rounded-md">
            <ul class="divide-y divide-gray-200">
                @foreach($stock as $stockItem)
                    <li wire:click="togglePortfolioItem({{$stockItem->id}})">
                        <div class="px-4 py-4 sm:px-6 cursor-pointer {{ $stockItem->inPortfolio ? 'bg-blue-50 hover:bg-blue-100' : 'hover:bg-gray-50' }}">
                            <div class="flex items-center flex-wrap">
                                <div class="mr-6">
                                    <input type="checkbox" {{ $stockItem->inPortfolio ? 'checked="checked"': '' }}>
                                </div>
                                <div class="mr-6 text-sm font-medium text-black">
                                    {{ $stockItem->name  }}
                                    <span class="font-semibold ml-4">({{ $stockItem->code }})</span>
                                </div>
                            </div>
                        </div>
                    </li>
                @endforeach

            </ul>
        </div>
    @endif

</x-sections.basic-list-section>
