<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('Stock') }}
            </h2>

            <div class="text-right">
                <!-- place for import button -->
            </div>
        </div>
    </x-slot>

    <x-sections.basic-section>

        Vyberte prosím materiál, které Vaše firma dodává. Na základě tohoto výběru bude možné filtrovat zobrazené otevřené poptávky.

    </x-sections.basic-section>

    @livewire('stock.stock-portfolio')

    <div class="h-20"></div>
</x-app-layout>
