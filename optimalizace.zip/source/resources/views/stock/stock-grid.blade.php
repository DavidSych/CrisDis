<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('Stock overview') }}
            </h2>

            <div class="text-right">
                <!-- place for import button -->
            </div>
        </div>
    </x-slot>

    <x-sections.basic-section>

        @livewire('stock.stock-grid', [
            'perPage' => '25',
            'searchable' => 'id,name',
            'hideable' => 'select',
        ])

    </x-sections.basic-section>
</x-app-layout>
