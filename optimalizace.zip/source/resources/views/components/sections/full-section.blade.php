<div class="pt-12">
    <div class="w-full mx-auto sm:px-4 lg:px-6">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <div class="p-0 sm:px-8 bg-white border-b border-gray-200 py-8 ">

                {{ $slot }}

            </div>
        </div>
    </div>
</div>
