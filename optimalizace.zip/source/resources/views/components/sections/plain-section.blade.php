@props([
    'class' => 'max-w-7xl pt-12',
])

<div class="{{ $class }} mx-auto px-4 sm:px-6 lg:px-8">
    {{ $slot }}
</div>
