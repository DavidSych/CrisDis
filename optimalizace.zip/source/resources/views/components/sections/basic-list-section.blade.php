@props([
    'size' => 'max-w-7xl',
    'class' => 'pt-12',
])

<div class="{{ $class }}">
    <div class="{{ $size }} mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            @if(!empty($title))
            <div class="bg-blue-900 text-white font-semibold tracking-wide px-6 py-4">
                {{ $title }}
            </div>
            @endif
            <div class="p-0 bg-white">

                {{ $slot }}

            </div>
        </div>
    </div>
</div>
