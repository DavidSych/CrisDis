@props([
    'size' => 'max-w-7xl',
    'class' => 'pt-12',
])

<div class="{{ $class }}">
    <div class="{{ $size }} mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <div class="p-0 px-4 md:px-8 bg-white border-b border-gray-200 py-8 ">

                {{ $slot }}

            </div>
        </div>
    </div>
</div>
