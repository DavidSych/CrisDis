@props(['disabled' => false])

<div class="relative form-input rounded-md shadow-sm p-3 border border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm">
    <input {{ $disabled ? 'disabled' : '' }}  placeholder="0.00" aria-describedby="price-currency" {{ $attributes->merge(['class' => 'outline-none  mr-8']) }}>

    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
        <span class="text-gray-500 sm:text-sm sm:leading-5" id="price-currency">
            {{ __('Kč')  }}
        </span>
    </div>
</div>
