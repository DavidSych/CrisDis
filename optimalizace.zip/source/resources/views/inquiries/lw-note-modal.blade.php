<x-jet-dialog-modal wire:model="dialogVisible">
    <x-slot name="title">{{ $stockItem->name ?? '' }}</x-slot>

    <x-slot name="content">

        <div class="mt-4 flex">
            <div class="flex-1">
                <x-jet-label>Poznámka</x-jet-label>
                <textarea  wire:model.defer="state.note" id="note" autocomplete="off" class="w-full p-3 border border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm"></textarea>
                <x-jet-input-error for="note" class="mt-2" />
            </div>
        </div>

    </x-slot>

    <x-slot name="footer">
        <div class="flex">

            <div class="rounded-md flex-1 text-left">
                <x-button-light wire:click="close()">{{ __('cancel') }}</x-button-light>
            </div>

            <div class="rounded-md">
                <x-jet-button wire:click="createProject()">Uložit poznámku</x-jet-button>
            </div>
        </div>

    </x-slot>


</x-jet-dialog-modal>
