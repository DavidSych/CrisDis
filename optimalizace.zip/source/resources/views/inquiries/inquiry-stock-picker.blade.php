<div>

    <div class="flex items-center">

        <div class="flex-1">
            Hledat materiál
        </div>

        <div class="mr-2">
            <svg xmlns="http://www.w3.org/2000/svg" class="text-gray-400 h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
        </div>
        <div>
            <x-jet-input type="text" wire:model="query" placeholder="{{ 'name (at least 3 chars)' }}" />
        </div>

    </div>



    @if(count($results))
    <div class="bg-white shadow overflow-hidden sm:rounded-md mt-8">
        <ul class="divide-y divide-gray-200">
            @foreach($results as $result)
            <li>
                <a href="#" class="block {{ $result->crisis_mode ? 'bg-red-50 cursor-not-allowed' : 'hover:bg-gray-50' }}" wire:click.prevent="addStockItem({{$result->id}})">
                    <div class="px-4 py-4 sm:px-6">
                        <div class="flex items-center">
                            <p class="text-sm font-medium uppercase font-bold text-black truncate w-24">
                                {{ $result->code }}
                            </p>
                            <p class="text-sm font-medium text-black truncate flex-1">
                                {{ $result->name }}
                            </p>
                            <div class="ml-2 flex-shrink-0 flex">
                                @if($result->crisis_mode)
                                    <p class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-200 text-red-700">
                                        Položka nelze přidat - krizový režim
                                    </p>
                                @elseif($result->selected)
                                    <p class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-700">
                                        {{$result->selected}}x v poptávce
                                    </p>
                                @else
                                    <p class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-600">
                                        přidat do poptávky
                                    </p>
                                @endif
                            </div>
                        </div>
                    </div>
                </a>
            </li>
            @endforeach

        </ul>
    </div>
    @endif

</div>
