<div>
    @if(count($stock))
    <div class="bg-white shadow overflow-hidden sm:rounded-md mt-8">
        <ul class="divide-y divide-gray-200">
            @foreach($stock as $stockItem)
            <li>
                <div class="block hover:bg-gray-50">
                    <div class="px-4 py-4 sm:px-6">
                        <div class="grid grid-cols-12 gap-4">
                            <div class="text-sm font-medium col-span-3">
                                <span class="text-black font-bold uppercase"></span>{{ $stockItem->code }}
                                <span class="ml-4">{{ $stockItem->name }}</span>
                            </div>
                            <div class="{{ ($showDates) ? 'col-span-5' :  'col-span-7' }} flex">
                                <div class="mr-4">
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                         wire:click="openNoteModal({{ $stockItem->pivot->id }})"
                                         class="h-6 w-6 text-gray-400 hover:text-red-300 cursor-pointer"
                                         fill="none"
                                         viewBox="0 0 24 24"
                                         stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
                                    </svg>
                                </div>
                                <div class="flex-1 flex-wrap text-sm text-gray-600 italic">{{ $stockItem->pivot->note }}</div>
                            </div>
                            @if($showDates)
                            <div class="col-span-2" >
                                <input type="text"
                                       id="stockDate{{ $stockItem->pivot->id }}"
                                       placeholder="{{ __('Due date') }}"
                                       value="{{$stockItem->pivot->delivery_date}}"
                                       wire:change="updateStockDeliveryDate({{$stockItem->pivot->id}},  document.getElementById('stockDate' + {{$stockItem->pivot->id}}).value)"
                                       class="flatpickr text-center text-xs p-2 border border-gray-300 w-full focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm"
                                />
                            </div>
                            @endif
                            <div class="col-span-2 flex">
                                <div>
                                    <input type="number"
                                           id="stockAmount{{ $stockItem->pivot->id }}"
                                           value="{{$stockItem->pivot->amount}}"
                                           min="1"
                                           wire:change="updateStockAmount({{$stockItem->pivot->id}},  document.getElementById('stockAmount' + {{$stockItem->pivot->id}}).value)"
                                           class="text-center text-xs p-2 border border-gray-300 w-full focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm"
                                    />
                                </div>


                                <div class="ml-2 flex-shrink-0 flex pl-4">
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                         class="h-6 w-6 text-gray-400 hover:text-red-300 cursor-pointer"
                                         fill="none"
                                         viewBox="0 0 24 24"
                                         stroke="currentColor"
                                         wire:click="removeStockItem({{ $stockItem->pivot->id }})"
                                    >
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                    </svg>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </li>
            @endforeach

        </ul>
    </div>
    @endif

    @livewire('inquiries.note-modal')



</div>
