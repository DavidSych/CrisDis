<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('Inquiry') }}
            </h2>

            <div class="text-right">
                #{{ str_pad($inquiry->id, 7, '0', STR_PAD_LEFT) }}
            </div>
        </div>
    </x-slot>

    <x-sections.basic-section>
        @livewire('inquiries.inquiry-stock-picker', [
            'inquiryId' => $inquiry->id
        ])
    </x-sections.basic-section>

    <x-sections.basic-section>
        <h1 class="text-xl">{{ __('Inquiry items') }}</h1>

        @livewire('inquiries.inquiry-stock-list', [
            'inquiryId' => $inquiry->id
        ])
    </x-sections.basic-section>

    <x-sections.basic-section>
        <h1 class="text-xl">{{ __('Inquiry details') }}</h1>

        @livewire('inquiries.inquiry-dates', [
            'inquiryId' => $inquiry->id
        ])

        @livewire('inquiries.inquiry-details', [
            'inquiryId' => $inquiry->id
        ])
    </x-sections.basic-section>

    <x-sections.basic-section>
        <div class="text-center">

        @if($inquiry->status == 1 && count($errorMessages))
            <div class="mb-4">
                @foreach($errorMessages as $message)
                    <p class="text-lg text-red-600">{{ $message }}</p>
                @endforeach
            </div>
        @endif

        @if($inquiry->status == 1)
            <x-button-link
                href="{{ route('inquiries.save', ['id' => $inquiry->id]) }}"
                class="text-lg"
            >
                Zkontrolovat poptávku před zveřejněním
            </x-button-link>
        @elseif($inquiry->status == 2)
            <span class="text-lg">Poptávka je zveřejněna</span>
        @endif
    </div>
    </x-sections.basic-section>

    <div class="pb-8"></div>

    <script>
        setTimeout(function() {
            flatpickr(".flatpickr", {
                "locale": "cs",  // locale for this instance only,
                altInput: true,
                altFormat:" j. n. Y"
            }, 50);
        })
    </script>
</x-app-layout>
