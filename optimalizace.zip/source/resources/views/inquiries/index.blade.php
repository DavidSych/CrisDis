<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('My Inquiries') }}
            </h2>
            <div>
                <x-jet-button onClick="window.location = '/inquiries/create'">{{ __('Create new inquiry') }}</x-jet-button>
            </div>
        </div>
    </x-slot>

    <x-sections.basic-list-section>

        <x-slot name="title">Moje rozpracované poptávky</x-slot>

        @livewire('inquiries.inquiry-list', [
            'status' => 1,
        ])

    </x-sections.basic-list-section>

    <x-sections.basic-list-section>

        <x-slot name="title">Moje zveřejněné poptávky</x-slot>

        @livewire('inquiries.inquiry-list', [
            'status' => 2,
        ])

    </x-sections.basic-list-section>
</x-app-layout>
