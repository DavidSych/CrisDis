<div>

    <form wire:submit.prevent="save()">

        <div class="grid grid-cols-6 gap-4 my-6">
            <!-- DIČ -->
            <div class="col-span-6 md:col-span-3 lg:col-span-2">
                <x-jet-label for="offers_due" value="{{ __('To be deliver by date') }}" />
                <x-jet-input id="offers_due" type="text" class="mt-1 block w-full flatpickr" wire:model="state.delivery_date" autocomplete="offers_due" />
                <x-jet-input-error for="offers_due" class="mt-2" />
            </div>

            <!-- DIČ -->
            <div class="col-span-6 md:col-span-3 lg:col-span-2">
                <x-jet-label for="delivery_date" value="{{ __('Inquiry expiration date') }}" />
                <x-jet-input id="delivery_date" type="text" class="mt-1 block w-full flatpickr" wire:model="state.offers_due" autocomplete="delivery_date" />
                <x-jet-input-error for="delivery_date" class="mt-2" />
            </div>
        </div>
    </form>
</div>
