<div>

    <form wire:submit.prevent="save()">

        <div class="grid grid-cols-6 gap-4 my-6">
            <!-- DIČ -->
            <div class="col-span-6 md:col-span-3 lg:col-span-2 md:my-4">
                <label class="flex items-center">
                    <x-jet-checkbox wire:model="state.allow_partial_offers" />
                    <span class="ml-2 text-sm text-gray-600">{{ __('Allow partial offers') }}</span>
                </label>
            </div>

            <!-- DIČ -->
            <div class="col-span-6 md:col-span-3 lg:col-span-2 md:my-4">
                <label class="flex items-center">
                    <x-jet-checkbox wire:model="state.separate_dates" />
                    <span class="ml-2 text-sm text-gray-600">{{ __('Separate dates for items') }}</span>
                </label>
            </div>

            <div class="col-span-6 md:col-span-6 lg:col-span-2">

            </div>

            <div class="col-span-6 md:col-span-6 lg:col-span-4">
                <x-jet-label for="note" value="{{ __('Additional information') }}" />
                <textarea
                    id="dic"
                    wire:model.debounce.500ms="state.note"
                    class="p-3 border border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm mt-1 block w-full id-flatpickr flatpickr-input active"
                ></textarea>
                <x-jet-input-error for="note" class="mt-2" />
            </div>

        </div>
    </form>
</div>
