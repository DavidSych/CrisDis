<div>
    @if(count($inquiries))
        <ul class="divide-y divide-gray-200">
            @foreach($inquiries as $inquiry)
                <li>
                    @if($inquiry->status == 1)
                    <a href="{{ route('inquiries.update', ['id' => $inquiry->id]) }}"
                    @else
                    <a href="{{ route('inquiries.preview', ['id' => $inquiry->id]) }}"
                    @endif
                       class="block hover:bg-gray-50"
                    >
                        <div class="px-4 py-4 sm:px-6">
                            <div class="flex items-center flex-wrap">
                                <p class="mr-8">
                                    <span class="text-sm @if($inquiry->status == 1) text-blue-600 @elseif($inquiry->status == 2) text-green-600 @endif">⬤</span>
                                </p>
                                <p class="text-sm font-medium uppercase font-bold text-black w-24">
                                    #{{ str_pad($inquiry->id, 7, '0', STR_PAD_LEFT) }}
                                </p>
                                <p class="text-sm font-medium text-black flex-1">
                                    Počet položek: {{ $inquiry->stock()->count() }}

                                    @if($inquiry->getOffersCount())
                                        <span class="ml-8">
                                            Počet nabídek: {{ $inquiry->getOffersCount() }}
                                        </span>
                                    @endif
                                </p>

                                @if($inquiry->status == 1)
                                    <div class="ml-8 text-sm flex-shrink-0 flex">
                                        Vytvořeno: <span class="ml-2 font-semibold">{{ format_date($inquiry->created_at) }}</span>
                                    </div>
                                @endif

                                @if($inquiry->delivery_date)
                                    <div class="ml-8 text-sm flex-shrink-0 flex">
                                        Datum dodání: <span class="ml-2 font-semibold">{{ format_date($inquiry->delivery_date) }}</span>
                                    </div>
                                @endif

                                @if($inquiry->offers_due)
                                    <div class="ml-8 text-sm flex-shrink-0 flex">
                                        Zveřejněno do: <span class="ml-2 font-semibold">{{ format_date($inquiry->offers_due) }}</span>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </a>
                </li>
            @endforeach
        </ul>
    @else
        <div class="py-4 px-6">Nejsou zde žádné poptávky.</div>
    @endif
</div>
