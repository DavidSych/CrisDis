<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                @if(isset($title))
                    {{ $title }}
                @else
                    Detail zveřejněné poptávky
                @endif
            </h2>
        </div>
    </x-slot>

    <x-sections.basic-section>

        <div class="grid gap-4 grid-cols-6">

            <div class="col-span-6 md:col-span-3 lg:col-span-2">
                <p class="text-lg mb-8 font-semibold">Základní informace</p>

                <div class="mb-3">
                    Zadavatel:
                    <span class="ml-2 font-semibold text-blue-800">
                        <a onClick="Livewire.emit('openCompanyInfoModal', {{ $inquiry->company->id }}); return false;" href="#">
                            {{ $inquiry->company->name }}

                            <svg xmlns="http://www.w3.org/2000/svg" class="inline-block h-5 w-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </a>
                    </span>
                </div>

                <div class="mb-3">
                    Číslo poptávky: <span class="ml-2 font-semibold">#{{ str_pad($inquiry->id, 7, '0', STR_PAD_LEFT) }}</span>
                </div>

                 <div class="mb-3">
                    Datum dodání: <span class="ml-2 font-semibold">{{ format_date($inquiry->delivery_date) }}</span>
                </div>

                <div class="mb-3">
                    Zveřejněnno do: <span class="ml-2 font-semibold">{{ format_date($inquiry->offers_due) }}</span>
                </div>

                <div class="mb-3">
                    Možnost částečné nabídky: <span class="ml-2 font-semibold"> {{ $inquiry->allow_partial_offers ? 'ano': 'ne' }}</span>
                </div>

                <div class="mt-8">
                    <div class="mb-2">Poznámka:</div>

                    <div>
                        {{ $inquiry->note }}
                    </div>

                </div>

            </div>

            <div class="col-span-6 md:col-span-3 lg:col-span-4 text-sm">
                <p class="text-lg mb-8 font-semibold">Poptávaný materiál</p>

            <table class="w-full">
                <tr class="border-b border-gray-200">
                    @if($inquiry->separate_dates)
                        <td class="py-2 pr-8 font-bold">datum</td>
                    @endif
                    <td  class="text-right py-2 pr-8 font-bold">poč.</td>
                    <td  class="text-right py-2 pr-8 font-bold">kód</td>
                    <td class="py-2 w-full font-bold">položka</td>
                </tr>
                @foreach($inquiry->stock as $stockItem)
                    <tr class="border-b border-gray-200 align-top">
                        @if($inquiry->separate_dates)
                            @if($stockItem->pivot->delivery_date)
                            <td class="py-2 pr-8 font-bold">{{ format_date($stockItem->pivot->delivery_date) }}</td>
                            @else
                                <td class="py-2 pr-8">{{ format_date($inquiry->delivery_date) }}</td>
                            @endif
                        @endif
                        <td  class="text-right py-2 pr-8">{{ $stockItem->pivot->amount }}</td>
                        <td  class="text-right py-2 pr-8">{{ $stockItem->code }}</td>
                        <td class="py-2 w-full">
                            {{ $stockItem->name }}
                            @if($stockItem->pivot->note)
                                <div class="text-gray-500 italic">{{ $stockItem->pivot->note }}</div>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </div>
            </table>

        </div>

    </x-sections.basic-section>

    @if(!isset($preview) || !$preview)
    <x-sections.basic-section>
        <div class="text-center">
            @if($inquiry->status == 2 && !$hasOffer)
                <x-button-link
                    href="/offers/create/{{$inquiry->id}}"
                    class="text-lg"
                >
                    Vytvořit nabídku
                </x-button-link>
            @elseif($inquiry->status == 2 && $hasOffer)
                <div class="text-lg">Vaše společnost už vytvořila nabídky k této poptávce.</div>

                <x-button-link
                    href="/offers/{{ $offerId }}/update"
                    class="text-md mt-4"
                >
                    zobrazit nabídku
                </x-button-link>
            @else
                <span class="text-lg">Není možné podávat nabídky</span>
            @endif
        </div>
    </x-sections.basic-section>
    @endif

    @if(isset($preview) && $preview)
        <x-sections.basic-section>
            <div class="text-center">
                @if($inquiry->status == 1)

                    <form method="post" action="{{ route('inquiries.make-public', ['id' => $inquiry->id]) }}">
                        @csrf

                        <div class="mb-10">
                            <div class="flex justify-center">
                                <div class="mr-6">
                                    <input type="checkbox" name="approval" id="approval">
                                </div>
                                <div>
                                    <label for="approval">Prohlášení o pravdivostí údajů (bude doplněno)</label>
                                </div>
                            </div>

                            <div>
                                <x-jet-input-error for="approval" class="mt-2" />
                            </div>
                        </div>

                        <div class="flex justify-center items-center">
                            <x-button-link href="{{ route('inquiries.update', ['id' => $inquiry->id]) }}" class="mr-10">
                                upravit poptávku
                            </x-button-link>

                            <x-jet-button type="submit" class="text-lg">
                                Zveřejnit poptávku
                            </x-jet-button>
                        </div>


                    </form>
                @elseif($inquiry->status == 2)
                    <span class="text-lg">Poptávka je zveřejněna.</span>
                @endif
            </div>
        </x-sections.basic-section>

        @if($inquiry->getOffersCount())
        <x-sections.basic-list-section>

            <x-slot name="title">Nabídky</x-slot>

            <ul class="divide-y divide-gray-200">
                @foreach($inquiry->activeOffers as $offer)
                    <li>
                        <a href="{{ route('offers.preview', ['id' => $offer->id]) }}"
                           class="block hover:bg-gray-50"
                        >
                            <div class="px-4 py-4 sm:px-6">
                                <div class="flex items-center flex-wrap">
                                    <p class="mr-12">
                                        {{ $offer->company->name }}
                                    </p>
                                    <p class="text-sm font-medium  text-black">
                                        <?php $priceRange = $offer->getPriceRange(); ?>

                                            @if($priceRange['from'] != $priceRange['to'])
                                                <span class="font-bold">{{ format_czk($priceRange['from']) }} Kč</span> až <span class="font-bold">{{ format_czk($priceRange['to']) }} Kč</span>
                                            @else
                                                <span class="font-bold">{{ format_czk($priceRange['from']) }} Kč
                                            @endif
                                    </p>
                                </div>
                            </div>
                        </a>
                    </li>
                @endforeach
            </ul>
        </x-sections.basic-list-section>
        @endif

    @endif

    <livewire:companies.company-info-modal></livewire:companies.company-info-modal>

</x-app-layout>
