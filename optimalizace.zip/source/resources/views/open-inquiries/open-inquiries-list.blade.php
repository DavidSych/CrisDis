<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('Open inquiries') }}
            </h2>
        </div>
    </x-slot>

    <x-sections.basic-list-section>

        <x-slot name="title">{{ __('Open inquiries') }}</x-slot>

        @if(count($inquiries))
            <div class="bg-white shadow overflow-hidden sm:rounded-md">
                <ul class="divide-y divide-gray-200">
                    @foreach($inquiries as $inquiry)
                        <li>
                            <a href="{{ route('open-inquiries.detail', ['id' => $inquiry->id]) }}"
                               class="block hover:bg-gray-50"
                            >
                                <div class="px-4 py-4 sm:px-6">
                                    <div class="flex items-center flex-wrap">
                                        <p class="text-sm font-medium uppercase font-bold text-black w-24">
                                            #{{ str_pad($inquiry->id, 7, '0', STR_PAD_LEFT) }}
                                        </p>
                                        <p class="mr-6 text-sm font-medium text-black">
                                            {{ $inquiry->company->name }}
                                        </p>
                                        <p class="mr-6 text-sm font-medium text-black">
                                            Počet položek: {{ $inquiry->stock()->count() }}
                                        </p>

                                        <p class="text-sm font-medium text-green-600 flex-1">
                                            @if($inquiry->offerCreated)
                                                vytvořena nabídka
                                            @endif
                                        </p>

                                        @if($inquiry->delivery_date)
                                            <div class="ml-8 text-sm flex-shrink-0 flex">
                                                Datum dodání: <span class="ml-2 font-semibold">{{ format_date($inquiry->delivery_date) }}</span>
                                            </div>
                                        @endif

                                        @if($inquiry->offers_due)
                                            <div class="ml-8 text-sm flex-shrink-0 flex">
                                                Zveřejněno do: <span class="ml-2 font-semibold">{{ format_date($inquiry->offers_due) }}</span>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </a>
                        </li>
                    @endforeach

                </ul>
            </div>
        @endif

    </x-sections.basic-list-section>
</x-app-layout>
