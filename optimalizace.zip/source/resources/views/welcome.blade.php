<x-guest-layout>

        <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">
            @if (Route::has('login'))
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    @auth
                        <a href="{{ url('/dashboard') }}" class="text-sm text-gray-700 underline">Dashboard</a>
                    @else
                        <a href="{{ route('login') }}" class="text-sm text-gray-700 underline">{{ __("Log in") }}</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="ml-4 text-sm text-gray-700 underline">{{ __("Register") }}</a>
                        @endif
                    @endauth
                </div>
            @endif

            <!-- This example requires Tailwind CSS v2.0+ -->
                <div class="bg-white rounded-lg max-w-4xl mx-auto mt-10 mb-10">
                    <div class="px-4 sm:px-6 lg:px-8 py-6 bg-blue-900 text-white rounded-t rounded-lg rounded-b-none">
                        <h1 class="text-2xl">Předběžný Informační Portál (PIP)</h1>
                    </div>

                    <div class="px-4 sm:px-6 lg:px-8 py-6">
                        <p class="mb-2">je platforma pro provádění předběžných tržních konzultací zejména pro drobný zdravotnický materiál podle ust. § 33 zákona č. 134/2016 Sb., o zadávání veřejných zakázek, ve znění pozdějších předpisů.</p>

                        <p class="mb-2">Cílem je sjednotit a usnadnit práci s přípravou veřejných zakázek na drobný zdravotnický materiál ve zdravotnických a sociálních zařízeních pro nakupující i prodávající. Výhledově, po ověření konceptu a užitečnosti PIP uživateli, chceme na základě PIP iniciovat vytvoření certifikovaného portálu veřejných zakázek, kde půjde veřejné zakázky také realizovat.</p>

                        <p class="mb-2">Kromě sjednocení a usnadnění práce nakupujícím a prodávajícím je motivací vytvoření PIP také práce na sytému krizové distribuce.</p>


                        <h2 class="text-2xl mb-4 mt-8">CrisDis: systém pro distribuci v krizi</h2>

                        <p class="mb-2">Distribuční krize je charakterizována velkým nepoměrem nabídky a poptávky pro určité zboží, například respirátory.</p>

                        <p class="mb-2">Protože ani volný trh, ani rozhodování centrální autority nejsou společensky nejvýhodnější řešení, navrhujeme hybridní model založený na autonomním chování účastníků.</p>

                        <p class="mb-2 italic">Cílem je rozšířit tok peněz a kritického zboží, který je v krizi koncentrovaný mezi prodávajícími a aktivními (bohatšími) nakupujícími, o váhající (chudší) nakupující.</p>

                        <p class="mb-2">Nyní popíšeme hlavní nápad našeho řešení. Pro zjednodušení předpokládejme, že se jedná jen o jeden druh zboží, a označme ho G.</p>

                        <p class="mb-2">Náš model sestává z posloupnosti trhů v čase: první trh probíhá v čase jedna, až skončí, začne druhý trh a tak dále. Každý trh má dvě části:</p>

                        <ol class="list-decimal ml-4 mb-2">
                            <li>Prodejci oznámí nabídku G, nákupci oznámí poptávku po G, která silně převyšuje nabídku. Na základě tohoto vstupu systém přiřadí, podle předem dohodnutých pravidel, každému nakupujícímu Právo R na určité množství zboží G.</li>
                            <li>Pak se G i R obchoduje s jedinou podmínkou: na konci obchodování musí mít každý nakupující alespoň tolik práv R, jako má zboží G. Myšlenka je, že někteří nakupující chtějí hned nakoupit více G, a tak podle pravidel trhu nakoupí od váhajících nakupujících jim přiřazené R. Za utržené peníze si pak i ti váhající mohou nakoupit G v následujícím trhu, protože práva se přepočítají před každým trhem, a obnovují se tedy.</li>
                        </ol>

                        <p class="mb-2">Prvním krokem pro vytvoření funkčního krizového distribučního systému je vytvořit</p>

                        <p class="mb-2">Předběžný Informační Portál (PIP) s vlastnostmi:</p>

                        <ol class="list-decimal ml-4 mb-2">
                            <li>může být jednoduše rozšířen na krizový režim,</li>
                            <li>nakupující a prodávající se s ním naučí pracovat a používají ho v normální době, a proto v krizi bude přechod na krizový režim plynulý.</li>
                        </ol>
                    </div>
                </div>

        </div>
</x-guest-layout>
