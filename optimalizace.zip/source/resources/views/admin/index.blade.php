<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight flex-1 ">
                {{ __('Nabídka správce') }}
            </h2>

            <div class="text-right">
                <!-- place for import button -->
            </div>
        </div>
    </x-slot>


    <div class="h-10"></div>

    <div class="text-center font-semibold text-2xl">
        Krizový režim
    </div>

    <x-sections.basic-section class="max-w-3xl mx-auto mb-10 mt-3">

        <div wire:loading.class="opacity-50">
            <div class="flex justify-center items-center gap-4">

                @can('manage stock')
                <x-button-link-light
                    href="{{route('stock-crisis') }}"
                >
                    {{ __('správa krizového režimu') }}
                </x-button-link-light>
                @endcan


                <x-button-link-light
                    href="{{route('generator') }}"
                >
                    {{ __('generátor hodnot') }}
                </x-button-link-light>

            </div>
        </div>

    </x-sections.basic-section>

    <div class="h-10"></div>

    <div class="text-center font-semibold text-2xl">
        Správa záznamů
    </div>

    <x-sections.basic-section class="max-w-3xl mx-auto mb-10 mt-3">

        <div wire:loading.class="opacity-50">
            <div class="flex justify-center items-center gap-4">

                @can('view users')
                <x-button-link-light
                    href="{{route('users') }}"
                >
                    {{ __('správa uživatelů') }}
                </x-button-link-light>
                @endcan

                @can('view companies')
                <x-button-link-light
                    href="{{ route('companies') }}"
                >
                    {{ __('správa společností') }}
                </x-button-link-light>
                @endcan

            </div>
        </div>

    </x-sections.basic-section>

</x-app-layout>

