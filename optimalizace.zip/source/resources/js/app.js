require('./bootstrap');

if(window.performance.navigation.type === window.performance.navigation.TYPE_BACK_FORWARD) {
    // Restart livewire on back or foward.
    console.log('restarting...');
    Livewire.restart();
}

require('alpinejs');
