<?php
return [
    'Password' => 'Heslo',
    'Whoops! Something went wrong.' => 'aaa',
];
